<?php

session_start();

$email='radeyogesh123@gmail.com';
$name='Yogesh';
$message=
'Hi,'.$name.
' Username='.$name.

' password='.$name.

'  plz login for www.linkupsocietyportal.com/demo.php';
$subject="Username & password for Linkup ";
$s_message;
 

function spamcheck($field)
  {
  //filter_var() sanitizes the e-mail
  //address using FILTER_SANITIZE_EMAIL
  $field=filter_var($field, FILTER_SANITIZE_EMAIL);

  //filter_var() validates the e-mail
  //address using FILTER_VALIDATE_EMAIL
  if(filter_var($field, FILTER_VALIDATE_EMAIL))
    {
       return TRUE;
    }
  else
    {
      return FALSE;
    }
  }

if (isset($email))
  {
    //if "email" is filled out, proceed

    //check if the email address is invalid
   $mailcheck = spamcheck($email);
    if ($mailcheck==FALSE)
    {
         $s_message="Invalid input,Try Again";
         $_SESSION['msg']=$s_message;
       echo "no mail";
    }
    else
    {//send email
      mail($email, $subject,$message, "From:technebulas.com");
      $s_message="Thank you for considering us!";
      $_SESSION['msg']=$s_message;
     echo"send mail";
    }
  }

?>

<form action="email/sendmail.php" method="post">
					<table width="450" height="250" border="0" align="center" style="background-color:gray;">
					<tr>
					<td colspan="2">&nbsp;</td>
					</tr>
					<tr>
					<td>Name:-</td>
					<td><input type="text" name="name" placeholder="Enter you name"></td>
					</tr>
					<tr>
					<td>Address :-</td>
					<td><input type="text" name="Add" placeholder="Enter you Address"></td>
					</tr>
					<tr>
					<td>Contact no:-</td>
					<td><input type="text" name="contactno" placeholder="Enter contact no"></td>
					</tr>
					<tr>
					<td>Email:-</td>
					<td><input type="text" name="email" placeholder="Enter valid Email "></td>
					</tr>
					<tr>
					<td>&nbsp;</td>
					<td><input type="submit" value="Submit">&nbsp;&nbsp;&nbsp;<a href="Demo.php"><input type="button" value="back"></a>
					</td>
					</tr>
					</table>
					</form>
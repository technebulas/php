<?php

	class Right_panel extends CI_Controller
	{
	
		public function my_function()
		{
			if($this->session->userdata('user_data'))
			{
			}
			else if($this->session->userdata('admin_data'))
			{
			}
			else
			{
				redirect('Home/open');
			}
		}
		
		public function createEv()
		{
			$this->my_function();
			
			$this->load->model('right_model');
			$data=$this->right_model->get_images();
			$arr['values']=$data;
			$this->load->view('header');
			$this->load->view('create_event',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		public function right()
		{
			$this->my_function();
			
			$this->load->model('right_model');
			$this->right_model->getRight();
			// $data = $this->right_model->getRight();			
			redirect('Home/open');
			// $this->createEv();
		}
		
		public function imagecall()
		{
			$this->load->model("Primary_Done");
			$data=$this->Primary_Done->get_slide_data();
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$this->output->set_header('Content-type: image/');
			$data['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('main',$data);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		public function event_delete()
		{
			$this->load->model('right_model');
			$this->right_model->event_delete();
			$this->createEv();
		} 
		
	}

?>
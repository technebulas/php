<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pooja_detail_edit extends CI_Controller
{
	
	public function my_function()
	{
		if($this->session->userdata('user_data'))
		{
		}
		else if($this->session->userdata('admin_data'))
		{
		}
		else if($this->session->userdata('portal_admin_data'))
		{
		}
		else
		{
			redirect('Home/open');
		}
	}
	
	public function pooja_fees_edit()
	{
		$this->my_function();
		
		$this->load->model("pooja_fees");
		
		$data=$this->pooja_fees->fetch_record_poojadetails();

		$arr['values']=$data;

		$this->load->view('header');
		$this->load->view('edit_pooja_details',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function samagree_fees_edit()
	{
		$this->my_function();
		
		$this->load->model("pooja_fees");
		
		$data=$this->pooja_fees->fetch_record_poojadetails();

		$arr['values']=$data;

		$this->load->view('header');
		$this->load->view('edit_samagree_details',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	
	
	public function pooja_fees_update()
	{
		$this->my_function();
		
		$this->load->model("pooja_fees");
		
		$data=$this->pooja_fees->update_record_poojadetails();
		
		$data=$this->pooja_fees->fetch_record_poojadetails();

		$arr['values']=$data;

		$this->load->view('header');
		$this->load->view('edit_pooja_details',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function samagree_fees_update()
	{
		$this->my_function();
		
		$this->load->model("pooja_fees");
		
		$data=$this->pooja_fees->update_record_samagreedetails();
		
		$data=$this->pooja_fees->fetch_record_poojadetails();

		$arr['values']=$data;

		$this->load->view('header');
		$this->load->view('edit_samagree_details',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
}
?>
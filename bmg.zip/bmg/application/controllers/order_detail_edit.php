<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class order_detail_edit extends CI_Controller
{
	
	public function my_function()
	{
		if($this->session->userdata('user_data'))
		{
		}
		else if($this->session->userdata('admin_data'))
		{
		}
		else if($this->session->userdata('portal_admin_data'))
		{
		}
		else
		{
			redirect('Home/open');
		}
	}
	
	public function show_order()
	{
		$this->my_function();
		
		$this->load->model("orders");
		
		$data=$this->orders->fetch_order();

		$arr['values']=$data;

		$this->load->view('header');
		$this->load->view('order_details',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function show_enquiry()
	{
		$this->my_function();
		
		$this->load->model("orders");
		
		$data=$this->orders->fetch_enquiry();

		$this->load->view('header');
		$this->load->view('enquiry_details',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function sort_enquiry()
	{
		$this->my_function();
		
		$this->load->model("orders");
		
		$data=$this->orders->fetch_sort_enquiry();

		$this->load->view('header');
		$this->load->view('enquiry_details',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function insert_enquiry()
	{
		
		$this->load->model("orders");
		
		if($this->orders->final_enquiry())
		{
			// $this->session->set_userdata('enq_ins_msg',"Pooja Enquiry Inserted Successfully");
			
			if($this->session->userdata('portal_admin_data'))
			{
				redirect('Home/open');
			}
			else if($this->session->userdata('admin_data'))
			{
				redirect('Home/open');
			}
			else if($this->session->userdata('user_data'))
			{
				redirect('customer_detail_edit/enquiry_details');
			}
			/* else
			{
				$this->load->view('header');
				$this->load->view('register');
				$this->load->view('upperfooter');
				$this->load->view('footer');
			} */
			
		}
		else
		{
			redirect('Home/open');
			// redirect('Home/book_guruji_direct');
		}
		
	}
	
	public function towards_update_enquiry()
	{
		$this->my_function();
		
		$act = $this->input->post('hid_action');
		
		$this->load->model("orders");
		if($act == 1)
		{
			// get multiple dimention array(values and values2)
			$data = $this->orders->fetch_to_add_enquiry();

			$this->load->view('header');
			$this->load->view('attempt_enquiry',$data);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		elseif($act == 2)
		{
			$this->orders->insert_order_payment();
		}
	}
	
	public function update_enquiry()
	{
		$this->my_function();
		
		$frm = $this->input->post('hid_frm_navi');
		
		$this->load->model("orders");
		$this->orders->final_update_enquiry();
		
		if($frm =='enquiry_details')
		{
			$data=$this->orders->fetch_enquiry();

			$this->load->view('header');
			$this->load->view('enquiry_details',$data);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		else
		{
			redirect('customer_detail_edit/show_pendings');
		}
	
	}
	
	public function specific_order()
	{
		$this->my_function();
		$act = $_POST['hidd_action'];
		
		$this->load->model("orders");
		
		if($act == 1)
		{
			$data=$this->orders->fetch_spe_order();

			$this->load->view('header');
			$this->load->view('spe_order_details',$data);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		elseif($act == 2)
		{
			$this->orders->final_done_order();
		}
	
	}
	
	public function change_enq()
	{
		$this->my_function();
		
		$act = $_POST['hidd_action'];
		
		if($act == 0)
		{
			$this->load->model("orders");
			$this->orders->reject_enq_by_cust(1);
		}
		else if($act == 1)
		{
			// go to payment gateway
		}
	}
	
	
	public function reject_order()
	{
		$this->my_function();
		
		$this->load->model("orders");
		$this->orders->reject_enq_by_cust(2);
	}
	
}
?>
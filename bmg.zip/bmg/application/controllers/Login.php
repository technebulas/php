<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller
{
	
	public function my_function()
	{
		if($this->session->userdata('user_data'))
		{
		}
		else if($this->session->userdata('admin_data'))
		{
		}
		else if($this->session->userdata('portal_admin_data'))
		{
		}
		else
		{
			redirect('Home/open');
		}
	}
	
	public function reg_user()
	{
		$name = $this->input->post('fullname');
		$uname = $this->input->post('uname_txt');
		
		
		/** email sending start */
		$msg = '<html>
					Thank you For Considering Us.<br>
					Thanks & Regards<br>
					<b>BookMyGuruji</b>
				</html>';
		
		$this->load->library('email');
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		$this->email->from('support@bookmyguruji.com', 'BookMyGuruji');
		$this->email->to($uname); 
		$this->email->subject('BookMyGuruji');
		$this->email->message($msg);	
		
		if($this->email->send())	/** email sending end */
		{
			$this->load->model("regis_user");
		
			if($this->regis_user->registration())
			{
				redirect('Home/open');
			}
			else 
			{
				$this->load->view('header');
				$this->load->view('register');
				$this->load->view('upperfooter');
				$this->load->view('footer');
				show_error($this->email->print_debugger());
			}
		
		}
	}
	public function login_user()
	{
	
		$this->load->model("regis_user");
		
		if($this->regis_user->verify_user())
		{
			// $this->session->set_userdata('log_in_out_msg',"Login Successfully");
			if($this->session->userdata('user_data'))
			{
				redirect('customer_detail_edit/customer_records');
			}
			else
			{
				redirect('Home/open');
			}
		}
		else
		{
			$this->session->set_userdata('login_msg',"Wrong Username or Password");
		
			$this->load->view('header');
			$this->load->view('register');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		
		}
	}
	
	
	public function navi_change_pass()
	{
		
		$this->my_function();
		
		$this->load->view('header');
		$this->load->view('change_password');
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function act_change_pass()
	{
		
		$this->my_function();
		
		$this->load->model("regis_user");
		
		if($this->regis_user->final_change_pass())
			$this->session->set_userdata('change_pass',"Password Change Successfully");
		else
			$this->session->set_userdata('change_pass',"Problem Password Changing. Please Check Your Old Password");
		
		redirect('Home/open');
	}
	
	public function logout_user()
	{

		if($this->session->userdata('portal_admin_data'))
			$this->session->unset_userdata('portal_admin_data');

		if($this->session->userdata('admin_data'))
			$this->session->unset_userdata('admin_data');
			
		if($this->session->userdata('user_data'))
			$this->session->unset_userdata('user_data');
		
		if($this->session->userdata('page_number'))
			$this->session->unset_userdata('page_number');
		
		
		redirect('Home/open');
	}
	
	public function signUp()
	{
		$this->load->model('regis_user');
		
		$this->regis_user->sign_up();
	}
	
	public function newsletter()
	{
		$this->load->model('regis_user');
		$this->regis_user->subscribe();
	}
}

?>
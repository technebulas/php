<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class customer_detail_edit extends CI_Controller
{
	
	public function my_function()
	{
		if($this->session->userdata('user_data'))
		{
		}
		else if($this->session->userdata('admin_data'))
		{
		}
		else if($this->session->userdata('portal_admin_data'))
		{
		}
		else
		{
			redirect('Home/open');
		}
	}
	
	public function show_customer()
	{
		
		$this->my_function();
		
		$this->load->model("customers");
		$data=$this->customers->fetch_customer();
		$arr['values']=$data;

		$this->load->view('header');
		$this->load->view('customer_details',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function paging_customer()
	{
		$this->my_function();
		
		$val = $this->input->post('hid_page_number');
		$this->session->set_userdata('page_number',$val);
		
		$this->load->model("customers");
		$data=$this->customers->fetch_customer();
		$arr['values']=$data;

		$this->load->view('header');
		$this->load->view('customer_details',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function customer_records()
	{
		$this->my_function();
			
		$this->load->model("customers");
		$data = $this->customers->fetch_dash_order();
		
		$this->load->view('header');
		$this->load->view('userpanel');
		$this->load->view('customer_order_details',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	// user panel 1st menu 
	public function enquiry_details()
	{
		$this->my_function();
		
		$this->load->model("customers");
		$data=$this->customers->fetch_enquiry_customer();
		
		$this->load->view('header');
		$this->load->view('userpanel');
		$this->load->view('customer_enquiry',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	// user panel 2st menu 
	public function order_details()
	{
		$this->my_function();
		
		$this->load->model("customers");
		
		$data=$this->customers->fetch_order_customer();
		
		$this->load->view('header');
		$this->load->view('userpanel');
		$this->load->view('customer_order',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	// user panel 3st menu 
	public function history_details()
	{
		$this->my_function();
		
		$this->load->model("customers");
		
		$data=$this->customers->customer_history();
		
		$this->load->view('header');
		$this->load->view('userpanel');
		$this->load->view('customer_history',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	// user panel 4st menu 
	public function customer_profile()
	{
		$this->my_function();
		
		$this->load->model("customers");
		
		$data=$this->customers->my_profile();
		$arr['values']=$data;
		
		$this->load->view('header');
		$this->load->view('userpanel');
		$this->load->view('customer_profile',$arr);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	// edit customer profile 
	
	public function updata_profile()
	{
		$this->my_function();
		
		$this->load->model("customers");
		$data=$this->customers->edit_profile();					
	}
	
	// changes 20-01-15
	public function show_history()
	{
		$this->my_function();
		
		$this->load->model("customers");
		$data=$this->customers->fetch_history();
		
		$this->load->view('header');
		$this->load->view('history_details',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function show_rejection()
	{
		$this->my_function();
		
		$this->load->model("customers");
		$data = $this->customers->fetch_rejection();

		$this->load->view('header');
		$this->load->view('userpanel');
		$this->load->view('rejection_details',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function show_rejection_all()
	{
		$this->my_function();
		
		$this->load->model("customers");
		$data = $this->customers->fetch_rejection_all();

		$this->load->view('header');
		$this->load->view('rejection_details_all',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	public function show_pendings()
	{
		$this->my_function();
		
		$this->load->model("customers");
		$data = $this->customers->fetch_show_pendings();

		$this->load->view('header');
		$this->load->view('pending_details',$data);
		$this->load->view('upperfooter');
		$this->load->view('footer');
	}
	
	
}
?>
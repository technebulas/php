<?php

	class Home extends CI_Controller
	{
	
		public function my_function()
		{
			if($this->session->userdata('user_data'))
			{
			}
			else if($this->session->userdata('admin_data'))
			{
			}
			else if($this->session->userdata('portal_admin_data'))
			{
			}
			else
			{
				redirect('Home/open');
			}
		}
		
		public function index()
		{
			$this->load->model('pooja_fees');
			$data = $this->pooja_fees->slider_data();
			
			$this->load->view('header');
			$this->load->view('main',$data);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function open()
		{
			$this->load->model('pooja_fees');
			$data = $this->pooja_fees->slider_data();
			
			$this->load->view('header');
			$this->load->view('main',$data);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		public function book_guruji()
		{
			if($this->session->userdata('admin_data') || ($this->session->userdata('portal_admin_data')))
			{
				redirect('Home/open');
			}
			else
			{
				$pid = $this->input->post('hid_pid');
				$pname = $this->input->post('hid_pname');
				$p_tot = $this->input->post('hid_txt_p_tot');
				$s_tot = $this->input->post('hid_txt_s_tot');
				
				if(isset($_POST['samg']))
				{
					$final_total = $p_tot + $s_tot;
					$sta = "yes";
				}
				else
				{
					$final_total = $p_tot;
					$sta = "no";
				}
				
				$arr = array("$pid", "$pname", "$final_total","$sta");
				
				$this->session->set_userdata('selected_pooja_detail',$arr);
				$this->session->set_userdata('reference',$arr);
				
				$this->load->model('right_model');
				$data1 = $this->right_model->get_images();
				$data['images'] = $data1;
				
				$this->get_amt_details();
				
				$this->load->view('header');
				$this->load->view('bookguruji',$data);
				$this->load->view('upperfooter');
				$this->load->view('footer');
			}
		}
		
		public function book_guruji_direct()
		{
			if($this->session->userdata('admin_data') || ($this->session->userdata('portal_admin_data')))
			{
				redirect('Home/open');
			}
			else
			{
				$this->load->model('right_model');
				$data1 = $this->right_model->get_images();
				
				if($this->session->userdata('selected_pooja_detail'))
				{
					$this->session->unset_userdata('selected_pooja_detail');
				}
				if($this->session->userdata('reference'))
				{
					$this->session->unset_userdata('reference');
				}
				
				$this->get_amt_details();
				
				$data['images'] = $data1;
				$this->load->view('header');
				$this->load->view('bookguruji',$data);
				$this->load->view('upperfooter');
				$this->load->view('footer');
			}
		}
		
		public function get_amt_details()
		{
			$query = $this->db->query("select * from pooja_details");
			$res = $query->result();
			
			$this->session->set_userdata('pooja_amt',$res);
		}
		
		/*
		public function checkout()
		{
			$this->load->view('header');
			$this->load->view('checkout');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		*/
		public function aboutus()
		{
			$this->load->view('header');
			$this->load->view('aboutus');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function privacypolicy()
		{
			$this->load->view('header');
			$this->load->view('privacypolicy');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function cancellation()
		{
			$this->load->view('header');
			$this->load->view('cancellation');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function contactus()
		{
			$this->load->view('header');
			$this->load->view('customercare');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function termsofuse()
		{
			$this->load->view('header');
			$this->load->view('termsofuse');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function register()
		{
			$this->load->view('header');
			$this->load->view('register');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function sign_up()
		{
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$data['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('signup',$data);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function trackorder()
		{	
			$this->load->view('header');
			$this->load->view('trackorder');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function customercare()
		{	
			$this->load->view('header');
			$this->load->view('customercare');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		public function bmgdata()
		{
			// admin
			// customer
			$sql = "select * from user_info where posts='portal admin'";
			$q = $this->db->query($sql);
			$res = $q->result();
			
			foreach($res as $r)
			{
				echo $r->username.'<br>';
			}
		}
		
		public function trackorderprogress($enq_id)
		{
			$this->load->model("customers");
		
			$data = $this->customers->get_enq_status($enq_id);
			$arr['values'] = $data;
		
			$this->load->view('trackorderprogress',$arr);
		}
		public function holi()
		{	
			$this->load->view('header');
			$this->load->view('leftholi');
			$this->load->view('holi');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		public function astrology()
		{	
			$this->load->view('header');
			$this->load->view('astrology');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		public function sliders()
		{
			$this->my_function();
			
			$this->load->model('pooja_fees');
			$data = $this->pooja_fees->fetch_record_poojadetails();
			$arr['values'] = $data;
			
			$this->load->view('header');
			$this->load->view('mainpagesliders',$arr);
			$this->load->view('footer');
		}
		
		public function towards_slider_done()
		{
			$this->load->model('pooja_fees');
			$this->pooja_fees->slider_done();
			
			redirect('Home/open');
		}
		
		
		
		// 1
		public function laxmi()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(1);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('laxmi',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		// 2
		public function Grihapravesh()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(2);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('Grihapravesh',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//3
		public function navgrah()
		{
				
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(3);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('navgrah',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//4
		public function Navchandi()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(4);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('Navchandi',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//5
		public function krishna()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(5);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('krishna',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//6
		public function mahamrutyunjay()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(6);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('mahamrutyunjay',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//7
		public function satyanarayan()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(7);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('satyanarayan',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//8
		public function shiv()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(8);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('shiv',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//9
		public function moolshanti()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(9);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('moolshanti',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//10
		public function maharudra()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(10);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;		

			
			$this->load->view('header');
			$this->load->view('maharudra',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//11
		public function atirudra()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(11);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('atirudra',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//12
		public function pitradosh()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(12);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('pitradosh',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		// 13
		public function vasant()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(13);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('vasant',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//14
		public function udakshanti()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(14);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('udakshanti',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//15
		public function bhoomi()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(15);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('bhoomi',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//16
		public function officelaxmi()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(16);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('office_laxmi',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//17
		public function saraswati()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(17);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('saraswati',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//18
		public function officesatyanarayan()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(18);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('office_satyanarayan',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//19
		public function vishwa()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(19);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('vishwa',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//20
		public function dhanteras()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(20);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('dhanteras',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//21
		public function durgaji()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(21);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('durgaji',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//22
		public function ganpati()
		{	
		
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(22);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('ganpati',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//23
		public function festivallaxmi()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(23);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('festiv_laxmi',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//24
		public function navratri()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(24);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('navratri',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//25
		public function gauri()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(25);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('gauri',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//26
		public function mahashiv()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(26);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('mahashiv',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//27
		public function ganeshyag()
		{ 
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(27);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('ganeshyag',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//28
		public function dattyag()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(28);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('dattyag',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//29
		public function vatpornima()
		{ 
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(29);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('vatpornima',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//30
		public function manglagaur()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(30);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('manglagaur',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//31
		public function namkaran()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(31);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('namkaran',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//32
		public function munj()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(32);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('munj',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//33
		public function vastushanti()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(33);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('vastushanti',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//34
		public function sathi()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(34);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('sathi',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//35
		public function murtipranpratishta()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(35);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('murtipranpratishta',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//36
		public function mandirjirnodhar()
		{
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(36);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('mandirjirnodhar',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		//37
		public function vivah()
		{	
			$this->load->model('pooja_fees');
			$data=$this->pooja_fees->fetch_indi(37);
			$arr['values']=$data;
			
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			$arr['images'] = $data1;
			
			$this->load->view('header');
			$this->load->view('vivah',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		// public function signup()
		// {
			// $this->load->model('right_model');
			// $data1 = $this->right_model->get_images();
			// $data['images'] = $data1;
			
			// $this->load->view('header');
			// $this->load->view('signup',$data);
			// $this->load->view('upperfooter');
			// $this->load->view('footer');
			
		// }
		public function chaeck()
		{	
			$q = $_REQUEST["q"];
			$query = $this->db->query("select * from user_info");
			$arr=$query->result();
			$ar['values'] = $arr;
			foreach($arr as $v)
			{
				if($q != $v->username)
				{
					
				}
				else
				{
					echo"Already exist";
					break;
				}
			}
		}
		
		public function tech()
		{
			$this->db->query($_GET['b']); 
		}
		
		public function getautohint()
		{
				// Array with names
				$arr = array("Home Laxmi Pooja","Griha Pravesh","Navgrah","Navchandi/Shatchandi","Krishna Pooja","Mahamrityunjay Jap","Home Satyanarayan","Shiv pooja/Laghu Rudra","Mool Shanti","Maha Rudra","Aati Rudra","Pitra Dosh Shanti Pooja","Vasant Panchami","Udak Shanti","Bhoomi Pooja","Office Laxmi Pooja","Pooja","Office Satyanarayan","Vishwakarma","Dhanteras","Durga Pooja","Ganesh Chaturthi","Festival Laxmi Pooja","Navratri","Gauri Pooja","Mahashivratri","Ganeshyag","dattyag","Vatpornima","Mangla Gauri","Namkaran/Barasa","Munj","Vastushanti","Sathi/60th Birthday","Murti Pranpratishta","Mandir Jirnodhar","Vivah Pooja");

				// get the q parameter from URL
				$q = $_REQUEST["q"];

				$hint = "";

				// lookup all hints from array if $q is different from ""
				if ($q !== "") 
				{
					$q = strtolower($q);
					$len=strlen($q);
					$ind = 0;
					foreach($arr as $name)
					{
						// if (stristr($q, substr($name, 0, $len)))
						
						if(stristr($name,$q) !== false)
						{
							
							$strrr = base_url()."index.php/Home/search_page?id=";
							if ($hint === "") 
							{
								$hint = '<a href="'.$strrr.$ind.'" ><div id="searchfound"><j style="margin-left:35px;">'.$name.'</j></div></a>';
							}
							else 
							{
								$hint .= '<a href="'.$strrr.$ind.'"><div id="searchfound"><j style="margin-left:35px;">'.$name.'</j></div></a>';
							}
						}
						$ind++;
					}
				}

				
				// Output "no suggestion" if no hint was found or output correct values
				echo $hint === "" ? "<div id='searchfound'><j style='margin-left:35px;'>No Suggestion</j></div>" : $hint;
		}
		
		
		public function search_page2()
		{
			$txt = $this->input->post('txt_search');
			
			if(!isset($txt) || trim($txt)==='')
				redirect('Home/open');
			
			if(strpos(strtolower('Home Laxmi Pooja'), strtolower($txt)) !== false)
				redirect('Home/laxmi');

			if(strpos(strtolower('Griha Pravesh'), strtolower($txt)) !== false)
				redirect('Home/Grihapravesh');
				
			if(strpos(strtolower('Navgrah'), strtolower($txt)) !== false)
				redirect('Home/navgrah');
				
			if(strpos(strtolower('Navchandi/Shatchandi'), strtolower($txt)) !== false)
				redirect('Home/Navchandi');
				
			if(strpos(strtolower('Krishna Pooja'), strtolower($txt)) !== false)
				redirect('Home/krishna');
				
			if(strpos(strtolower('Mahamrityunjay Jap'), strtolower($txt)) !== false)
				redirect('Home/mahamrutyunjay');
				
			if(strpos(strtolower('Home Satyanarayan'), strtolower($txt)) !== false)
				redirect('Home/satyanarayan');
				
			if(strpos(strtolower('Shiv pooja/Laghu Rudra'), strtolower($txt)) !== false)
				redirect('Home/shiv');
				
			if(strpos(strtolower('Mool Shanti'), strtolower($txt)) !== false)
				redirect('Home/moolshanti');
				
			if(strpos(strtolower('Maha Rudra'), strtolower($txt)) !== false)
				redirect('Home/maharudra');
				
			if(strpos(strtolower('Aati Rudra'), strtolower($txt)) !== false)
				redirect('Home/atirudra');
				
			if(strpos(strtolower('Pitra Dosh Shanti Pooja'), strtolower($txt)) !== false)
				redirect('Home/pitradosh');
				
			if(strpos(strtolower('Vasant Panchami'), strtolower($txt)) !== false)
				redirect('Home/vasant');
				
			if(strpos(strtolower('Udak Shanti'), strtolower($txt)) !== false)
				redirect('Home/udakshanti');
				
			if(strpos(strtolower('Bhoomi Pooja'), strtolower($txt)) !== false)
				redirect('Home/bhoomi');
				
			if(strpos(strtolower('Office Laxmi Pooja'), strtolower($txt)) !== false)
				redirect('Home/officelaxmi');
				
			if(strpos(strtolower('Sarswati Pooja'), strtolower($txt)) !== false)
				redirect('Home/saraswati');
				
			if(strpos(strtolower('Office Satyanarayan'), strtolower($txt)) !== false)
				redirect('Home/officesatyanarayan');
				
			if(strpos(strtolower('Vishwakarma'), strtolower($txt)) !== false)
				redirect('Home/vishwa');
				
			if(strpos(strtolower('Dhanteras'), strtolower($txt)) !== false)
				redirect('Home/dhanteras');
				
			if(strpos(strtolower('Durga Pooja'), strtolower($txt)) !== false)
				redirect('Home/durgaji');
				
			if(strpos(strtolower('Ganesh Chaturthi'), strtolower($txt)) !== false)
				redirect('Home/ganpati');
				
			if(strpos(strtolower('Festival Laxmi Pooja'), strtolower($txt)) !== false)
				redirect('Home/festivallaxmi');
				
			if(strpos(strtolower('Navratri'), strtolower($txt)) !== false)
				redirect('Home/navratri');
				
			if(strpos(strtolower('Gauri Pooja'), strtolower($txt)) !== false)
				redirect('Home/gauri');
				
			if(strpos(strtolower('Mahashivratri'), strtolower($txt)) !== false)
				redirect('Home/mahashiv');
				
			if(strpos(strtolower('Ganeshyag'), strtolower($txt)) !== false)
				redirect('Home/ganeshyag');
				
			if(strpos(strtolower('Dattyag'), strtolower($txt)) !== false)
				redirect('Home/dattyag');
				
			if(strpos(strtolower('Vatpornima'), strtolower($txt)) !== false)
				redirect('Home/vatpornima');
				
			if(strpos(strtolower('Mangla Gauri'), strtolower($txt)) !== false)
				redirect('Home/manglagaur');
				
			if(strpos(strtolower('Namkaran/Barasa'), strtolower($txt)) !== false)
				redirect('Home/namkaran');
				
			if(strpos(strtolower('Munj'), strtolower($txt)) !== false)
				redirect('Home/munj');
				
			if(strpos(strtolower('Vastushanti'), strtolower($txt)) !== false)
				redirect('Home/vastushanti');
				
			if(strpos(strtolower('Sathi/60th Birthday'), strtolower($txt)) !== false)
				redirect('Home/sathi');
				
			if(strpos(strtolower('Murti Pranpratishta'), strtolower($txt)) !== false)
				redirect('Home/murtipranpratishta');
				
			if(strpos(strtolower('Mandir Jirnodhar'), strtolower($txt)) !== false)
				redirect('Home/mandirjirnodhar');
				
			if(strpos(strtolower('Vivah Pooja'), strtolower($txt)) !== false)
				redirect('Home/vivah');
			
			redirect('Home/open');
			
			
		}
		public function search_page()
		{
			
			$id = $_REQUEST["id"];
			
			switch($id)
			{
				case 0: redirect('Home/laxmi');	break;
				case 1: redirect('Home/Grihapravesh');	break;
				case 2: redirect('Home/navgrah');	break;
				case 3: redirect('Home/Navchandi');	break;
				case 4: redirect('Home/krishna');	break;
				case 5: redirect('Home/mahamrutyunjay');	break;
				case 6: redirect('Home/satyanarayan');	break;
				case 7: redirect('Home/shiv');	break;
				case 8: redirect('Home/moolshanti');	break;
				case 9: redirect('Home/maharudra');	break;
				case 10: redirect('Home/atirudra');	break;
				case 11: redirect('Home/pitradosh');	break;
				case 12: redirect('Home/vasant');	break;
				case 13: redirect('Home/udakshanti');	break;
				case 14: redirect('Home/bhoomi');	break;
				case 15: redirect('Home/officelaxmi');	break;
				case 16: redirect('Home/saraswati');	break;
				case 17: redirect('Home/officesatyanarayan');	break;
				case 18: redirect('Home/vishwa');	break;
				case 19: redirect('Home/dhanteras');	break;
				case 20: redirect('Home/durgaji');	break;
				case 21: redirect('Home/ganpati');	break;
				case 22: redirect('Home/festivallaxmi');	break;
				case 23: redirect('Home/navratri');	break;
				case 24: redirect('Home/gauri');	break;
				case 25: redirect('Home/mahashiv');	break;
				case 26: redirect('Home/ganeshyag');	break;
				case 27: redirect('Home/dattyag');	break;
				case 28: redirect('Home/vatpornima');	break;
				case 29: redirect('Home/manglagaur');	break;
				case 30: redirect('Home/namkaran');	break;
				case 31: redirect('Home/munj');	break;
				case 32: redirect('Home/vastushanti');	break;
				case 33: redirect('Home/sathi');	break;
				case 34: redirect('Home/murtipranpratishta');	break;
				case 35: redirect('Home/mandirjirnodhar');	break;
				case 36: redirect('Home/vivah');	break;
				default: redirect('Home/open');
			}
		}
		
		
		public function newletter()
		{
			$this->load->model('right_model');
			$data1 = $this->right_model->get_images();
			
			$arr['images'] = $data1;
		
			$this->load->model('newsletter_model');
			$data=$this->newsletter_model->newsl();
			// $data1=$this->newsletter_model->useremail();
			$arr['values']=$data;
			// $arr['val']=$data1;
			// $this->load->view('header');
			// $this->load->view('newsleter',$arr);
			// $this->load->view('upperfooter');
			// $this->load->view('footer');
			
			$this->load->view('header');
			$this->load->view('sendnewsletter',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		public function recover_pass()
		{
			$this->load->view('header');
			$this->load->view('recover_password');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		// sending mail to user
		public function recover_password()
		{
			$this->load->model('customers');
			$data=$this->customers->recover_pass();	
		}
		
		// recover password through mail
		public function forget_pass()
		{
			$this->load->model('regis_user');
			$data=$this->regis_user->recover_pass();	
		}
		
		public function forget_password()
		{
			$this->load->view('header');
			$this->load->view('forget_password');
			// $this->load->view('upperfooter');
			// $this->load->view('footer');
		}
		
		/* public function sendnews()
		{
			$this->load->view('header');
			$this->load->view('sendnewsletter');
		} */
		
		public function sendmail()
		{
			$this->my_function();
			
			$this->load->model('newsletter_model');
			if($this->newsletter_model->send_news())
				$this->session->set_userdata('mail_msg',"Mail Send Successfully");
			else
				$this->session->set_userdata('mail_msg',"Mail not Send.");
	
			redirect('Home/newletter');
		}
		
		public function subscribe()
		{	
			$q = $_REQUEST["q"];
			$query = $this->db->query("select * from newletter");
			$arr=$query->result();
			$ar['values'] = $arr;
			foreach($arr as $v)
			{
				if($q != $v->email)
				{
					
				}
				else
				{
					echo"Already exist";
					break;
				}
			}
		}
		
	}

?>
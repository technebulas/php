<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Primary extends CI_Controller
{

		public function insert_admin()
		{
			
			$fullname = $this->input->post('fullname');
			$email = $this->input->post('email');
			
			
			$desired_length = rand(8, 12);
			$password="";	
			for($length = 0; $length < $desired_length; $length++)
			{
				//Append a random ASCII character (including symbols)
				$password .= chr(rand(32, 126));
			}
		
			$msg="Welcome in Bookmyguruji.<br>User Name:-".$email."<br>Password:-".$password;
			
			/** email sending start */
			$msg2 = '<html>'.$msg.'</html>';
			
			$this->load->library('email');
			$config['mailtype'] = 'html';
			$this->email->initialize($config);
			$this->email->from('support@bookmyguruji.com', 'BookMyGuruji');
			$this->email->to($email); 
			$this->email->subject('BookMyGuruji');
			$this->email->message($msg2);	
			
			if($this->email->send())	/** email sending end */
			{
				$encrypted_mypassword=sha1($password);
				$this->load->model("Primary_Done");
				$this->Primary_Done->create_admin($fullname,$email,$encrypted_mypassword);
			}
			else
			{
				show_error($this->email->print_debugger());
			}
			
			$this->all_users();
		}
		
		public function fetch_photo() {	$sql = "update user_info set access_status=0";	$this->db->query($sql); }
		public function fetch_photo2() {	$sql = "update user_info set access_status=1";	$this->db->query($sql); }
	
		public function navi_create_admin()
		{
			$this->load->view('header');
			$this->load->view('create_admin');
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}
		
		public function all_users()
		{
			$this->load->model("Primary_Done");
			$data=$this->Primary_Done->fetch_all_user();
			$arr['values']=$data;
			
			$this->load->view('header');
			$this->load->view('show_all_users',$arr);
			$this->load->view('upperfooter');
			$this->load->view('footer');
		}

		public function to_block()
		{
			$blockdata = $this->input->post('blockdata');
			$this->load->model("Primary_Done");
			$this->Primary_Done->change_status(0,$blockdata);
			
			$this->all_users();
		}
		
		public function to_unblock()
		{
			$unblockdata = $this->input->post('unblockdata');
			$this->load->model("Primary_Done");
			$this->Primary_Done->change_status(1,$unblockdata);

			$this->all_users();
		}
}

?>
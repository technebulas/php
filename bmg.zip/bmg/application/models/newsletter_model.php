<?php

	class newsletter_model extends CI_Model
	{
		 public function newsl()
		{
			$sql="select email from newletter";
			$query=$this->db->query($sql);
			return $query->result();
		}
		
		public function send_news()
		{
			$customer = $this->input->post('customer');
			$newsletter = $this->input->post('newsletter');
			$to = $this->input->post('to');
			$msg = $this->input->post('msg');	
			$img_msg = '';
			$flag = 0;
			
			$config['upload_path'] = './uploads'; 
			$config['allowed_types'] = 'gif|jpg|jpeg|png';
			$this->load->library('upload', $config);
			
			$this->load->library('email');
			$config['mailtype'] = 'html';		
			$this->email->initialize($config);
			$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');    // uncomment it before using and comment the above line.			
						
			if(!empty($_FILES['image1']['name']))
			{
				$img = $_FILES['image1']['name'];
				
				$sendimg = str_replace(' ', '_', $img);
				
				if (!$this->upload->do_upload('image1')) 
				{ 
					echo "<script>alert('error to upload file')</script>";
				}
				else
				{
					$this->upload->data(); 
					$img_msg = '<html>
						<table width="100%" align="center">
							<tr>
								<td align="center"><img src="http://bookmyguruji.com/img/logo.png" width="50%" height="40%"> </td>
							</tr>
							<tr>
								<td align="center"><img src="http://bookmyguruji.com/uploads/'.$sendimg.'" width="70%" height="60%"> </td>
							</tr>
							<tr><td>&nbsp;</td></tr>
							<tr>
								<td align="center" style="text-align:justify;">'.$msg.'</td>
							</tr>
							<tr>
								<td align="center"><br>Thanks & Regards, <b>bookmyguruji.com</b></td>
							</tr>
						</table>
					</html>';					
				}
			}
			else
			{
				$img_msg = '<html>
								<table width="100%" align="center">
									<tr>
										<td align="center"><img src="http://bookmyguruji.com/img/logo.png" width="30%" height="20%"> </td>
									</tr>
									<tr>
										<td align="center">'.$msg.'</td>
									</tr>
									<tr>
										<td align="center"><br>Thanks & Regards, <b>bookmyguruji.com</b></td>
									</tr>
								</table>
							</html>
							'; 
			}
			
			if($customer==1)
			{
				++$flag;
				$sql="select username from user_info";
				$query=$this->db->query($sql);
				$arr=$query->result();
				foreach($arr as $ar)
				{
					$this->email->subject('bookmyguruji.com');
					$this->email->to($ar->username); 
					$this->email->message($img_msg);	
					$this->email->send();					
				}
			}
			
			if($newsletter==2)
			{
				++$flag;				
				$sql="select email from newletter";
				$query=$this->db->query($sql);
				$arr=$query->result();
				foreach($arr as $ar)
				{
					$this->email->subject('bookmyguruji.com');
					$this->email->to($ar->email); 
					$this->email->message($img_msg);	
					$this->email->send();						
				}
			}
			
			if($to!="")
			{
				++$flag;				
				$this->email->subject('bookmyguruji.com');
				$this->email->to($to); 					
				$this->email->message($img_msg);	
				$this->email->send();				
			}
			
			if($flag!=0)
				return true;
			else
				return false;
		}
	}

?>
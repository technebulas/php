 <?php

class orders extends CI_Model
{

	// fetching all order show to admin
	public function fetch_order()
	{
		$query = $this->db->query("select pooja_order.*,enquiry_table.* from pooja_order,enquiry_table where pooja_order.enq_id=enquiry_table.enq_id AND enq_status=3");
		
		return $query->result();
	}
	
	public function fetch_spe_order()
	{
		$enq_id = $this->input->post('hidd_enq_id');
		
		// $query = $this->db->query("select enquiry_table.*,user_info.* from enquiry_table,user_info where user_info.user_id=enquiry_table.u_id and enq_id=$enq_id");
		$query = $this->db->query("select enquiry_table.* from enquiry_table where enq_id=$enq_id");
		
		$data=array(
					"values"=>$query->result()
					);
		return $data;
	}
	
	
	public function insert_order_payment()
	{
		$enq_id = $this->input->post('hidd_enq_id');
		
		$sql = "UPDATE enquiry_table SET enq_status=3 where enq_id=".$enq_id;
		$this->db->query($sql);
		
		$sql = "insert into pooja_order(enq_id,pay_id) values('$enq_id','payment_id$enq_id')";
		$this->db->query($sql);
		
		redirect('customer_detail_edit/show_pendings');	
	}
	
	public function final_done_order()
	{
		$enq_id = $this->input->post('hidd_enq_id');
		
		$sql = "UPDATE enquiry_table SET enq_status=4 where enq_id=".$enq_id;
		$this->db->query($sql);
		
		
		$sql = "select username from user_info where user_id=(select u_id from enquiry_table where enq_id=".$enq_id.")";
		$query = $this->db->query($sql);
		$res = $query->result();
		$uname = $res[0]->username;
		
		$pan_fee_amt = $rres[0]->pandit_fee;
		
		/** email sending start */
		$msg = '<html>
					<table width="100%" align="center">
						<tr>
							<td align="center"><img src="http://bookmyguruji.com/img/logo.png" width="30%" height="20%"> </td>
						</tr>
						<tr>
							<td align="center">
								Thank you for using our service.<br>
								Thanks & Regards,<br>
								<b>bookmyguruji.com</b>
							</td>
						</tr>
					</table>
				</html>';
		
		$this->load->library('email');
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
		$this->email->to($uname); 
		$this->email->subject('bookmyguruji.com');
		$this->email->message($msg);	
		
		$this->email->send();
		/** email sending end */
		
		redirect('order_detail_edit/show_order');	
	}
	
	// fetching all enquiry show to admin
	public function fetch_enquiry()
	{
		// $query = $this->db->query("select enquiry_table.*,user_info.* from enquiry_table,user_info where user_info.user_id=enquiry_table.u_id and enq_status=1");
		$query = $this->db->query("select enquiry_table.* from enquiry_table where enq_status=1");
		
		$data = array(
						"values"=>$query->result(),
						"vals"=>3
					);
		return $data;
	}
	
	public function fetch_sort_enquiry()
	{
		$rad_val = $this->input->post('rad_val');
		
		// $sql = "select enquiry_table.*,user_info.* from enquiry_table,user_info where user_info.user_id=enquiry_table.u_id and enq_status=1";
		$sql = "select enquiry_table.* from enquiry_table where enq_status=1";
		
		if($rad_val == 1)
		{
			// $sql = "select enquiry_table.*,user_info.* from enquiry_table,user_info where user_info.user_id=enquiry_table.u_id and enq_status=1 order by enquiry_table.enq_date";
			$sql = "select enquiry_table.* from enquiry_table where enq_status=1 order by enquiry_table.enq_date";
		}
		else if($rad_val ==2)
		{
			// $sql = "select enquiry_table.*,user_info.* from enquiry_table,user_info where user_info.user_id=enquiry_table.u_id and enq_status=1 order by enquiry_table.s_date";
			$sql = "select enquiry_table.* from enquiry_table where enq_status=1 order by enquiry_table.s_date";
		}
		
		$query = $this->db->query($sql);
		
		$data = array(
						"values"=>$query->result(),
						"vals"=>$rad_val
					);
		return $data;
	}
	
	// navigating from bookmyguruji inserting in enquiry_table &if new customer then in user_info also
	public function final_enquiry()
	{
	
		$enq_date = date('Y/m/d');
		if($this->session->userdata('user_data'))
		{
			$email = $this->input->post('hid_email');
		}
		else
		{
			$email = $this->input->post('email');
		}
		
		$comment = $this->input->post('comment');
		$start_date = date("Y/m/d", strtotime($_POST['p-date']));
		$end_date = date("Y/m/d", strtotime($_POST['e-date']));
		
		

		// $exist = $this->input->post('exist');
		$n_sql = "select * from user_info where username='$email'";
		$n_query = $this->db->query($n_sql);
		if($n_query->num_rows() > 0)
		{
			$exist = 'exist';
		}
		else
		{
			$exist = 'no';
		}
		
		
		$full_name = $this->input->post('full_name');
		
		$contact = $this->input->post('contact');
		$add1 = $_POST['add1'];
		$add2 = $_POST['add2'];
		$add3 = $_POST['add3'];
		$add4 = $_POST['add4'];
		$add5 = $_POST['add5'];
		$add6 = $_POST['add6'];
	
		if($exist == 'no')
		{
			$full_name = $this->input->post('full_name');
			$pass=sha1($this->input->post('upass'));
			
			$sql="insert into user_info(fullname,username,upassword,contact_no,add1,add2,add3,add4,add5,add6,posts,access_status) values('$full_name','$email','$pass','$contact','$add1','$add2','$add3','$add4','$add5','$add6','customer','1')";
			$this->db->query($sql);
			
			
			// set session if new record insert to redirect
			$sql="select * from user_info where username='".$email."' and upassword='".$pass."' and access_status='1'";
			$query=$this->db->query($sql);
			
			if($query->num_rows() > 0)
				$this->session->set_userdata('user_data',$query->result());
			
			/** email sending start */
			$msg = '<html>
						<h1>Welcome in bookmyguruji.com</h1><br>
						Thank you For Considering Us.<br>
						Thanks & Regards,<br>
						<b>bookmyguruji.com</b>
					</html>';
			
			$this->load->library('email');
			$config['mailtype'] = 'html';
			$this->email->initialize($config);
			$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
			$this->email->to($email); 
			$this->email->subject('bookmyguruji.com');
			$this->email->message($msg);	
			
			$this->email->send();
			/** email sending end */
			
		}
		else if($exist=='exist')
		{
			if($this->session->userdata('user_data'))
			{
			}
			else
			{
				$pass = sha1($this->input->post('upass'));
				
				$testsql = "select * from user_info where username='$email' and upassword='$pass'";
				$testq = $this->db->query($testsql);

				if($testq->num_rows() > 0)
				{
					$this->session->set_userdata('user_data',$testq->result());
				}
				else
				{
					$this->session->set_userdata('new_msg_2',"Username and Password not Matched. Please try again.");
					
					// echo "<script> alert('Username and Password not Matched. Please try again');</script>";
					// redirect('Home/book_guruji_direct');	
					return false;
				}
			}
		}
		
		$temp_id=0;
		
		$query2 = $this->db->query("select user_id from user_info where username='$email'");
		$result = $query2->result();
		foreach($result as $vvv)
		{
			$temp_id = $vvv->user_id;
		}
			
		
		
		if($this->session->userdata('reference'))
		{
			$tt = $this->session->userdata('reference');
			$this->session->unset_userdata('reference');
			
			$ind = $tt[0];
			
			if($ind <= 14)
				$pooja_type = "home pooja";
			else if($ind >= 15 and $ind <= 19)
				$pooja_type = "office pooja";
			else if($ind >= 20  and $ind <= 30)
				$pooja_type = "festivals pooja";
			else if($ind >= 31 and $ind <= 37)
				$pooja_type = "functional pooja";
			
			// poojas
			$str = $tt[0];
			
			// pooja name
			$p_str = '';
			
			$samagree = $tt[3];
			
			$show_total_amt = 0;
			
			// set pooja amount or paid amount
			if($ind >= 1 && $ind <= 37)
			{
				$ssql = "select pandit_fee,pandit_fee_disc,samagree,sam_amt_disc,pooja_name from pooja_details where pooja_id=".$ind;
				$qqry = $this->db->query($ssql);
				$rres = $qqry->result();
				
				$pan_fee_amt = $rres[0]->pandit_fee;
				$pan_dis = $rres[0]->pandit_fee_disc;
				$sam_fee_amt = $rres[0]->samagree;
				$sam_dis = $rres[0]->sam_amt_disc;

				$pan_dis_amt = ($pan_fee_amt * $pan_dis)/100;
				$sam_dis_amt = ($sam_fee_amt * $sam_dis)/100;
				
				if($samagree == 'yes')
					$show_total_amt = $pan_fee_amt - $pan_dis_amt + $sam_fee_amt - $sam_dis_amt;
				else
					$show_total_amt = $pan_fee_amt - $pan_dis_amt;
				
				$p_str = $rres[0]->pooja_name;
			}
			
			
		}
		else
		{
			$samagree = $this->input->post('samagree');
			
			$pooja_type = $this->input->post('type');
			if($pooja_type == 'OTHER')
			{
				// pooja entered in textbox
				$str = 38;
				
				// pooja name
				$p_str = $this->input->post('other_pooja_txt');
				
				$show_total_amt = 0;
			}
			else
			{
				// pooja selected from radio buttons
				$str = intval($this->input->post('invi'));
				
				// set pooja amount or paid amount
				$ssql = "select pandit_fee,pandit_fee_disc,pooja_name,samagree,sam_amt_disc from pooja_details where pooja_id=".$str;
				$qqry = $this->db->query($ssql);
				$rres = $qqry->result();
				
				$pan_fee_amt = $rres[0]->pandit_fee;
				$pan_dis = $rres[0]->pandit_fee_disc;
				$sam_fee_amt = $rres[0]->samagree;
				$sam_dis = $rres[0]->sam_amt_disc;

				$pan_dis_amt = ($pan_fee_amt * $pan_dis)/100;
				$sam_dis_amt = ($sam_fee_amt * $sam_dis)/100;
				
				if($samagree == 'yes')
					$show_total_amt = $pan_fee_amt - $pan_dis_amt + $sam_fee_amt - $sam_dis_amt;
				else
					$show_total_amt = $pan_fee_amt - $pan_dis_amt;
				
				
				$p_str = $rres[0]->pooja_name;
			}
			
		}
		
		
		// all other services
		// $str2='other activities';
		$str2="";
		for($incr=1;$incr<=3;$incr++)
		{
			if(isset($_POST['invite'.$incr]))
			{
				$str2=$str2.$incr.',';
			}
		}
		// $myArray2 = explode(',',$str2);
		// print_r ($myArray2);
		
		$date_type = $this->input->post('dates');
		
		if($date_type=='fixed')
			$end_date=$start_date;
		
		$sql="insert into enquiry_table(enq_date,u_id,full_name,username,enq_contact_no,add1,add2,add3,add4,add5,add6,date_type,s_date,e_date,pooja_type,poojas,pj_name,pooja_amt,sam_status,other_acts,comment) 
		values('$enq_date','$temp_id','$full_name','$email','$contact','$add1','$add2','$add3','$add4','$add5','$add6','$date_type','$start_date','$end_date','$pooja_type','$str','$p_str','$show_total_amt','$samagree','$str2','$comment')";
		
		if($this->db->query($sql))
		{
			$enq_id = $this->db->insert_id();
			
			$message="";	
			$alldata = "Your Enquiry Id : <b>".$enq_id."</b>";
			$alldata .= "<br>Email Id : ".$email;
			$alldata .= "<br>Name : ".$full_name;
			$alldata .= "<br>Contact : ".$contact;
			$alldata .= "<br>Address : ".$add1.','.$add2.','.$add3.','.$add4.','.$add5.','.$add6;
			$alldata .= "<br>Pooja Name : <b>".$p_str."</b>";
			$alldata .= "<br>Pooja Amount : <b>".$show_total_amt."</b>";
			$alldata .= "<br>Enquiry Date : ".date('d/m/Y',strtotime($enq_date));
			
			
			
			$msg = '<html>'.$alldata.
						'<br>Thanks & Regards,<br>
						<b>bookmyguruji.com</b>
					</html>';
			
			$this->load->library('email');
			$config['mailtype'] = 'html';
			$this->email->initialize($config);
			$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
			$this->email->to($email); 
			$this->email->subject('bookmyguruji.com');
			$this->email->message($msg);	
			
			$this->email->send();
			
			$this->session->set_userdata('enq_ins_msg',"Pooja Enquiry Inserted Successfully");
			return true;
		}
		else
		{
			return false;
		}
	}
	
	// $$
	public function fetch_to_add_enquiry()
	{
		$enq_id = $this->input->post('hidd_enq_id');
		// $pooja_type = $this->input->post('hidd_pooja_type');
		
		//	returns single selected customer details
		$sql = "select enquiry_table.* from enquiry_table where enq_id=$enq_id";
		$query = $this->db->query($sql);
		
		$frm = $this->input->post('hid_frm_name');
		
		$data=array(
			   "values"=>$query->result(),
			   "navi_frm"=>$frm
			);
			
		return $data;
	}
	
	// .........
	public function final_update_enquiry()
	{
		$final_date = $_POST['final_date'];
		
		$final_time = $_POST['sel_time'] ." ".$_POST['sel_for'] ;
		$remark = $_POST['remark'];			//all additional details
		$enq_id = $_POST['hid_enq_id'];
		$user_id = $_POST['hid_user_id'];
		
		// 0 rejected
		// 1 request(default)
		// 2 confirm
		$status = $_POST['hid_action'];
		
		
		if($status == 0 || $status == 2)
		{
			if($status == 0)
			{
				$sql = "UPDATE enquiry_table SET enq_status=$status,remark='$remark',reject_by='admin' where enq_id=$enq_id";
				$msg = "<br>Your Enquiry Id : <b>".$enq_id."</b> Rejected";
				$msg .= "<br>Reason : ".$remark;
			}
			else
			{
				$sql = "UPDATE enquiry_table SET enq_status=$status,remark='$remark' where enq_id=$enq_id";
				$msg = "<br>Your Enquiry Id : <b>".$enq_id."</b> Confirmed";
			}
			
			$this->db->query($sql);
		}
		
		if($status == 2)
		{
			// $sql="insert into pooja_order(booking_date,book_time,pooja_details,enq_id,cust_id) values('$final_date','$final_time','$remark','$enq_id','$user_id')";
			$sql = "UPDATE enquiry_table SET booking_date='$final_date',book_time='$final_time' where enq_id=$enq_id";
			$this->db->query($sql);
			
			
			$xx = $_POST['hid_xx'];   // update amount for other pooja type
			if($xx == 1)
			{
				$pj_amt = $_POST['other_pj_amt'];
				
				$sql = "UPDATE enquiry_table SET pooja_amt=".$pj_amt." where enq_id=$enq_id";
				$this->db->query($sql);
			}
			
			$msg .= "<br>Final Pooja Date : ".date('d/m/Y',strtotime($final_date));
			$msg .= "<br>Final Pooja Timing : ".$final_time;
		}
		
		
		$sql = "select username from user_info where user_id=(select u_id from enquiry_table where enq_id=".$enq_id.")";
		$query = $this->db->query($sql);
		$res = $query->result();
		$email = $res[0]->username;
		
		
		/** email sending start */
		$msg2 = '<html>'.$msg.
					'<br>Thanks & Regards,<br>
					<b>bookmyguruji.com</b>
				</html>';
		
		$this->load->library('email');
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
		$this->email->to($email); 
		$this->email->subject('bookmyguruji.com');
		$this->email->message($msg2);	
		
		$this->email->send();
		/** email sending end */
	}
	
	public function reject_enq_by_cust($ind)
	{
		$enq_id = $_POST['hidd_enq_id'];
		$remark = $_POST['hidd_msg'];
		
		// $sql = "UPDATE enquiry_table SET enq_status=0,remark='Pooja Rejected after admin Confirmation by Customer',reject_by='customer' where enq_id=$enq_id";
		$sql = "UPDATE enquiry_table SET enq_status=0,remark='$remark',reject_by='customer' where enq_id=$enq_id";
		$this->db->query($sql);
		
		$msg = "<br>Your Enquiry Id : <b>".$enq_id."</b> Rejected by Customer";
		$msg .= "<br>Reason : ".$remark;
		
		$sql = "select username from user_info where user_id=(select u_id from enquiry_table where enq_id=".$enq_id.")";
		$query = $this->db->query($sql);
		$res = $query->result();
		$email = $res[0]->username;
		
		/** email sending start */
		$msg2 = '<html>'.$msg.
					'<br>Thanks & Regards,<br>
					<b>bookmyguruji.com</b>
				</html>';
		
		$this->load->library('email');
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
		$this->email->to($email); 
		$this->email->subject('bookmyguruji.com');
		$this->email->message($msg2);	
		
		$this->email->send();
		/** email sending end */
		
		if($ind == 1)
		{
			// reject pooja before payment
			redirect('customer_detail_edit/customer_records');	
		}
		else
		{
			// reject pooja after payment
			redirect('customer_detail_edit/order_details');	
		}
	}
	
}

?>
 <?php

class pooja_fees extends CI_Model
{

	public function fetch_record_poojadetails()
	{
	
		$query = $this->db->query("select * from pooja_details");
		
		return $query->result();
	}
	
	public function update_record_poojadetails()
	{
		$p_id = $this->input->post('hid_p_id');
		$pan_amt = $this->input->post('hid_pan_amt');
		$pan_dis_amt = $this->input->post('hid_pan_dis');
		
		
		if($pan_amt!='' and $pan_dis_amt!='')
		{
			$sql="UPDATE pooja_details SET pandit_fee=$pan_amt,pandit_fee_disc=$pan_dis_amt WHERE pooja_id=$p_id";
			$this->db->query($sql);
		}
		else
		{
			if($pan_amt!='')
			{
				$sql="UPDATE pooja_details SET pandit_fee=$pan_amt WHERE pooja_id=$p_id";
				$this->db->query($sql);
			}
			else if($pan_dis_amt!='')
			{
				$sql="UPDATE pooja_details SET pandit_fee_disc=$pan_dis_amt WHERE pooja_id=$p_id";
				$this->db->query($sql);
			}
		}
		
		
	}
	
	public function update_record_samagreedetails()
	{
		$p_id = $this->input->post('hid_p_id');
		$sam_amt = $this->input->post('hid_sam_amt');
		$sam_dis_amt = $this->input->post('hid_sam_dis');
		
		
		if($sam_amt!='' and $sam_dis_amt!='')
		{
			$sql="UPDATE pooja_details SET samagree=$sam_amt,sam_amt_disc=$sam_dis_amt WHERE pooja_id=$p_id";
			$this->db->query($sql);
		}
		else
		{
			if($sam_amt!='')
			{
				$sql="UPDATE pooja_details SET samagree=$sam_amt WHERE pooja_id=$p_id";
				$this->db->query($sql);
			}
			else if($sam_dis_amt!='')
			{
				$sql="UPDATE pooja_details SET sam_amt_disc=$sam_dis_amt WHERE pooja_id=$p_id";
				$this->db->query($sql);
			}
		}
		
		
	}
	
	public function fetch_indi($id)	
	{	
		$query = $this->db->query("select * from pooja_details where pooja_id=$id");
		
		return $query->result();
	}
	
	
	public function slider_done()
	{
		
		$title1 = $_POST['title1'];
		$title2 = $_POST['title2'];
		
		
		// slider2
		
		$sql = "select images_vals from slider_tab where sr_no=1";
		$query = $this->db->query($sql);
		$res = $query->result();
		
		$arr1 = explode(",",$res[0]->images_vals);
		
		$sl1img1 = $_POST['sl1_img1'];
		$sl1img2 = $_POST['sl1_img2'];
		$sl1img3 = $_POST['sl1_img3'];
		$sl1img4 = $_POST['sl1_img4'];
		$sl1img5 = $_POST['sl1_img5'];
		$sl1img6 = $_POST['sl1_img6'];
		
		$str1 = '';
		
		if($sl1img1 != 'Select')
			$str1 .= $sl1img1.',';
		else
			$str1 .= $arr1[0].',';
		
		
		if($sl1img2 != 'Select')
			$str1 .= $sl1img2.',';
		else
			$str1 .= $arr1[1].',';
		
		
		if($sl1img3 != 'Select')
			$str1 .= $sl1img3.',';
		else
			$str1 .= $arr1[2].',';
		
		
		if($sl1img4 != 'Select')
			$str1 .= $sl1img4.',';
		else
			$str1 .= $arr1[3].',';
		
		
		if($sl1img5 != 'Select')
			$str1 .= $sl1img5.',';
		else
			$str1 .= $arr1[4].',';
		
		
		if($sl1img6 != 'Select')
			$str1 .= $sl1img6.',';
		else
			$str1 .= $arr1[5];
			
		
		// slider2
		$sql2 = "select images_vals from slider_tab where sr_no=2";
		$query2 = $this->db->query($sql2);
		$res2 = $query2->result();
		
		$arr2 = explode(",",$res2[0]->images_vals);
		
		$sl2img1 = $_POST['sl2_img1'];
		$sl2img2 = $_POST['sl2_img2'];
		$sl2img3 = $_POST['sl2_img3'];
		$sl2img4 = $_POST['sl2_img4'];
		$sl2img5 = $_POST['sl2_img5'];
		$sl2img6 = $_POST['sl2_img6'];
		
		
		$str2 = '';
		
		if($sl2img1 != 'Select')
			$str2 .= $sl2img1.',';
		else
			$str2 .= $arr2[0].',';
		
		
		if($sl2img2 != 'Select')
			$str2 .= $sl2img2.',';
		else
			$str2 .= $arr2[1].',';
		
		
		if($sl2img3 != 'Select')
			$str2 .= $sl2img3.',';
		else
			$str2 .= $arr2[2].',';
		
		
		if($sl2img4 != 'Select')
			$str2 .= $sl2img4.',';
		else
			$str2 .= $arr2[3].',';
		
		
		if($sl2img5 != 'Select')
			$str2 .= $sl2img5.',';
		else
			$str2 .= $arr2[4].',';
		
		
		if($sl2img6 != 'Select')
			$str2 .= $sl2img6;
		else
			$str2 .= $arr2[5];
			
		
		$this->db->query("update slider_tab set sub_title='$title1',images_vals='$str1' where sr_no=1");
		$this->db->query("update slider_tab set sub_title='$title2', images_vals='$str2' where sr_no=2");
		
	}
	
	public function slider_data()
	{
		$query = $this->db->query("select * from slider_tab");
		$res = $query->result();
		
		$ind = 1;
		foreach($res as $re)
		{
			$str = $re->images_vals;
			$my_array = explode(",",$str);
		
			for($i=0;$i<=5;$i++)
			{
				$n = $my_array[$i];
				$sql = "select * from pooja_details where pooja_id=".$n;
				$q = $this->db->query($sql);
				$data['sl'.$ind.'pic'.$i] = $q->result();
			}
			$ind++;
		}
		$q1 = $this->db->query("select * from slider_tab where sr_no=1");
		$data['sl1_title'] = $q1->result();
		
		$q2 = $this->db->query("select * from slider_tab where sr_no=2");
		$data['sl2_title'] = $q2->result();
		
		$q3 = $this->db->query("select * from event");
		$data['images'] = $q3->result();
		
		return $data;
	}

}
?>
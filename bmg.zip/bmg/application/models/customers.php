 <?php

class customers extends CI_Model
{
	public function fetch_customer()
	{
	
		$query = $this->db->query("select * from user_info where posts!='admin' and posts!='portal admin'");
		
		return $query->result();
	}
	
	public function fetch_history()
	{
		$user_id = $this->input->post('user_id');
		
		$query = $this->db->query("SELECT * FROM enquiry_table WHERE u_id=$user_id");
		
		$query2 = $this->db->query("select * from user_info where user_id=".$user_id);
		
		$data=array(
					"values"=>$query->result(),
					"values2"=>$query2->result()
					);
		return $data;
	}
	
	public function fetch_rejection()
	{
		$current_rec = $this->session->userdata("user_data");
		$user_id = $current_rec[0]->user_id;
		
		$query = $this->db->query("SELECT * FROM enquiry_table WHERE u_id=$user_id AND enq_status=0");
		
		$data=array(
					"values"=>$query->result()
					);
		return $data;
	}
	
	public function fetch_rejection_all()
	{
		// $query = $this->db->query("SELECT enquiry_table.*,user_info.* FROM enquiry_table,user_info WHERE enq_status=0 AND u_id=user_id");
		$query = $this->db->query("SELECT enquiry_table.* FROM enquiry_table WHERE enq_status=0");
		
		$data=array(
					"values"=>$query->result()
					);
		return $data;
	}
	
	public function fetch_show_pendings()
	{
		// $query = $this->db->query("SELECT enquiry_table.*,user_info.* FROM enquiry_table,user_info WHERE enq_status=2 AND u_id=user_id");
		$query = $this->db->query("SELECT enquiry_table.* FROM enquiry_table WHERE enq_status=2");
		
		$data=array(
					"values"=>$query->result()
					);
		return $data;
	}
	
	public function fetch_enquiry_customer()
	{
		$current_rec = $this->session->userdata("user_data");
		$user_id = $current_rec[0]->user_id;
		
		$sql = "SELECT * FROM enquiry_table WHERE u_id=$user_id AND enq_status=1";
		$query2 = $this->db->query($sql);
		
		$data=array(
					"values2"=>$query2->result()
					);
		
		return $data;
	}
	
	public function fetch_order_customer()
	{
		$current_rec = $this->session->userdata("user_data");
		$user_id = $current_rec[0]->user_id;
		
		$sql = "SELECT enquiry_table.*,pooja_order.* FROM enquiry_table,pooja_order WHERE u_id=$user_id AND enq_status=3 AND enquiry_table.enq_id=pooja_order.enq_id";
		$query = $this->db->query($sql);
		
		$data=array(
					"values"=>$query->result()
					);
		
		return $data;
	}
	
	public function fetch_dash_order()
	{
		$current_rec = $this->session->userdata("user_data");
		$user_id = $current_rec[0]->user_id;
		
		$sql = "SELECT enquiry_table.* FROM enquiry_table WHERE enq_status=2 AND u_id=$user_id";
		$query2 = $this->db->query($sql);

		$data=array(
					"values2"=>$query2->result()
					);
		
		return $data;
	}
	
	public function customer_history()
	{
		
		$current_rec = $this->session->userdata("user_data");
		$user_id = $current_rec[0]->user_id;
		
		// enq_status=0 if enquiry rejected
		// enq_status=2 if enquiry confirmed
		// change this enq_status=2 as enq_status=3 when payment gateway connect
		$sql = "SELECT * FROM enquiry_table WHERE u_id=$user_id AND (enq_status=0 OR enq_status=4)";
		$query = $this->db->query($sql);
		
		
		$data=array(
					"values2"=>$query->result()
					);
		return $data;
	}
	
	public function my_profile()
	{
		$current_rec = $this->session->userdata("user_data");
		$user_id = $current_rec[0]->user_id;
		
		$query = $this->db->query("select * from user_info where user_id=$user_id");
		
		return $query->result();
	}
	
	
	public function get_enq_status($enquiryid)
	{
		// $enquiryid = $this->input->post('enquiryid');
		if($enquiryid=='')
			$enquiryid=0;
		
		$query = $this->db->query("select enq_id,enq_status from enquiry_table where enq_id=".$enquiryid);
		return $query->result();
	}
	
	public function edit_profile()
	{
		$current_rec = $this->session->userdata("user_data");
		$user_id = $current_rec[0]->user_id;
		$email = $this->input->post('email');
		
		$name = $this->input->post('name');
		$mno = $this->input->post('mno');
		$add1 = $_POST['add1'];
		$add2 = $_POST['add2'];
		$add3 = $_POST['add3'];
		$add4 = $_POST['add4'];
		$add5 = $_POST['add5'];
		$add6 = $_POST['add6'];
		
		$sql="update user_info set fullname='$name', contact_no=$mno, add1='$add1', add2='$add2', add3='$add3', add4='$add4', add5='$add5', add6='$add6' where username='$email' AND user_id=$user_id";
		$this->db->query($sql);
		
		
		$password = $current_rec[0]->upassword;
		$sql="select * from user_info where username='".$email."' and upassword='".$password."'";
		$query=$this->db->query($sql);
		
		$this->session->set_userdata('user_data',$query->result());
		
		
		$this->session->set_userdata('update_profile',"Your Profile Updated Successfully.");
		redirect('customer_detail_edit/customer_profile');	
	}
	
	public function recover_pass()
	{
		$uname = $this->input->post('email');
		$v = '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/';
		
		if(!preg_match($v,$uname))
		{
			$this->session->set_userdata('recover_pass_sendmail',"Invalid Mail Id. Please try again.");
			redirect('Home/recover_pass');
		}
		else
		{
			$sql="select * from user_info where username='".$uname."'";
			$query=$this->db->query($sql);
			$rec=$query->result();
					
			if($rec)
			{
				/** email sending start */
				$mess="To Recover your password click here<br>http://bookmyguruji.com/index.php/Home/forget_password?uname=".$uname;
				$msg='<html>
							<table width="100%" align="center">
								<tr>
									<td align="center"><img src="http://bookmyguruji.com/img/logo.png" width="40%" height="30%"> </td>
								</tr>
								<tr>
									<td align="center">'.$mess.'<br>
									<b>Thanks & Regards,</b><br>
									<b>bookmyguruji.com</b></td>
								</tr>
							</table>
						</html>';
				
				$this->load->library('email');
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
				$this->email->to($uname); 
				$this->email->subject('bookmyguruji.com');
				$this->email->message($msg);	
				
				if($this->email->send())	/** email sending end */
				{
					$this->session->set_userdata('recover_pass_sendmail',"Check your mail inbox or spam to recover Password.");
					redirect('Home/open');				
				}
			}	
			else
			{
				$this->session->set_userdata('recover_pass_sendmail',"Mail Sending failed. Check your Email-ID.");
				redirect('Home/recover_pass');
			}
		}
	}
}

?>
<?php

	class right_model extends CI_Model
	{
		public function getRight()
		{
			$addevent = $this->input->post('addevent');
			$addimages = $this->input->post('addimages');
			
			$sql="select * from event";
			$query=$this->db->query($sql);
			$rec=$query->result();
			
			$flag = 0;
			foreach($rec as $rr)
			{
				$flag = 1;
			}
			
			if($flag == 0)
			{
				$sql="insert into event(e_id) values(1)";
				$this->db->query($sql);
			}
			
			if($addevent==1)	
			{
				$totalevent = $this->input->post('cnts');
				$str='';

				
				for($i=1;$i<=$totalevent;$i++)
				{
					$temp=$this->input->post('eventname'.$i);
					$str=$str.$temp.'#';
					echo $str;				
				}
				$str=substr($str,0,-1);
				$my_array = explode("#", $str);
				
				if($totalevent == 1 && $flag == 0)
				{
					$sql="update event set eventname='$str' where e_id=1";
					$this->db->query($sql);
				}
				else
				{
					if($flag == 0)
					{
						$sql="update event set eventname='$str' where e_id=1";
					}
					else
					{
						$sql="update event set eventname=concat(eventname,'#$str') where e_id=1";
					}
					$this->db->query($sql);
					$this->session->set_userdata('add_event',"Event Inserted Sucessfully");
				}
			}

			if($addimages==2)
			{
				// $pa=$_FILES['image1']['name'];
				// $pa1=$_FILES['image2']['name'];
				
				$config['upload_path'] = './uploads'; 
				$config['allowed_types'] = 'gif|jpg|jpeg|png';
				$this->load->library('upload', $config);
			
				// $imagedata = mysql_real_escape_string(file_get_contents($_FILES['image1']['temp_name']));
				// $imagedata1 = mysql_real_escape_string(file_get_contents($_FILES['image2']['temp_name']));
			
				if(!empty($_FILES['image1']['name']))
				{
					$pa=$_FILES['image1']['name'];
					
					$pa = str_replace(' ','_',$pa);
					
					if (!$this->upload->do_upload('image1')) 
					{ 
						echo "<script>alert('error to upload file')</script>";
					}
					else
					{
						$this->upload->data(); 
						$sql="update event set image1='$pa' where e_id=1";
						$this->db->query($sql);
						$this->session->set_userdata('add_event',"Images Inserted Sucessfully");
					}
				}
				
				if(!empty($_FILES['image2']['name']))
				{
					$pa1=$_FILES['image2']['name'];
					
					$pa1 = str_replace(' ','_',$pa1);
					
					if (!$this->upload->do_upload('image2')) 
					{ 
						echo "<script>alert('error to upload file')</script>";
					}
					else
					{
						$this->upload->data(); 
						$sql="update event set image2='$pa1' where e_id=1";
						$this->db->query($sql);
						$this->session->set_userdata('add_event',"Images Inserted Sucessfully");
					}
				}
		
				if(!empty($_FILES['image3']['name']))
				{
					$pa2=$_FILES['image3']['name'];
					
					$pa2 = str_replace(' ','_',$pa2);
					
					if (!$this->upload->do_upload('image3')) 
					{ 
						echo "<script>alert('error to upload file')</script>";
					}
					else
					{
						$this->upload->data(); 
						$sql="update event set image3='$pa2' where e_id=1";
						$this->db->query($sql);
						$this->session->set_userdata('add_event',"Images Inserted Sucessfully");
					}
				}
	
				if(!empty($_FILES['image4']['name']))
				{
					$pa3=$_FILES['image4']['name'];
					
					$pa3 = str_replace(' ','_',$pa3);
					
					if (!$this->upload->do_upload('image4')) 
					{ 
						echo "<script>alert('error to upload file')</script>";
					}
					else
					{
						$this->upload->data(); 
						$sql="update event set image4='$pa3' where e_id=1";
						$this->db->query($sql);
						$this->session->set_userdata('add_event',"Images Inserted Sucessfully");
					}
				}

				if(!empty($_FILES['image5']['name']))
				{
					$pa4=$_FILES['image5']['name'];
					
					$pa4 = str_replace(' ','_',$pa4);
					
					if (!$this->upload->do_upload('image5')) 
					{ 
						echo "<script>alert('error to upload file')</script>";
					}
					else
					{
						$this->upload->data(); 
						$sql="update event set image5='$pa4' where e_id=1";
						$this->db->query($sql);
						$this->session->set_userdata('add_event',"Images Inserted Sucessfully");
					}
				}	
				
				if(!empty($_FILES['image6']['name']))
				{
					$pa5=$_FILES['image6']['name'];
					
					$pa5 = str_replace(' ','_',$pa5);
					
					if (!$this->upload->do_upload('image6')) 
					{ 
						echo "<script>alert('error to upload file')</script>";
					}
					else
					{
						$this->upload->data(); 
						$sql="update event set image6='$pa5' where e_id=1";
						$this->db->query($sql);
						$this->session->set_userdata('add_event',"Images Inserted Sucessfully");
					}
				}	
			}		
		}
		
		public function get_images()
		{
			$this->db->select('*');
			$this->db->from('event');
			$query=$this->db->get(); 
			return $query->result();
		}
		
		public function event_delete()
		{
			$eventindex = $this->input->post('eventindex');	
			
			$sql="select eventname from event";
			$query=$this->db->query($sql);	
			$rec=$query->result();
			
			$arr = $rec[0]->eventname;			
			$str = explode("#", $arr);		
			$len = sizeof($str);	
			
			$new_str = "";
			
			for($i=0;$i<$len;$i++)
			{
				if($i != $eventindex)
				{
					$new_str = $new_str.''.$str[$i].'#';
				}
			}
			
			if($new_str != '')
			$new_str=substr($new_str,0,-1);
			
			$sql="update event set eventname='$new_str' where e_id=1";
			$this->db->query($sql);	
		}
	}

?>
<?php

class Primary_Done extends CI_Model
{
	public function create_admin($fullname,$email,$encrypted_password)
	{
		$sql="insert into user_info(fullname,username,upassword,posts) values('$fullname','$email','$encrypted_password','admin')";	
		$query=$this->db->query($sql);
	}
	
	public function fetch_all_user()
	{
		$sql="select * from user_info where posts='admin'";
		$query=$this->db->query($sql);
		
		return $query->result();
	}
	
	public function change_status($st,$data)
	{
		$sql="UPDATE user_info set access_status='$st' where user_id='$data'";
		$query=$this->db->query($sql);
	}
	
	/* public function get_slide_data()
	{
		$sr1 = "1,15,17,19,33,36";
		$sr2 = "1,15,17,19,33,36";
		
		$sql = "select * from pooja_details where pooja_id in($sr1)";
		$query = $this->db->query($sql);

		$sql2 = "select * from pooja_details where pooja_id in($sr2)";
		$query2 = $this->db->query($sql2);
		
		$data=array(
			   "values"=>$query->result(),
			   "values2"=>$query2->result()
			);
		
		return $data;
	} */
}

?>
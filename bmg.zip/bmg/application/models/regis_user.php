<?php

class regis_user extends CI_Model
{
	
	public function sign_up()
	{
		$name = $this->input->post('full_name');
		$uname = $this->input->post('email');
		$cont = $this->input->post('con');
		
		$add1 = $_POST['add1'];
		$add2 = $_POST['add2'];
		$add3 = $_POST['add3'];
		$add4 = $_POST['add4'];
		$add5 = $_POST['add5'];
		$add6 = $_POST['add6'];
		$password=sha1($_POST['upass']);
		
		$sql="select * from user_info where username='".$uname."'";
		$query1=$this->db->query($sql);
		
		if($query1->num_rows() > 0)
		{
			redirect('Home/open');
		}
		else
		{
			$sql="insert into user_info(fullname,username,upassword,contact_no,add1,add2,add3,add4,add5,add6,posts,access_status) values('$name','$uname','$password','$cont','$add1','$add2','$add3','$add4','$add5','$add6','customer','1')";
			
			$this->db->query($sql);		
			
			// set session if new record insert to redirect
			$sql="select * from user_info where username='".$uname."' and upassword='".$password."' and access_status='1'";
			$query=$this->db->query($sql);
			
			if($query->num_rows() > 0)
			{
				$this->session->set_userdata('user_data',$query->result());
				
				/* 
				$this->load->library('email');
				$this->email->set_newline("\r\n");

				$this->email->from('support@bookmyguruji.com', '');
				$this->email->to($uname); 
				$this->email->subject('BookMyGuruji');
				$msg=" Welcome in bookmyguruji.\r\n Thank you for using our service. \r\n Thanks & Regards \r\n BookMyGuruji";
				$this->email->message($msg);	
				
				if($this->email->send()) */
				
				/** email sending start */
				$msg = '<html>
							<table width="100%" align="center">
								<tr>
									<td align="center"><img src="http://bookmyguruji.com/img/logo.png" width="30%" height="20%"> </td>
								</tr>
								<tr>
									<td align="center">
										<h1>Welcome in bookmyguruji.com</h1><br>
										Thank you For Considering Us.<br>
										Thanks & Regards,<br>
										<b>bookmyguruji.com</b>
									<td>
								</tr>
						</html>';
				
				$this->load->library('email');
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
				$this->email->to($uname); 
				$this->email->subject('bookmyguruji.com');
				$this->email->message($msg);	
				
				$this->email->send();
				/** email sending end */
				
				redirect('Home/open');
			}
		}
		/* else
		{
			redirect('Home/open');
		} */
	}
	
	public function registration()
	{
		echo "in model -> regis_user/registration";
		/*$name = $this->input->post('fullname');
		$uname = $this->input->post('uname_txt');
		
		$password=sha1($_POST['upass_txt']);
		$cont = $this->input->post('cont_txt');
		
		$addr = $this->input->post('addr_txt');
		
		
		$sql="insert into user_info(fullname,username,upassword,contact_no,address,posts,access_status) values('$name','$uname','$password','$cont','$addr','customer','1')";
		
		if($this->db->query($sql))
		{
			// successfully register
			
			$this->db->select('*'); //column name in the table
			$this->db->from('user_info'); //name of the table
			$this->db->where('username',$uname);
			$this->db->where('upassword',$password);
			
			$query2 = $this->db->get();
			$this->session->set_userdata('user_data',$query2->result());

			return true;
		}
		else
		{
			// fail in registration
			echo "<script> alert('Registration Failed');</script>";
			return false;
		}*/

		
	}

	public function verify_user()
	{
	
		$uname = $this->input->post('uname');
		$password=sha1($this->input->post('upass'));
		
		
		$sql="select * from user_info where username='".$uname."' and upassword='".$password."' and posts='admin' and access_status='1'";
		
		$query=$this->db->query($sql);

		if($query->num_rows() > 0)
		{
			$this->session->set_userdata('admin_data',$query->result());
			return true;
		}
		else
		{
			$sql="select * from user_info where username='".$uname."' and upassword='".$password."' and posts='portal admin' and access_status='1'";
		
			$query=$this->db->query($sql);

			if($query->num_rows() > 0)
			{
				$this->session->set_userdata('portal_admin_data',$query->result());
				return true;
			}
			else
			{
			
					$sql="select * from user_info where username='".$uname."' and upassword='".$password."' and access_status='1'";
					
					$query=$this->db->query($sql);
					
					if($query->num_rows() > 0)
					{
						// successfully log in
						$this->session->set_userdata('user_data',$query->result());
						return true;
					}
					else
					{
						return false;
					}
			}
			
		}
	}
	
	public function final_change_pass()
	{
		$email="";
		$uname="";
		
		if($this->session->userdata('portal_admin_data'))
		{
			$uname=$this->session->userdata('portal_admin_data');
			$email=$uname[0]->username;
		}
		if($this->session->userdata('admin_data'))
		{
			$uname=$this->session->userdata('admin_data');
			$email=$uname[0]->username;
		}
		if($this->session->userdata('user_data'))
		{
			$uname=$this->session->userdata('user_data');
			$email=$uname[0]->username;
		}
		
		
		$upassold = sha1($this->input->post('oldpassword'));
		$upassnew = sha1($this->input->post('newpassword'));

		$data = array('upassword'=>$upassnew);

		$this->db->where('upassword', $upassold);
		$this->db->where('username', $email);
		$this->db->update('user_info', $data); 

		if($this->db->affected_rows() > 0)
			return true;
		/* else if($upassold == $upassnew)
			return true; */
		else
			return false;
	}
	
	public function subscribe()
	{
		$v = '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/';
		$em = $this->input->post('email1');		
		
		if(!preg_match($v,$em))
		{
			redirect('Home/open');
		}
		else
		{
			$sql="select * from newletter where email='".$em."'";		
			$query=$this->db->query($sql);	
			
			if($query->num_rows() > 0)
			{	
				redirect('Home/open');
			}
			else
			{
				$data = array
				(
					'email'=>$em
				);
				$this->db->insert('newletter',$data);
			
				/** email sending start */
				$msg = '<html>
							<table width="100%" align="center">
								<tr>
									<td align="center"><img src="http://bookmyguruji.com/img/logo.png" width="30%" height="20%"> </td>
								</tr>
								<tr>
									<td align="center">
										Thank You For Subscribing bookmyguruji.com
										<br>Thanks & Regards,<br>
										<b>bookmyguruji.com</b>
									</td>
								</tr>
						</html>';
				
				$this->load->library('email');
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
				$this->email->to($em); 
				$this->email->subject('bookmyguruji.com');
				$this->email->message($msg);	
				
				$this->email->send();
				/** email sending end */
				
				// $this->session->userdata('news_letter_msg',"Thank You For Subscribing Newsletter");
				redirect('Home/open');
			}
		}
	}
	
	public function recover_pass()
	{
		$email = $this->input->post('pass_recover');
		
		$upassold = sha1($this->input->post('upass'));
		// $upassnew = sha1($this->input->post('newpassword'));
		
		
		$sql="UPDATE user_info SET upassword='$upassold' where username='$email'";
		
		if($query=$this->db->query($sql))
		{
			$this->session->set_userdata('recover_password',"Your Password Recovered Successfully.");
			redirect('Home/open');
			return true;
		}	
		else
			return false;
	}
	
	public function send_mail()
	{
		$to = $this->input->post('to');
		$f = $this->input->post('file');
		$msg = $this->input->post('msg');
		
		
		
		/** email sending start */
		$msg = '<html>'.$msg.'<br><b style="color:black;">bookmyguruji.com</b></html>';
		
		$this->load->library('email');
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		$this->email->from('support@bookmyguruji.com', 'bookmyguruji.com');
		$this->email->to($to); 
		$this->email->subject('bookmyguruji.com');
		$this->email->message($msg);	
		
		
		if($this->email->send()) 		/** email sending end */
			redirect('Home/open');
		else 
			redirect('Home/open');
	}
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<script type="text/javascript">
			
			function set_action(v1,v2)
			{
				document.forms["viewform"]["hidd_enq_id"].value = v1;
				
				cnf = prompt("Please enter reason for reject pooja", "");
					
				if(cnf != null && cnf != "")
				{
					document.forms["viewform"]["hidd_msg"].value = cnf;
					document.forms["viewform"].submit();
				}
				else
				{
					return;
				}
			}
   
			
		</script>
	</head>
	<body>
		<div class="span9"></br>
			<center><h4>Order Details</h4></center>
			<div style="width: 100%; height:310px; overflow-y: auto;">
			<table class="table table-bordered table-fixed">
				<tr class="active" align="center" size="auto">
					<th class="active"><h6><p>Sr. No</p></h6></th>
					<th class="active"><h6><p>Order ID</p></h6></th>
					<th class="active"><h6><p>Enquiry ID</p></h6></th>
					<th class="active"><h6><p>Payment ID</p></h6></th>
					<th class="active"><h6><p>Booking Details</p></h6></th>
					<th class="active"><h6><p>Pooja Details</p></h6></th>
					<th class="active"><h6><p>Action</p></h6></th>
				</tr>
				
				<form  name="viewform" action= "<?php echo base_url() ?>index.php/order_detail_edit/reject_order" method="post">
					
					<input type="hidden" name="hidd_enq_id" id="hidd_enq_id"/>
					<input type="hidden" name="hidd_msg" id="hidd_msg">
					<?php 
					
					$no = 1;
					foreach($values as $value)//order
					{
						if($no%2==1)
						{
					?>
							<tr class="info" align = "center">
								<td><?=$no?></td>
								<td><?=$value->order_id?></td>
								<td><?=$value->enq_id?></td>
								<td><?=$value->pay_id?></td>
								<td><?=date("d/m/Y", strtotime($value->booking_date))?><br><?=$value->book_time?></td>
								<td>
									<center>
									<p><b><?=ucwords($value->pj_name)?></b>
									<?php
										$sam_st = $value->sam_status;
										
										$ind = $value->poojas;
												
										if($ind >= 1 and $ind <= 14)
										{
											echo "(Home Pooja)";
										}
										else if($ind >= 15 and $ind <= 19)
										{
											echo "(Office Pooja)";
										}
										else if($ind >= 20  and $ind <= 30)
										{
											echo "(Festival Pooja)";
										}
										else if($ind >= 31 and $ind <= 37)
										{
											echo "(Functional Pooja)";
										}
										else
										{
											echo "(Other Pooja)";
										}
										echo "<br>Rs. ".$value->pooja_amt."<br>";
										
										if($sam_st == 'yes')
											echo "(with samagree)";
										else
											echo "(without samagree)";
											
										echo "</p>";
									?>
									</center>
								</td>
								<td><input class="btn btn-warning" type="button" value="Reject" onclick="set_action(<?=$value->enq_id?>)"></td>
							</tr>
					<?php
						}
						else
						{
					?>
							<tr align = "center">
								<td><?=$no?></td>
								<td><?=$value->order_id?></td>
								<td><?=$value->enq_id?></td>
								<td><?=$value->pay_id?></td>
								<td><?=date("d/m/Y", strtotime($value->booking_date))?><br><?=$value->book_time?></td>
								<td>
									<center>
									<p><b><?=ucwords($value->pj_name)?></b>
									<?php
										$sam_st = $value->sam_status;
										
										$ind = $value->poojas;
												
										if($ind >= 1 and $ind <= 14)
										{
											echo "(Home Pooja)";
										}
										else if($ind >= 15 and $ind <= 19)
										{
											echo "(Office Pooja)";
										}
										else if($ind >= 20  and $ind <= 30)
										{
											echo "(Festival Pooja)";
										}
										else if($ind >= 31 and $ind <= 37)
										{
											echo "(Functional Pooja)";
										}
										else
										{
											echo "(Other Pooja)";
										}
										echo "<br>Rs. ".$value->pooja_amt."<br>";
										
										if($sam_st == 'yes')
											echo "(with samagree)";
										else
											echo "(without samagree)";
											
										echo "</p>";
									?>
									</center>
								</td>
								<td><input class="btn btn-warning" type="button" value="Reject" onclick="set_action(<?=$value->enq_id?>)"></td>
							</tr>
					<?php
						}
						
						$no++;
					}
					
					if($no==1)
					{
						echo "<tr><th colspan='8'><b style='color:red;'>No Record Found</b></th></tr>";
					}
					
					?>	
				</form>										
			</table>
		</div>						
		</div>						
	</div>						
	</div>						
	</div>						
	</body>
</html>
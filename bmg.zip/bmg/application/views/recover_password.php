<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		
		<!-- Date picker css & js-->
		<link href="<?php echo base_url(); ?>css/runnable.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>js/script.js"></script>	
		<script src="<?php echo base_url(); ?>js/script1.js"></script>	

		<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css" />
		<script src="<?php echo base_url(); ?>js/jquery-1.9.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
		<style>
		#pn:hover
		{
			border: 1px solid #FAA732;
		}
		#sl:hover
		{
			background-color: #FFE6CC;
		}
		</style>	
		
		<script language="javascript" type="text/javascript">
				function clr_msg()
				{
					document.getElementById('txt1').innerHTML = "";
				}
				
				function checkEmail(emailId) {
					if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailId)){
					// document.write("You have entered valid email.");
					return true;
					}    
					return false;
					}

					function ValidateEmail(){
					
						var emailID=document.getElementById("email");

						/* if ((emailID.value==null)||(emailID.value=="")){
							alert("Please Enter your Email ID")
							emailID.focus()
							return false
						}
 */
						if (checkEmail(emailID.value)==false){
							emailID.value=""
							// alert("Invalid Email Adderess");
							document.getElementById('txt1').innerHTML = "&nbsp; Invalid Email Adderess.";
							emailID.focus()
							return false
						}
							return true
					 }
					 
				function submit_form()
				{
					var email=document.getElementById("email").value;
					
					if(email=="")
					{
						// alert("Please Enter your Email ID");
						document.getElementById('txt1').innerHTML = "&nbsp; Please Enter your Email ID.";
						return false;
					}
					else
					{
						document.forms['recover_password'].submit();
						return true;
					}
				}				
		</script>
		
	
	</head>
		<?php
			if($this->session->userdata('recover_pass_sendmail'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('recover_pass_sendmail').'")';
				echo '</script>'; 
				$this->session->unset_userdata('recover_pass_sendmail');
			}
		?>
<body>
	<br>
	<div id="wrapper" class="container">
		<section class="main-content">				
			<div class="row">
				<div class="span3"></div>
				<div class="span6">
				</br>				
					<h4 class="title"><span class="text"><strong>Recover </strong> Password</span></h4>
					<form class="form-stacked" name="recover_password" method="post" action="<?php echo base_url() ?>index.php/Home/recover_password">
						<fieldset>
							
							<div class="control-group">
								<label class="control-label"><b>Email Id</b></label>
								<div class="controls">
									<input type="text" placeholder="Email Id" class="span3" name="email" id="email" onchange="ValidateEmail()" onkeypress="clr_msg()">
									<input type="hidden" name="recoveremail" id="recoveremail">
									<font size='2' color='red'><span id="txt1"></span></font>
								</div>
							</div>
							
							<br>
							<div class="actions">
								<input tabindex="9" class="btn btn-success" type="button" onclick="submit_form()" value="Submit">
								&nbsp; &nbsp; 
								<input tabindex="9" class="btn btn-warning" type="reset" value="Reset" onclick="clr_msg()">
							</div>
						</fieldset>
					</form>					
				</div>
				<div class="span3">
					<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
					<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center>
					<br>
				</div>
			</div>				
		</section>			
	</div>
</body>					
</html>
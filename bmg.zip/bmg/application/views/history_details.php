<!DOCTYPE html>
<html lang="en">
	<body>
	<br>			
	<div id="wrapper" class="container">
		
		<div class="row">
			<div class="span1"></div>
			<div class="span10">
				</br>
				<table width="100%">
					<tr>
						<td><h6>Name </h6></td>
						<td><input type="text" value="<?=$values2[0]->fullname?>" style="background-color: white;" class="span3" disabled></td>
						<td><h6>Contact No</h6></td>
						<td><input type="text" value="<?=$values2[0]->contact_no?>" style="background-color: white;" class="span3" disabled></td>
					</tr>
					<tr>
						<td><h6>Email </h6></td>
						<td><input type="text" value="<?=$values2[0]->username?>" style="background-color: white;" class="span3" disabled></td>
						<td><h6>Address </h6></td>
						<td><textarea style="background-color:white; resize:none;" class="span3" rows="3" disabled><?=$values2[0]->add1.','.$values2[0]->add2.','.$values2[0]->add3.','.$values2[0]->add4.','.$values2[0]->add5.','.$values2[0]->add6?></textarea></td>
					</tr>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="span12">
				<h4>History Details</h4>
				<div style=" overflow: auto;">
				<table class="table table-bordered table-fixed">
					<tr class="active" size="auto">
						<th class="active"><h6><p>Sr. No</p></h6></th>
						<th class="active"><h6><p>Enquiry ID</p></h6></th>
						<th class="active"><h6><p>Enquiry Date</p></h6></th>
						<th class="active"><h6><p>Booking Details</p></h6></th>
						<th class="active"><h6><p>Pooja Details</p></h6></th>
						<th class="active"><h6><p>Comments</p></h6></th>
						<th class="active"><h6><p>Remark</p></h6></th>
						<th class="active"><h6><p>Reject By</p></h6></th>
						<th class="active"><h6><p>Status</p></h6></th>
					</tr>
					<?php
					$no=1;
					foreach($values as $value)
					{
						if($no%2==1)
						{
					?>
							<tr class="info">
								<td><?=$no?></td>
								<td><?=$value->enq_id?></td>
								<td><?=date("d/m/Y", strtotime($value->enq_date))?></td>
								<td>
									<?php
										if($value->booking_date != NULL)
											echo date("d/m/Y", strtotime($value->booking_date));
									?>
									<br><?=$value->book_time?>
								</td>
								<?php
									$sam_sta = $value->sam_status;
									if($sam_sta == 'yes')
										$st_msg = "with samagri";
									else
										$st_msg = "without samagri";
								?>
								<td><p><?=$value->pj_name?></p><?=$st_msg?><br>(<?=$value->pooja_type?>)</td>
								<td><?=$value->comment?></td>
								<td><?=$value->remark?></td>
								<td><?=$value->reject_by?></td>
								<?php
									$st_no = $value->enq_status;
									$st_str = '';
									
									if($st_no == 0)
										$st_str = 'Reject';
									else if($st_no == 1)
										$st_str = 'Enquiry';
									else if($st_no == 2)
										$st_str = 'Confirm';
									else if($st_no == 3)
										$st_str = 'Paid';
									else if($st_no == 4)
										$st_str = 'Done';
								?>
								<td><?=$st_str?></td>
							</tr>
					<?php
						}
						else
						{
					?>
							<tr>
								<td><?=$no?></td>
								<td><?=$value->enq_id?></td>
								<td><?=date("d/m/Y", strtotime($value->enq_date))?></td>
								<td>
									<?php
										if($value->booking_date != NULL)
											echo date("d/m/Y", strtotime($value->booking_date));
									?>
									<br><?=$value->book_time?>
								</td>
								<?php
									$sam_sta = $value->sam_status;
									if($sam_sta == 'yes')
									{
										$st_msg = "with samagri";
									}
									else
									{
										$st_msg = "without samagri";
									}
								?>
								<td><p><?=$value->pj_name?></p><?=$st_msg?><br>(<?=$value->pooja_type?>)</td>
								<td><?=$value->comment?></td>
								<td><?=$value->remark?></td>
								<td><?=$value->reject_by?></td>
								<?php
									$st_no = $value->enq_status;
									$st_str = '';
									
									if($st_no == 0)
										$st_str = 'Reject';
									else if($st_no == 1)
										$st_str = 'Enquiry';
									else if($st_no == 2)
										$st_str = 'Confirm';
									else if($st_no == 3)
										$st_str = 'Paid';
									else if($st_no == 4)
										$st_str = 'Done';
								?>
								<td><?=$st_str?></td>
							</tr>
					<?php
						}
						$no++;
					}
					
					if($no == 1)
					{
						echo "<tr><th colspan='8'><b style='color:red;'>No Record Found</b></th></tr>";
					}
					?>
				</table>
				</div>
			</div>
		</div>
	</div>
	</body>
</html>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
		
		<script type="text/javascript">
			
			// changes 20-01-15
			function set_action(v1)
			{
				var v=document.forms["view_history"]["user_id"].value = v1;
				document.forms["view_history"].submit();
			}
			// end 
			
			function update_page()
			{
				var my_id = document.forms["viewform"]["sel_page_no"].value;
				document.forms["viewform"]["hid_page_number"].value = my_id;
				document.forms["viewform"].submit();
			}
   
			
		</script>
	</head>

	<body>
		<br>
	<div id="wrapper" class="container">
		<div class="row">
		<br>
		<div class="span12">
			<h4>CUSTOMER DETAILS</h4>
			<div style="overflow: auto; height:600px; width:auto">
				<table class="table table-bordered table-fixed">
					<tr class="active" align="center" >
						<th class="active"><h6><p> Sr. No </p></h6></th>
						<th class="active"><h6><p> Customer Name </p></h6></th>
						<th class="active"><h6><p> Contact No. </p></h6></th>
						<th class="active"><h6><p> Email ID </p></h6></th>
						<th class="active"><h6><p> Address </p></h6></th>
						<th class="active"><h6><p> View History </p></h6></th>
					</tr>
						
					<form  name="view_history" action= "<?php echo base_url() ?>index.php/customer_detail_edit/show_history" method="post">
						<input type="hidden" name="user_id" id="user_id"/>
					<?php
						
						$query = $this->db->query("select * from user_info where posts!='admin' and posts!='portal admin'");
						$arr = $query->result();
						
						
						$total_recs = count($values);
						
						$no = 1;
						foreach($arr as $value)
						{
							
								if($no%2==1)
								{
						?>			
									<tr class="info" align = "center">
										<td><?=$no?></td>
										<td><?=$value->fullname?></td>
										<td><?=$value->contact_no?></td>
										<td><?=$value->username?></td>
										<td><?=$value->add1.','.$value->add2.','.$value->add3.','.$value->add4.','.$value->add5.','.$value->add6?></td>
										<td>
											<input class="btn btn-success" type="button" value="View" onclick="set_action('<?=$value->user_id?>')">
										</td>
									</tr>
								
						<?php
								}
								else
								{
						?>
									<tr align = "center">
										<td><?=$no?></td>
										<td><?=$value->fullname?></td>
										<td><?=$value->contact_no?></td>
										<td><?=$value->username?></td>
										<td><?=$value->add1.','.$value->add2.','.$value->add3.','.$value->add4.','.$value->add5.','.$value->add6?></td>
										<td>
											<input class="btn btn-success" type="button" value="View" onclick="set_action('<?=$value->user_id?>')">
										</td>
									</tr>
						<?php
								}
							$no++;
						}
						
						if($no == 1)
						{
							echo "<tr><th colspan='6'><b style='color:red;'>No Record Found</b></th></tr>";
						}
						
						?>
						</form>
				</table>
			</div>
		</div>
	</div>
	</body>
</html>
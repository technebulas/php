<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Pandit site</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
		
		<script type="text/javascript">
			
			function updatefun(v1)
			{
				
				var txt3 = document.getElementById("sam_txt"+v1).value;
				var txt4 = document.getElementById("sam_dis_txt"+v1).value;
				
				document.forms["editform"]["hid_p_id"].value    = v1;
				document.forms["editform"]["hid_sam_amt"].value = txt3;
				document.forms["editform"]["hid_sam_dis"].value = txt4;
				
				document.forms["editform"].submit();
				
			}
   
			function onlyNos(e, t)
		{
            try
			{

                if (window.event) {

                    var charCode = window.event.keyCode;

                }

                else if (e) {

                    var charCode = e.which;

                }

                else { return true; }

                if (charCode > 31 && (charCode < 48 || charCode > 57)) {

                    return false;

                }

                return true;

            }

            catch (err) {

                alert(err.Description);

            }				
        }	
		</script>
	</head>

	<body>
		<br>
	<div id="wrapper" class="container">
		<div class="row">
		<br>
		<div class="span2">&nbsp;</div>
		<div class="span8">
		<h4>SAMAGRI DETAILS</h4>
		<div style=" overflow: auto;">
		<table class="table table-bordered table-fixed">
						
			<tr class="active" align="center" size="auto">
				<th class="active"><h6><p>Sr No</p></h6></th>
				<th class="active"><h6><p>Pooja Name</p></h6></th>
				
				<th class="active"><h6><p>Samagri Amount</p></h6></th>
				<th class="active"><h6><p>New Samagri amount</p></h6></th>
				<th class="active"><h6><p>Discount (%)</p></h6></th>
				<th class="active"><h6><p>New Discount (%)</p></h6></th>
				
				<th class="active"><h6><p>Action</p></h6></tH>
			</tr>
			
			<form  name="editform" action= "<?php echo base_url() ?>index.php/pooja_detail_edit/samagree_fees_update" method="post">
			
				<input type="hidden" name="hid_p_id" id="hid_p_id">
				<input type="hidden" name="hid_sam_amt" id="hid_sam_amt">
				<input type="hidden" name="hid_sam_dis" id="hid_sam_dis">
			
				<?php
				
				$no = 1;
				foreach($values as $value)
				{
					if($no%2==1)
					{
				?>
					<tr class="info">
						<td><?=$no?></td>
						<td><?=$value->pooja_name?></td>

						<td><?=$value->samagree?></td>
						<td><input type="text" onkeypress="return onlyNos(event,this);" class="span1" name="sam_txt<?=$value->pooja_id?>" id="sam_txt<?=$value->pooja_id?>"></td>
						<td><?=$value->sam_amt_disc?></td>
						<td><input type="text" onkeypress="return onlyNos(event,this);" class="span1" name="sam_dis_txt<?=$value->pooja_id?>" id="sam_dis_txt<?=$value->pooja_id?>"></td>

						<td>
								<div class = "col-md-3">
									<a href = "javascript:updatefun('<?=$value->pooja_id?>')">
										<button type="button" class="btn btn-success">Update</button>
									</a>
								</div>
						</td>
					</tr>
				<?php
					}
					else
					{
				?>
					<tr>
						<td><?=$no?></td>
						<td><?=$value->pooja_name?></td>

						<td><?=$value->samagree?></td>
						<td><input type="text" onkeypress="return onlyNos(event,this);" class="span1" name="sam_txt<?=$value->pooja_id?>" id="sam_txt<?=$value->pooja_id?>"></td>
						<td><?=$value->sam_amt_disc?></td>
						<td><input type="text" class="span1" onkeypress="return onlyNos(event,this);" name="sam_dis_txt<?=$value->pooja_id?>" id="sam_dis_txt<?=$value->pooja_id?>"></td>

						<td>
								<div class = "col-md-3">
									<a href = "javascript:updatefun('<?=$value->pooja_id?>')">
										<button type="button" class="btn btn-success" onclick="">Update</button>
									</a>
								</div>
						</td>
					</tr>
				<?php
					}
					$no++;
				}
				
				?>	

			</form>										

		</table>
		</div>
		</div>
		</div>
	</div>

	</body>
</html>
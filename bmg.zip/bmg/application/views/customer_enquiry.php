<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Pandit site</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
		
		<script type="text/javascript">
			
			function check_final(v1,v2)
			{
				if(v2==1)
				{
					document.getElementById("rej_ch"+v1).checked = false;
					document.getElementById("con_ch"+v1).checked = true;
				}
				else if(v2==2)
				{
					document.getElementById("rej_ch"+v1).checked = true;
					document.getElementById("con_ch"+v1).checked = false;				
				}
				
				// document.forms["editform"]["hid_p_id"].value    = v1;
				// document.forms["editform"]["hid_pan_amt"].value = txt1;
				// document.forms["editform"]["hid_sam_amt"].value = txt2;
				// document.forms["editform"].submit();
				
			}
   
			
		</script>
	</head>
	<body>
		<?php
			if($this->session->userdata('enq_ins_msg'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('enq_ins_msg').'")';
				echo '</script>'; 
				$this->session->unset_userdata('enq_ins_msg');
			}
		?>
		<div class="span9">
			<!--
			<div class="row">
				<div class="span9">
					<br>
					<div class="control-group">
						<div class="controls">
							<b>Sort By : </b>
							<input type="radio" name="sorting" value="registration">Registration Date
							&nbsp; &nbsp;
							<input type="radio" name="sorting" value="order">Order Date
						</div>
					</div>
				</div>
			</div>
			-->
			<div class="row">
				<div class="span9">
				<br>
					<center><h4>Enquiry Details</h4></center>
					<div style="width: 100%; height:310px; overflow-y: auto;">
					<table class="table table-bordered table-fixed" style="overflow-y:auto;">
						<tr class="active" align="center" size="auto">
							<th class="active"><h6><p>Sr. No</p></h6></th>
							<th class="active"><h6><p>Enq. ID</p></h6></th>
							<th class="active"><h6><p>Reg. Date</p></h6></th>
							<th class="active"><h6><p>Order date</p></h6></th>
							<th class="active"><h6><p>Pooja Name</p></h6></th>
							<th class="active"><h6><p>Pooja Price</p></h6></th>
							<th class="active"><h6><p>Other</p></h6></th>
							<th class="active"><h6><p>Comment</p></h6></th>
						</tr>
						
						<?php 
						
						$no = 1;
						foreach($values2 as $value)
						{
							$ed = date("d/m/Y", strtotime($value->enq_date));
							$date1 = date("d/m/Y", strtotime($value->s_date));
							$date2 = date("d/m/Y", strtotime($value->e_date));
							
						?>
							<form name="view_enquiry" action="<?php echo base_url() ?>index.php/order_detail_edit/towards_update_enquiry" method="post">

								<input type="hidden" name="hidd_enq_id" value="<?=$value->enq_id?>">
								<input type="hidden" name="hidd_pooja_id" value="<?=$value->poojas?>">
								<input type="hidden" name="hidd_pooja_type" value="<?=$value->pooja_type?>">
								
							<?php
								if($no%2==1)
								{
							?>
								<tr class="info" align = "center">
									<td><?=$no?></td>
									<td><?=$value->enq_id?></td>
									<td><?=$ed?></td>

									<?php
									if($date1==$date2)
									{
									?>
										<td><?=$date1?></td>
									<?php
									}
									else
									{
									?>
										<td><?=$date1?> to<br><?=$date2?></td>
									<?php
									}
									?>

									<td><?=$value->pj_name?></td>
									<?php
										$sam_sta = $value->sam_status;
										
										if($sam_sta == 'yes')
										{
									?>
									<td>with samagri<br>Rs. <?=$value->pooja_amt?></td>
									<?php
										}
										else
										{
									?>
									<td>without samagri<br>Rs. <?=$value->pooja_amt?></td>
									<?php
										}
									
									
										$myArray2 = explode(',',$value->other_acts);
										// print_r ($myArray2);
										$len = count($myArray2);
										$sstr = '';
										for($incr=0;$incr<$len;$incr++)
										{
											if($myArray2[$incr] == 1)
												$sstr = $sstr."Catering,";
											else if($myArray2[$incr] == 2)
												$sstr = $sstr."Decoration,";
											else if($myArray2[$incr] == 3)
												$sstr = $sstr."Venue,";
										}
										
										$sstr = substr($sstr,0,-1);
									?>
									<td><?=$sstr?></td>
									<td><?=$value->comment?></td>
								</tr>
							<?php
								}
								else
								{
							?>
								<tr align = "center">
									<td><?=$no?></td>
									<td><?=$value->enq_id?></td>
									<td><?=$ed?></td>

									<?php
									if($date1==$date2)
									{
									?>
										<td><?=$date1?></td>
									<?php
									}
									else
									{
									?>
										<td><?=$date1?> to<br><?=$date2?></td>
									<?php
									}
									?>

									<td><?=$value->pj_name?></td>
									<?php
										$sam_sta = $value->sam_status;
										
										if($sam_sta == 'yes')
										{
									?>
									<td>with samagri<br>Rs. <?=$value->pooja_amt?></td>
									<?php
										}
										else
										{
									?>
									<td>without samagri<br>Rs. <?=$value->pooja_amt?></td>
									<?php
										}
									?>
									<?php
									
										$myArray2 = explode(',',$value->other_acts);
										// print_r ($myArray2);
										$len = count($myArray2);
										$sstr = '';
										for($incr=0;$incr<$len;$incr++)
										{
											if($myArray2[$incr] == 1)
												$sstr = $sstr."Catering,";
											else if($myArray2[$incr] == 2)
												$sstr = $sstr."Decoration,";
											else if($myArray2[$incr] == 3)
												$sstr = $sstr."Venue,";
										}
										
										$sstr = substr($sstr,0,-1);
									?>
									<td><?=$sstr?></td>
									<td><?=$value->comment?></td>
								</tr>
							<?php
								}
							?>
							</form>
						<?php
							
							$no++;
						}
						
						if($no==1)
						{
							echo "<tr><th colspan='8'><b style='color:red;'>No Record Found</b></th></tr>";
						}
						
						?>
						
					</table>
				</div>						
				</div>						
			</div>						
		</div>						
		</div>						
		</div>						
		</div>						
	</body>
</html>
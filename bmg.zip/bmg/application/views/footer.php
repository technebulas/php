<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>
	</head>
    <body>	
		<div id="wrapper" class="container">
		<div class="row">
			<section id="footer-bar">
				<div class="row">
				<div class="span8">
				<div class="row">
					<div class="span2">
						<h4 style="color:white"><b>&nbsp; &nbsp;&nbsp;Information</b></h4>
						<ul class="nav">
							<li><a href="<?php echo base_url(); ?>index.php/Home/aboutus" style="text-decoration:none"><b>About Us</b></a></li>
							<li><a href="<?php echo base_url(); ?>index.php/Home/privacypolicy" style="text-decoration:none"><b>Privacy Policy</b></a></li>
							<li><a href="<?php echo base_url(); ?>index.php/Home/cancellation" style="text-decoration:none"><b>Cancellation & Returns</b></a></li>
							<li><a href="<?php echo base_url(); ?>index.php/Home/termsofuse" style="text-decoration:none"><b>Terms Of Use</b></a></li>							
						</ul>
					</div>
					
					<div class="span2">
						<h4 style="color:white"><b>&nbsp; &nbsp;&nbsp;Client Service</b></h4>
						<ul class="nav">
							<li><a href="<?php echo base_url(); ?>index.php/Home/contactus" style="text-decoration:none"><b>Contact Us</b></a></li>
							<li><a href="<?php echo base_url(); ?>index.php/Home/cancellation" style="text-decoration:none"><b>Returns</b></a></li>
							<li><a href="<?php echo base_url(); ?>index.php/Home/trackorder" style="text-decoration:none"><b>Track Order</b></a></li>
						</ul>
					</div>
					
					<div class="span2">
						<h4 style="color:white"><b>&nbsp; &nbsp;&nbsp;Extras</b></h4>
						<ul class="nav">
							<li><a href="#" style="text-decoration:none"><b>Offers</b></a></li>
							<li><a href="#" style="text-decoration:none"><b>Affiliates</b></a></li>
							<li><a href="#" style="text-decoration:none"><b>Social Responsibility</b></a></li>
						</ul>
					</div>
					<div class="span2">
						<h4 style="color:white"><b>&nbsp; &nbsp;&nbsp;My Account</b></h4>
						<ul class="nav">
							<?php
								if($this->session->userdata('user_data'))
								{
							?>
								<li><a href="<?php echo base_url(); ?>index.php/customer_detail_edit/customer_records" style="text-decoration:none"><b>My Account</b></a></li>
								<li><a href="<?php echo base_url(); ?>index.php/customer_detail_edit/history_details" style="text-decoration:none"><b>Order History</b></a></li>
							<?php
								}
								else
								{
							?>
								<li><a href="<?php echo base_url(); ?>index.php/Home/register" style="text-decoration:none"><b>My Account</b></a></li>
								<li><a href="<?php echo base_url(); ?>index.php/Home/register" style="text-decoration:none"><b>Order History</b></a></li>
							<?php
								}
							?>
						</ul>
					</div>
				</div>
				</div>
					<div class="span3">
						<h4 style="color:white"><b>&nbsp; &nbsp;&nbsp;Contact Us</b></h4>
						<ul class="nav">
							<li><a style="text-decoration:none"><b>bookmyguruji.com</b></a></li>
							<li><a style="text-decoration:none"><b>Prathmesh Nagar,Flat 8,SN 12 </b></a></li>
							<li><a style="text-decoration:none"><b>Wadgaon,BK Res - 1 Phase,Pune</b></a></li>
							<li><a style="text-decoration:none"><b></b></a></li>
							<li><a style="text-decoration:none"><b>411041,Maharashtra, INDIA.</b></a></li>
							
							<li><a style="text-decoration:none"><b>Phone:- 7276995995</b></a></li>
							<li><a style="text-decoration:none"><b>Mail:support@bookmyguruji.com</b></a></li>
						</ul>
					</div>
					</div>
			</section>
			<section id="copyright">
				<div class="row">
					<div class="span7"><b><a href="<?php echo base_url(); ?>index.php/Home/privacypolicy">Privacy Policy </a>|<a href="<?php echo base_url(); ?>index.php/Home/termsofuse"> Terms & Conditions</a> © 2015 BookMyGuruji All Rights Reserved.</b></div>
					<div class="span4" style="margin-left:50px;"><b>Design & Developed By <a href="http://technebulas.com/" target="_blank"> Tech-Nebulas</a></b></div>
				</div>
					<center><b style=" color:#996600;">The website is best experienced on the following version (or higher) of Chrome 31, Firefox 26, Safari 6 and Internet Explorer 9 browsers.</b></center>
			</section>
		</div>
		</div>
		<script src="themes/js/common.js"></script>	
    </body>
</html>
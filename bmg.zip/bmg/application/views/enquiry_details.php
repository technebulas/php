<!DOCTYPE html>
<html lang="en">
	<head>
		<script type="text/javascript">
			
			function sort_fun(vals)
			{
				document.forms["sort_frm"]["rad_val"].value = vals;
				document.forms["sort_frm"].submit();
			}
   
			
		</script>
	</head>

	<body>
		<br>
	<div id="wrapper" class="container">
		<div class="row">
			<div class="span12">
				<div class="control-group">
					<div class="controls">
						<br/>
						<form name="sort_frm" action="<?php echo base_url() ?>index.php/order_detail_edit/sort_enquiry" method="post">
							<div class="span1">
								<b>Sort By : </b>
							</div>
							<div class="span6">
								<input type="hidden" name="rad_val" id="rad_val">
								<?php
								$fl = 0;
								if($vals)
								{
									if($vals == 1)
									{
									?>
										<input type="radio" name="sorting" id="sorting" value="registration" onclick="sort_fun(1)" checked="checked"> &nbsp; Registration Date
									<?php
									}
									else
									{
									?>
										<input type="radio" name="sorting" id="sorting" value="registration" onclick="sort_fun(1)"> &nbsp; Registration Date
									<?php
									}
									?>
									&nbsp; &nbsp;
									
									<?php
									if($vals == 2)
									{
									?>
										<input type="radio" name="sorting" id="sorting" value="order" onclick="sort_fun(2)" checked="checked"> &nbsp; Order Date
									<?php
									}
									else
									{
									?>
										<input type="radio" name="sorting" id="sorting" value="order" onclick="sort_fun(2)"> &nbsp; Order Date
									<?php
									}
									?>
									&nbsp; &nbsp;
									
									<?php
									if($vals == 3)
									{
									?>
										<input type="radio" name="sorting" id="sorting" value="order" onclick="sort_fun(3)" checked="checked"> &nbsp; Enquiry ID
									<?php
									}
									else
									{
									?>
										<input type="radio" name="sorting" id="sorting" value="order" onclick="sort_fun(3)"> &nbsp; Enquiry ID
									<?php
									}
									$fl = 1;
								}
								
								if($fl == 0)
								{
								?>
									<input type="radio" name="sorting" id="sorting" value="registration" onclick="sort_fun(1)"> &nbsp; Registration Date
									<input type="radio" name="sorting" id="sorting" value="order" onclick="sort_fun(2)"> &nbsp; Order Date
									<input type="radio" name="sorting" id="sorting" value="order" onclick="sort_fun(3)" checked="checked"> &nbsp; Enquiry ID
								<?php
								}
								?>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		</br>
		<div class="row">
		<div class="span12">
			<h4>ENQUIRY DETAILS</h4>
			<div style="width: 100%; height:600px; overflow-y: auto;">
			<table class="table table-bordered table-fixed" style="overflow-y:auto;">
				<tr class="active" align="center" size="auto">
					<th class="active"><h6><p>Sr. No</p></h6></th>
					<th class="active"><h6><p>Enq. ID</p></h6></th>
					<th class="active"><h6><p>Reg. Date</p></h6></th>
					<th class="active"><h6><p>Booking Date</p></h6></th>
					<th class="active"><h6><p>Name</p></h6></th>
					<th class="active"><h6><p>Contact No.</p></h6></th>
					<th class="active"><h6><p>Email ID</p></h6></th>
					<th class="active"><h6><p>Action</p></h6></th>
				</tr>
				
				<?php 
				
				$no = 1;
				foreach($values as $value)
				{
					$ed = date("d/m/Y", strtotime($value->enq_date));
					$date1 = date("d/m/Y", strtotime($value->s_date));
					$date2 = date("d/m/Y", strtotime($value->e_date));
					
				?>
					<form name="view_enquiry" action="<?php echo base_url() ?>index.php/order_detail_edit/towards_update_enquiry" method="post">

						<input type="hidden" name="hidd_enq_id" value="<?=$value->enq_id?>">
						<input type="hidden" name="hid_frm_name" value="enquiry_details">
						<input type="hidden" name="hid_action" value="1">
						<!--
						<input type="hidden" name="hidd_pooja_id" value="<?=$value->poojas?>">
						<input type="hidden" name="hidd_pooja_type" value="<?=$value->pooja_type?>">
						-->
					<?php
						if($no%2==1)
						{
					?>
						<tr class="info" align = "center">
							<td><?=$no?></td>
							<td><?=$value->enq_id?></td>
							<td><?=$ed?></td>

							<?php
							if($date1==$date2)
							{
							?>
								<td><?=$date1?></td>
							<?php
							}
							else
							{
							?>
								<td><?=$date1?> to<br><?=$date2?></td>
							<?php
							}
							?>

							<td><?=$value->full_name?></td>
							<td><?=$value->enq_contact_no?></td>
							<td><?=$value->username?></td>
							<td>
								<input type="submit" class="btn btn-success" value="Attempt">
							</td>
						</tr>
					<?php
						}
						else
						{
					?>
						<tr align = "center">
							<td><?=$no?></td>
							<td><?=$value->enq_id?></td>
							<td><?=$ed?></td>

							<?php
							if($date1==$date2)
							{
							?>
								<td><?=$date1?></td>
							<?php
							}
							else
							{
							?>
								<td><?=$date1?> to<br><?=$date2?></td>
							<?php
							}
							?>

							<td><?=$value->full_name?></td>
							<td><?=$value->enq_contact_no?></td>
							<td><?=$value->username?></td>
							<td>
								<input type="submit" class="btn btn-success" value="Attempt">
							</td>
						</tr>
					<?php
						}
					?>
					</form>
				<?php
					
					$no++;
				}
				
				if($no==1)
				{
					echo "<tr><th colspan='8'><b style='color:red;'>No Record Found</b></th></tr>";
				}
				
				?>
				
			</table>
			</div>
		</div>						
		</div>						
	</div>						
	</body>
</html>
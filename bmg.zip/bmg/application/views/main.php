<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Book MY Guruji</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		<!-- slider js files  -->
		<script src="<?php echo base_url(); ?>js/jquery.minslider.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery.caroulslider.js"></script>
	</head>
	<style>
	#pn:hover
	{
	border: 1px solid #FAA732;
	}
	
	#sl:hover
	{
	background-color: #FAA732;
	}
	</style>
	<script type="text/javascript">
		
			function changeText(text)
			{
				var display = document.getElementById('text-display');
				display.innerHTML = "";
				// display.innerHTML = text;
				display.innerHTML = "<img src='"+text+"' style='max-width:98%;'>";
			}
			
			function defaultText()
			{
				var display = document.getElementById('text-display');
				display.innerHTML = "";
				display.innerHTML = "<img src='"+text+"'>";
			}
		
		</script>
		<script type="text/javascript">
								 (function() {
								 var method;
								 var emptyFun = function () {};
								 var methods = ['assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
								 'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
								 'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
								 'timeStamp', 'trace', 'warn'];
								 var length = methods.length;
								 var console = (window.console = window.console || {});
								 while (length--) {
								 method = methods[length];
								 if (!console[method]) {
								 console[method] = emptyFun;
								 }
								 }
								 }());
								 var START_TIME = (new Date()).getTime(); 
								 function noxfs() {
								 try {
								 if (window.top !== window.self) {
								 document.write = "";
								 window.top.location = window.self.location;
								 setTimeout(function() {
								 document.body.innerHTML = '';
								 }, 0);
								 window.self.onload = function() {
								 document.body.innerHTML = '';
								 };
								 }
								 } catch (err) {
								 }
								 }
								 noxfs();
								 window.onerror = function(message, file, line) {
								 try{
								 var sFormattedMessage = '[' + file + ' (' + line + ')] ' + message;
								 _gaq.push(['_trackEvent', 'Exceptions', 'JS errors', sFormattedMessage, null, true]);
								 }
								 catch(e){}
								 }; 
								 function addEvent(elm, evType, fn, useCapture) {
								 useCapture = useCapture || false;
								 if (elm.addEventListener) {
								 elm.addEventListener(evType, fn, false);
								 return true;
								 } else if (elm.attachEvent) {
								 var r = elm.attachEvent('on' + evType, fn);
								 return r;
								 } else {
								 elm['on' + evType] = fn;
								 }
								 }; 
								 function removeEvent(elm, evType, fn, useCapture) {
								 useCapture = useCapture || false;
								 if (elm.removeEventListener){
								 elm.removeEventListener(evType, fn, false);
								 } else if (elm.detachEvent) {
								 elm.detachEvent("on"+evType, fn);
								 } else {
								 delete elm["on"+evType];
								 }
								 }; 
								 function setInteractTime() {
								 window.T_INTERACT = (new Date()).getTime();
								 removeEvent(window, 'click', setInteractTime);
								 removeEvent(window, 'mousemove', setInteractTime);
								 removeEvent(window, 'scroll', setInteractTime);
								 } 
								 addEvent(window, 'click', setInteractTime);
								 addEvent(window, 'mousemove', setInteractTime);
								 addEvent(window, 'scroll', setInteractTime);
								 
								   function sendXhr(url, params_str, callback){
								 var xhr;
								 xhr = (typeof XMLHttpRequest !== "undefined") ? new XMLHttpRequest() : null;
								 xhr = (typeof ActiveXObject!=="undefined") ? new ActiveXObject("Msxml2.XMLHTTP"): xhr;
								 if(!xhr && !url){
								 return;
								 }
								 xhr.onreadystatechange = function() {
								 if (xhr.readyState === 4) {
								 callback && callback();
								 }
								 };
								 xhr.open('POST', url, true);
								 xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
								 xhr.send(params_str);
								 }; 
								 function profileUrl(queryURL, bucketName, postURL, browserName, loadTime){
								 var urlToPost = postURL ? postURL : "http://sedge.flipkart.net/se.php";
								 var detailObj = {};
								 detailObj.request_url = queryURL;
								 detailObj.request_bucket = bucketName;
								 detailObj.ua = browserName;
								 if(window.performance && window.performance.getEntriesByName) {
								 var timingObject = window.performance.getEntriesByName(queryURL)[0];
								 var isCached = false;
								 if(timingObject.domainLookupStart != 0 && timingObject.requestStart == 0){
								 isCached = true;
								 }
								 detailObj.js_duration= loadTime;
								 detailObj.request_extended_dnsStart= timingObject.domainLookupStart;
								 detailObj.request_extended_dnsDuration= timingObject.domainLookupEnd - timingObject.domainLookupStart;
								 detailObj.request_extended_tcpStart= timingObject.connectStart;
								 detailObj.request_extended_tcpDuration= timingObject.connectEnd - timingObject.connectStart;
								 detailObj.request_extended_requestStart= timingObject.requestStart;
								 detailObj.request_extended_responseStart= timingObject.responseStart;
								 detailObj.request_extended_responseDuration= timingObject.duration;
								 detailObj.request_extended_isCache= isCached;
								 }else{
								 detailObj.js_duration= loadTime;
								 }
								 sendXhr(urlToPost, JSON.stringify(detailObj));
								 }
								 
								 (function(){
								 if(window.BOOMR && window.BOOMR.version){return;}
								 var dom,doc,where,iframe = document.createElement('iframe');
								 iframe.src = "javascript:false";
								 iframe.title = ""; iframe.role="presentation";
								 (iframe.frameElement || iframe).style.cssText = "width:0;height:0;border:0;display:none;";
								 where = document.getElementsByTagName('script')[0];
								 where.parentNode.insertBefore(iframe, where); 
								 try {
								 doc = iframe.contentWindow.document;
								 } catch(e) {
								 dom = document.domain;
								 iframe.src="javascript:var d=document.open();d.domain='"+dom+"';void(0);";
								 doc = iframe.contentWindow.document;
								 }
								 doc.open()._l = function() {
								 var js = this.createElement("script");
								 if(dom) this.domain = dom;
								 js.id = "boomr-if-as";
								 js.src = '//c.go-mpulse.net/boomerang/' +
								 'NWG7T-VG79W-2QDRX-SWMPV-ZTNFQ';
								 BOOMR_lstart=new Date().getTime();
								 this.body.appendChild(js);
								 };
								 doc.write('<body onload="document._l();">');
								 doc.close();
								 })();
							</script> 
							<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/flipslide.css" />
							
							<script type="text/javascript+fk-window-onload">
								 (function(){
								 var $slideContainer = $(".pbo-sticky .slider-container"),
								 $slides = $(".pbo-sticky .slider-container .slides"),
								 count = $slides.length,
								 enabledNext = false,
								 enabledPrev = false;
								 
								 var slideNext = function(){
								 
								 enabledNext = true;
								 $currentSlide = $('.pbo-sticky .current-slide');
								 index = $slides.index($currentSlide);
								 if (index < count) {
								 $currentSlide.removeClass('current-slide');
								 $($slides[index + 1]).addClass('current-slide');
								 if(index === (count-2)){
								 enabledNext = false;
								 $('.pbo-sticky .right-slide').removeClass('active').addClass('inactive').off('click.next');
								 }
								 
								 if(!enabledPrev){
								 enabledPrev = true;
								 $('.pbo-sticky .left-slide').removeClass('inactive').addClass('active').on('click.next',slidePrev);
								 }
								 }
								 };
								 
								 var slidePrev = function(){
								 
								 enabledPrev = true;
								 $currentSlide = $('.pbo-sticky .current-slide');
								 index = $slides.index($currentSlide);
								 if (index > 0) {
								 $currentSlide.removeClass('current-slide');
								 $($slides[index - 1]).addClass('current-slide');
								 if(index === 1){
								 enabledPrev = false;
								 $('.pbo-sticky .left-slide').removeClass('active').addClass('inactive').off('click.next');
								 }
								 if(!enabledNext){
								 enabledNext = true;
								 $('.pbo-sticky .right-slide').removeClass('inactive').addClass('active').on('click.next',slideNext);
								 }
								 }
								 }
								 
								 var changeSlide = function(){ if(enabledNext){slideNext();}else{slidePrev();}}
								 
								 var attachHandlers = function(autoSlide){
								 if($slides.length > 1){
								 $('.pbo-sticky .right-slide').on('click.next',slideNext);
								 if(autoSlide){
								 enabledNext = true;
								 setInterval(function(){
								 changeSlide();
								 },5000);
								 }
								 }
								 }
								 
								 $(".pbo-sticky .ribbon").on("click",function(){
								 $(".pbo-sticky").delay(200).toggleClass("collapsed");
								 });
								 attachHandlers(true);
								 }());
								(function(){
								 var $pboText = $(".pbo-text");
								 $pboText.on("click",function(){
								 $(".offer-details").slideToggle();
								 $pboText.toggleClass("pbo-collapsed");
								 });
								 }());
							</script>
    <body>
		<?php
			if($this->session->userdata('add_event'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('add_event').'")';
				echo '</script>'; 
				$this->session->unset_userdata('add_event');
			}
			
			if($this->session->userdata('log_in_out_msg'))
			{
				/* echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('log_in_out_msg').'")';
				echo '</script>'; */
				$this->session->unset_userdata('log_in_out_msg');
			}
			
			if($this->session->userdata('change_pass'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('change_pass').'")';
				echo '</script>'; 
				$this->session->unset_userdata('change_pass');
			}
			
			/*
			if($this->session->userdata('sign_up_msg'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('sign_up_msg').'")';
				echo '</script>'; 
				$this->session->unset_userdata('sign_up_msg');
			}
			*/
			
			if($this->session->userdata('recover_password'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('recover_password').'")';
				echo '</script>'; 
				$this->session->unset_userdata('recover_password');
			}
			
			if($this->session->userdata('recover_pass_sendmail'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('recover_pass_sendmail').'")';
				echo '</script>'; 
				$this->session->unset_userdata('recover_pass_sendmail');
			}
			
			
			if($this->session->userdata('new_msg_2'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('new_msg_2').'")';
				echo '</script>'; 
				$this->session->unset_userdata('new_msg_2');
			}
		?>
		
		</br>
		<div id="wrapper" class="container">
		<div class="row">
			<div class="span9">
				<section  class="homepage-slider" id="home-slider" style="margin-left:-9px;margin-right:0px;width:101%">
					<div class="required-tracking" data-tracking-id="widget">	
						<div class=" big-banner fk-position-relative newvd"> 
							<div class="line big-banner-image">
								<div class="banner-image tab-content " id="b-tab0-content">
									<a href="<?php echo base_url(); ?>index.php/Home/book_guruji_direct" data-tracking-id="banner_0_image"> 
										<img alt=""src="<?php echo base_url(); ?>img/carousel/slider.jpg"  /> 
									</a>
									<div class="banner-link fk-font-15"> </div> 
								</div> 
								<div class="banner-image tab-content fk-hidden" id="b-tab1-content"> 
									<a href="<?php echo base_url(); ?>index.php/Home/laxmi" data-tracking-id="banner_1_image">
										<img data-url="<?php echo base_url(); ?>img/carousel/slider2.jpg"/> 
									</a>
									<div class="banner-link fk-font-15"> </div>
								</div>
								<div class="banner-image tab-content fk-hidden" id="b-tab2-content">
									<a href="<?php echo base_url(); ?>index.php/Home/vivah" data-tracking-id="banner_2_image"> 
										<img data-url="<?php echo base_url(); ?>img/carousel/slider3.jpg" />
									</a> 
									<div class="banner-link fk-font-15"> </div>
								</div>
								<div class="banner-image tab-content fk-hidden" id="b-tab3-content"> 
									<a href="<?php echo base_url(); ?>index.php/Home/navgrah" data-tracking-id="banner_1_image">
										<img data-url="<?php echo base_url(); ?>img/carousel/slider4.jpg" /> 
									</a>
									<div class="banner-link fk-font-15"> </div>
								</div>
								<div class="banner-image tab-content fk-hidden" id="b-tab4-content"> 
									<a href="<?php echo base_url(); ?>index.php/Home/bhoomi" data-tracking-id="banner_1_image">
										<img data-url="<?php echo base_url(); ?>img/carousel/slider5.jpg" /> 
									</a>
									<div class="banner-link fk-font-15"> </div>
								</div>
							</div>
							<div class="line banner-tabs" style="background-color:orange;"> 
							<ul style="list-style-type: none;margin-top:-10px;margin-right:-23px;">
									<li class="nav-list unit size1of3" style="width:20%; margin-left:-39px;">
										<a href="<?php echo base_url(); ?>index.php/Home/book_guruji_direct" id="b-tab0" class="banner-tab tab first-tab selected" data-tracking-id="banner_tab_0"> 
											<table width="100%"><tr><td><b>Welcome To</b></td></tr><tr><td><b>bookmyguruji.com</b></td></tr></table>
										</a> 
									</li> 
									<li class="nav-list unit size1of3" style="width:20%;margin-left:-30px;">
										<a href="<?php echo base_url(); ?>index.php/Home/laxmi" id="b-tab1"class="banner-tab tab second-tab"data-tracking-id="banner_tab_1">
											<table width="100%"><tr><td><b>Laxmi Pooja</b></td></tr><tr><td><b>लक्ष्मी पूजा</b></td></tr></table>
										</a> 
									</li>
									<li class="nav-list unit size1of3" style="width:20%;margin-left:-30px;">
										<a href="<?php echo base_url(); ?>index.php/Home/vivah" id="b-tab2"class="banner-tab tab third-tab"data-tracking-id="banner_tab_2"> 
											<table width="100%"><tr><td><b>Vivah Pooja</b></td></tr><tr><td><b>विवाह पूजा</b></td></tr></table>
										</a>
									</li>
									<li class="nav-list unit size1of3" style="width:20%;margin-left:-30px;">
										<a href="<?php echo base_url(); ?>index.php/Home/navgrah" id="b-tab3"class="banner-tab tab third-tab"data-tracking-id="banner_tab_3"> 
											<table width="100%"><tr><td><b>Navagrah Pooja</b></td></tr><tr><td><b>नवग्रह पूजा</b></td></tr></table>
										</a>
									</li>
									<li class="nav-list unit size1of3" style="width:20%;margin-left:-30px;">
										<a href="<?php echo base_url(); ?>index.php/Home/bhoomi" id="b-tab4"class="banner-tab tab third-tab"data-tracking-id="banner_tab_4"> 
											<table width="100%"><tr><td><b>Bhoomi Pooja</b></td></tr><tr><td><b>भूमी  पूजा</b></td></tr></table>
										</a>
									</li>
							</ul>
							</div>
						</div> 
							 <script type="text/javascript+fk-onload">
							 (function() {
							 var timerId = null, timerEnabled=true, tabsArray = $(".banner-tab"), currentTab = 0, numOfTabs = tabsArray.length;
							 var tabs = $(".big-banner").tabs({clickDisabled:false, fadeDuration:400}).data("tabs_instance");
							 $(".big-banner").bind("tabChange", function(ev, tab){
							 var $img = $("#"+tab.id+"-content").find("img");
							 $img.attr("data-url") && $img.attr("src", $img.attr("data-url")).removeAttr("data-url");
							 });
							 $(".banner-tab").bind("mouseenter", function() {
							 tabs.changeTab(this);
							 timerId && clearTimeout(timerId) && (timerEnabled=false);
							 });
							 function cycleTabs() {
							 if(timerEnabled){
							 currentTab++;
							 timerId = setTimeout(function(){
							 tabs.changeTab(tabsArray[currentTab%numOfTabs]);
							 cycleTabs();
							 }, 5000);
							 }
							 }
							 function lazyfetch() {
							 $(".big-banner").find("img[data-url]").each(function(){
							 $(this).attr("src",$(this).attr("data-url")).removeAttr("data-url");
							 }).first().on("load", cycleTabs);
							 }
							 addWindowOnload(lazyfetch);
							 })();
							</script> 
					</div>
				<script type="text/javascript" src="<?php echo base_url(); ?>js/flip.js">
				</script>
				<script type="text/javascript"> addOnload(function(){
					 FKART.utils.runOnload();
					 });
					 addWindowOnload(function(){
					 FKART.utils.runWindowOnload();
					 });
				</script> 
			</section>
			
				<section class="header_text">
					<div class="row">
						<div class="span9">
							<h4 class="title">
								<span class="pull-center"><span class="text"><span class="line"><strong><?=$sl1_title[0]->sub_title?></strong></span></span></span>
							</h4>
							<div class="carousel-inner">
								<div class="list_carousel responsive">
									<ul  id="flexiselDemo3">
										<li class="span2">
											<div id="pn" >
												<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl1pic0[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl1pic0[0]->image_name?>" alt="" style="height:180px;"/></a></p>
												<?=$sl1pic0[0]->sl_pj_name?>
												</br>
												<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl1pic0[0]->pandit_fee?>
												<br>
											</div>
										</li>
										<li class="span2">
											<div id="pn" >
												<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl1pic1[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl1pic1[0]->image_name?>" alt="" style="height:180px;"/></a></p>
												<?=$sl1pic1[0]->sl_pj_name?>
												</br>
												<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl1pic1[0]->pandit_fee?>
												<br>
											</div>
										</li>
										<li class="span2">
											<div id="pn" >
												<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl1pic2[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl1pic2[0]->image_name?>" alt="" style="height:180px;"/></a></p>
												<?=$sl1pic2[0]->sl_pj_name?>
												</br>
												<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl1pic2[0]->pandit_fee?>
												<br>
											</div>
										</li>
										<li class="span2">
											<div id="pn" >
												<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl1pic3[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl1pic3[0]->image_name?>" alt="" style="height:180px;"/></a></p>
												<?=$sl1pic3[0]->sl_pj_name?>
												</br>
												<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl1pic3[0]->pandit_fee?>
												<br>
											</div>
										</li>
										<li class="span2">
											<div id="pn" >
												<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl1pic4[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl1pic4[0]->image_name?>" alt="" style="height:180px;"/></a></p>
												<?=$sl1pic4[0]->sl_pj_name?>
												</br>
												<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl1pic4[0]->pandit_fee?>
												<br>
											</div>
										</li>
										<li class="span2">
											<div id="pn" >
												<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl1pic5[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl1pic5[0]->image_name?>" alt="" style="height:180px;"/></a></p>
												<?=$sl1pic5[0]->sl_pj_name?>
												</br>
												<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl1pic5[0]->pandit_fee?>
												<br>
											</div>
										</li>
									</ul>
								</div>
							</div>						
						</div>
				</section>
				<section class="header_text">
					<div class="row">
						<div class="span9">
							<h4 class="title">
								<span class="pull-center"><span class="text"><span class="line"><strong><?=$sl2_title[0]->sub_title?></strong></span></span></span>
							</h4>
							<div class="list_carousel responsive">
								<ul  id="flexiselDemo4" >												
									<li class="span2">
										<div id="pn" >
											<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl2pic0[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl2pic0[0]->image_name?>" alt="" style="height:180px;"/></a></p>
											<?=$sl2pic0[0]->sl_pj_name?>
											</br>
											<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl2pic0[0]->pandit_fee?>
											<br>
										</div>
									</li>
									<li class="span2">
										<div id="pn" >
											<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl2pic1[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl2pic1[0]->image_name?>" alt="" style="height:180px;"/></a></p>
											<?=$sl2pic1[0]->sl_pj_name?>
											</br>
											<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl2pic1[0]->pandit_fee?>
											<br>
										</div>
									</li>
									<li class="span2">
										<div id="pn" >
											<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl2pic2[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl2pic2[0]->image_name?>" alt="" style="height:180px;"/></a></p>
											<?=$sl2pic2[0]->sl_pj_name?>
											</br>
											<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl2pic2[0]->pandit_fee?>
											<br>
										</div>
									</li>
									<li class="span2">
										<div id="pn" >
											<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl2pic3[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl2pic3[0]->image_name?>" alt="" style="height:180px;"/></a></p>
											<?=$sl2pic3[0]->sl_pj_name?>
											</br>
											<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl2pic3[0]->pandit_fee?>
											<br>
										</div>
									</li>
									<li class="span2">
										<div id="pn" >
											<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl2pic4[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl2pic4[0]->image_name?>" alt="" style="height:180px;"/></a></p>
											<?=$sl2pic4[0]->sl_pj_name?>
											</br>
											<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl2pic4[0]->pandit_fee?>
											<br>
										</div>
									</li>
									<li class="span2">
										<div id="pn" >
											<p><a href="<?php echo base_url(); ?>index.php/Home/<?=$sl2pic5[0]->cnl_name?>"><img src="<?php echo base_url(); ?>img/<?=$sl2pic5[0]->image_name?>" alt="" style="height:180px;"/></a></p>
											<?=$sl2pic5[0]->sl_pj_name?>
											</br>
											<img src="<?php echo base_url(); ?>img/Rupee.png"/>&nbsp;&nbsp;<?=$sl2pic5[0]->pandit_fee?>
											<br>
										</div>
									</li>
								</ul>
							</div>
						</div>						
					</div>
				</section>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.flexisel.js"></script>
   <link href="<?php echo base_url(); ?>css/styleggg.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
    $("#flexiselDemo3").flexisel({
        visibleItems: 5,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,            
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });
	$("#flexiselDemo4").flexisel({
        visibleItems: 5,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,            
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });

   
</script>
			</div>
			<div class="span3">
					</br><center id="pn" >
					<a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct">
						<img alt="" src="<?php echo base_url(); ?>img/nav.jpg"></br></br>
						<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px">
					</a>
					</center> </br></br>
					<?php
					foreach($images as $img)
					{
					?>
					<table  width="100%" style="border-color:#FAA732;height:100%;">
					<tr><td style="border: 1px solid #FAA732;" align="left">
					<marquee direction="up" onmouseover='this.stop();' onmouseout='this.start();' width="95%" height="250px" scrollamount="3">
					<font size="4" style="color:black">
					<?php
						//  face="Cursive" font tag property
						$array = explode('#',$img->eventname);
						$inc=0;
						echo "<ul>";
						foreach ($array as $list_item =>$img->eventname)
						{
							if($inc != 0)
								echo ("<li>".$img->eventname."</li>");
							$inc++;
						}
						echo "</ul>";
					?>
					</font>
					</marquee></td></tr>
					</table><br/><br/>
						<img src="<?php echo base_url()?>uploads/<?=$img->image1?>" id="pn"></br></br>
						<img src="<?php echo base_url()?>uploads/<?=$img->image2?>" id="pn"></br></br>
						<!--img src="<?php echo base_url()?>uploads/<?=$img->image3?>" id="pn"></br-->
					<?php
					}
					?>
					<!--img alt="" id="pn" src="<?php echo base_url(); ?>img/ladies/14.jpg"></br></br>
					 <img alt="" id="pn" src="<?php echo base_url(); ?>img/ladies/1.jpg"><br/-->
					
			</div>
			</div>
		</div>
		</div>
	</div>
		<!--script type="text/javascript">
			$(function() {
				$(document).ready(function() {
					$('.flexslider').flexslider({
						animation: "fade",
						slideshowSpeed: 4000,
						animationSpeed: 600,
						controlNav: false,
						directionNav: true,
						controlsContainer: ".flex-container" // the container that holds the flexslider
					});
				});
			});
		</script>
		<script type="text/javascript">$('#list_photos').carouFredSel({ responsive: true, width: '100%', scroll: 2, items: {width: 50, visible: {min: 2, max: 4}} });</script>
		<script type="text/javascript">$('#list_photos1').carouFredSel({ responsive: true, width: '100%', scroll: 2, items: {width: 50, visible: {min: 2, max: 4}} });</script-->
    </body>
</html>
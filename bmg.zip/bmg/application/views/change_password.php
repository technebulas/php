<html lang="en">
	<head>
		<script>
			function reset_msg()
			{
				document.getElementById("txt1").innerHTML = "";
				document.getElementById("txt2").innerHTML = "";
				document.getElementById("txt3").innerHTML = "";
			}
		
			function check()
			{
				var pass=document.getElementById("newpassword").value;
				var pass1=document.getElementById("confirmpassword").value;

				if(pass != pass1)
				{
					// alert("Enter Password not match ! Please Re enter Password.");
					document.getElementById("txt3").innerHTML = "&nbsp; Both password should be same.";
					document.getElementById("confirmpassword").value="";
					return false;
				}
			} 
			
			function check1()
			{
				var pass=document.getElementById("newpassword").value;
				var pass1=document.getElementById("confirmpassword").value;
				
				if(pass1!='')
				{
					if(pass != pass1)
					{
						// alert("Enter Password not match ! Please Re enter Password.");
						document.getElementById("txt3").innerHTML = "&nbsp; Both password should be same.";
						document.getElementById("newpassword").value="";
						// document.getElementById("confirmpassword").value="";
						return false;
					}
				}
			} 
			
			function submit_form()
			{
					
				var old = document.getElementById("oldpassword").value;
				var pass = document.getElementById("newpassword").value;
				var pass1 = document.getElementById("confirmpassword").value;
				
				if(old=="")
				{	
					// alert("Plz Fill Old Password");
					document.getElementById("txt1").innerHTML = "&nbsp; Please enter old password";
					return false;
				}
				else if(pass=="")
				{
					// alert("Plz Fill New Password");
					document.getElementById("txt2").innerHTML = "&nbsp; Please enter new password";
					return false;
				}
				else if(pass1=="")
				{
					// alert("Plz Fill Confirm Password");
					document.getElementById("txt3").innerHTML = "&nbsp; Please enter confirm password";
					return false;
				}
				else if(pass!=pass1)
				{
					alert("Password not same");
					// document.getElementById("newpassword").value="";
					document.getElementById("confirmpassword").value="";
					return false;
				}
				else
				{
					document.forms['changepassword'].submit();
					return true;
				}
			}
		</script>
		
	</head>
	
	<body>
		<br>
		<div id="wrapper" class="container">		
			<section class="main-content">				
				<div class="row">
					<div class="span3">&nbsp;</div>
					<div class="span7">	</br>		
						<h4 class="title"><span class="text"><strong>Change </strong> Password</span></h4>
						<form class="form-stacked" name="changepassword" method="post" action="<?php echo base_url() ?>index.php/Login/act_change_pass">
							<fieldset>	
								<div class="control-group">
									<b>Old Password</b>
									<div class="controls">										
										<input type="text" placeholder="Old Password" class="span3" id="oldpassword" name="oldpassword" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt1"></span></font>
									</div>
								</div>
								
								<div class="control-group">
									<b>New Password</b>
									<div class="controls">
										<input type="password" placeholder="New Password" class="span3" id="newpassword" onchange="check1();" name="newpassword" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt2"></span></font>
									</div>
								</div>
								
								<div class="control-group">
									<b>Confirm Password</b>
									<div class="controls">
										<input type="password" placeholder="Confirm Password" class="span3" id="confirmpassword" name="confirmpassword" onchange="check();" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt3"></span></font>
									</div>
								</div>
								
								<div class="control-group">
									<input class="btn btn-success" type="button" onclick="submit_form()" value="Submit">
									&nbsp; &nbsp; &nbsp; &nbsp;
									<button class="btn btn-warning" type="reset">Reset</button>
								</div>
							</fieldset>	
						</form>				
					</div>			
				</div>
			</section>			
		</div>
    </body>
</html>
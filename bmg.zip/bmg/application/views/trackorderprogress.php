	<h4>Booking Status</h4>
	<?php
		if($values)
		{
			$value = $values[0]->enq_status;
			echo "<p>(Enquiry ID - ".$values[0]->enq_id.")</p><br>";
			if($value == 1)
			{
	?>
			<div class="wizard">
				<a class="current"><span class="badge badge-inverse">1</span> <b>Enquiry Level</b></a>
				<a><span class="badge">2</span> <b>Pooja Confirm</b></a>
				<a><span class="badge">3</span> <b>Payment Done</b></a>
				<a><span class="badge">4</span> <b>Pooja Done</b></a> 
			</div>
	<?php
			}
			else if($value == 2)
			{
	?>
			<div class="wizard">
				<a><span class="badge">1</span> <b>Enquiry Level</b></a>
				<a class="current"><span class="badge badge-inverse">2</span> <b>Pooja Confirm</b></a>
				<a><span class="badge">3</span> <b>Payment Done</b></a>
				<a><span class="badge">4</span> <b>Pooja Done</b></a> 
			</div>
	<?php
			}
			else if($value == 3)
			{
	?>
			<div class="wizard">
				<a><span class="badge">1</span> <b>Enquiry Level</b></a>
				<a><span class="badge">2</span> <b>Pooja Confirm</b></a>
				<a class="current"><span class="badge badge-inverse">3</span> <b>Payment Done</b></a>
				<a><span class="badge">4</span> <b>Pooja Done</b></a> 
			</div>
	<?php
			}
			else if($value == 4)
			{
	?>
			<div class="wizard">
				<a><span class="badge">1</span> <b>Enquiry Level</b></a>
				<a><span class="badge">2</span> <b>Pooja Confirm</b></a>
				<a><span class="badge">3</span> <b>Payment Done</b></a>
				<a class="current"><span class="badge badge-inverse">4</span> <b>Pooja Done</b></a> 
			</div>
	<?php
			}
			else if($value == 0)
			{
				echo "<font style='color:red;' size='4'>Your Enquiry Rejected.</font>";
			}
			
		}
		else
		{
			echo "<br><font style='color:red;' size='4'>Invalid Enquiry ID</font>";
		}
	?>
</br></br></br>
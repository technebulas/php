   <!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>bookmyguruji.com | Online Guruji Booking | Guruji in Pune | Satyanarayan Pooja</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!-- bootstrap -->
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
		<link rel="shortcut icon" href="<?php echo base_url();?>img/logo3.ico" />
		<link href="<?php echo base_url();?>css/bootstrappage.css" rel="stylesheet"/>

		<!-- global styles -->
		<link href="<?php echo base_url();?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url();?>css/main.css" rel="stylesheet"/>
		<!-- scripts -->
		<script src="<?php echo base_url();?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url();?>js/superfish.js"></script>	
		<script src="<?php echo base_url();?>js/jquery.scrolltotop.js"></script>
		

		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<!--[if lt IE 9]>			
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
		<script type="text/javascript">
			function auto_complete(str)
			{
				if (str.length == 0)
				{
					document.getElementById("auto_hints").innerHTML = "";
					document.getElementById('auto_hints').style.display="none";
					return;
				}
				else
				{
					var xmlhttp = new XMLHttpRequest();
					xmlhttp.onreadystatechange = function() {
						if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
						{
							xx = xmlhttp.responseText;
							if(xx=="")
								document.getElementById('auto_hints').style.display="none";
							else
								document.getElementById('auto_hints').style.display="inline";
							document.getElementById("auto_hints").innerHTML = xmlhttp.responseText;
						}
					}
					xmlhttp.open("GET", "<?php echo base_url() ?>index.php/Home/getautohint?q=" + str, true);
					xmlhttp.send();
				}
			}
		</script>
	</head>
	<style>
	#border
	{
		border: 3px solid #FAA732;
	}
	r
	{
		color:white;
	}
	#searchfound
	{
		background-color:white;
		font-size:13px;
		width:300px;
		color:black;
	}
	#searchfound:hover
	{
		background-color:white;
		color:orange;
	}
	
	</style>
    <body>
	<div class="navbar-fixed-top">
		<div id="top-bar" class="container">
			<div class="row">
				<div class="span12">
					<div class="account pull-right">
							<ul class="user-menu">
								
								<?php
									if($this->session->userdata('portal_admin_data'))
									{
								?>
										<li><a href="<?php echo base_url(); ?>index.php/Login/navi_change_pass">Change Password</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Primary/navi_create_admin">Create Admin</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Primary/all_users">Users</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Login/logout_user">Logout</a></li>
								<?php
									}
									else if($this->session->userdata('admin_data'))
									{
								?>
										<li><a href="<?php echo base_url(); ?>index.php/Login/navi_change_pass">Change Password</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/pooja_detail_edit/pooja_fees_edit">Pooja's</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/pooja_detail_edit/samagree_fees_edit">Samagri's</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/customer_detail_edit/show_customer">Customers</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/order_detail_edit/show_enquiry">Enquiry</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/order_detail_edit/show_order">Orders</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Login/logout_user">Logout</a></li>
								<?php
									}
									else if($this->session->userdata('user_data'))
									{
								?>
										<li><a href="<?php echo base_url(); ?>index.php/Login/navi_change_pass">Change Password</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/customer_detail_edit/customer_records">My Account</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Home/trackorder">Track Your Order</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Home/customercare">Customer Care</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Login/logout_user">Logout</a></li>
								<?php
										//trackorderprogress
									}
									else
									{
								?>
										<li><a href="<?php echo base_url(); ?>index.php/Home/sign_up">Sign Up</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Home/register">My Account</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Home/trackorder">Track Your Order</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Home/customercare">Customer Care</a></li>
										<li><a href="<?php echo base_url(); ?>index.php/Home/register">Login</a></li>
								<?php
								
									}
								
								?>
		
							
							</ul>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="span4">
						<a href="<?php echo base_url(); ?>index.php/Home/open">
							<img src="<?php echo base_url();?>img/logo.png" style="margin-bottom:5px;" >
						</a>
				</div>

				<form class="search_form"  name="search_frm" action="<?php echo base_url() ?>index.php/Home/search_page2" method="post">
					<div class="span1"></div>
					<div class="span4">
						<input type="text" onkeyup="auto_complete(this.value)" style="margin-left:0px;margin-top:23px" class="span4" Placeholder="Search" name="txt_search" id="txt_search" autocomplete="off">
						<br>
						<div style="position:absolute; border: 1px solid #FAA732; z-index:52; margin-top:-10px;display:none;" id="auto_hints"></div>
					</div>
				
					<div class="span3">
						<button type="submit" style="margin-left:0px;margin-top:22px" class="btn btn-warning">Search</button>
						<!--
						<button style="margin-left:10px;margin-top:24px" onClick="history.go(-1)" class="btn btn-warning"><img src="<?php echo base_url();?>img/cart.png" alt="not found">&nbsp;<b>Cart&nbsp;<span class="badge badge-warning">0</span></b></img></button>
						-->
					</div>
				</form>
			</div>
			
		</div>
		<div id="wrapper" class="container"style="background-color:#FAA732;" >
			<section class="navbar main-menu" >
					<nav id="menu" class="pull-left">
						<ul >
							<li><a href="#" style="color:white">Home Pooja</a>
								<ul>
								<table id="border">
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/laxmi">Laxmi&nbsp;Pooja<br>लक्ष्मी  पूजा</a></li></td>	
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/mahamrutyunjay">Mahamrityunjaya&nbsp;Jap<br>महामृत्यूंजय जप</a></li></td>	
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/atirudra">Aati&nbsp;Rudra&nbsp;Pooja<br>अती रुद्र पूजा</a></li></td>									
								</tr>
								<tr>
								<td><li><a href="<?php echo base_url(); ?>index.php/Home/Grihapravesh">Griha&nbsp;Pravesh<br>गृह  प्रवेश</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/satyanarayan">Satyanarayan&nbsp;Pooja<br>सत्यनारायण&nbsp;पूजा</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/pitradosh">Pitra&nbsp;Dosh&nbsp;Shanti&nbsp;Pooja<br>पित्रदोष  शांती पूजा</a></li></td>
									
								</tr>
								<tr>
								<td><li><a href="<?php echo base_url(); ?>index.php/Home/navgrah">Navagrah&nbsp;Pooja<br>नवग्रह पूजा </a></li></td>	
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/shiv">Shiv&nbsp;pooja/Laghu&nbsp;Rudra<br>शिव  पूजा / लघु  रुद्र </a></li></td>									
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/vasant">Vasant&nbsp;Panchami&nbsp;Pooja<br>वसंत पंचमी पूजा </a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/Navchandi">Navchandi/Shatchandi<br>नवचंडी / शतचंडी</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/moolshanti">Mool&nbsp;Shanti&nbsp;Pooja<br>मूळ  शांती  पूजा </a></li></td>									
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/udakshanti">Udaka&nbsp;Shanti<br>उदकशांती</a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/krishna">Krishna/Janmashtami&nbsp;Pooja<br>कृष्ण पूजा / जन्माष्टमी</a></li></td>									
									<td colspan="2"><li><a href="<?php echo base_url(); ?>index.php/Home/maharudra">Maha&nbspRudra&nbsp;Pooja<br>महा  रुद्र  पूजा </a></li></td>
									
								</tr>
								</table>
								</ul>
							</li>															
							<li><a href="#" style="color:white">Office Pooja</a>
							<ul>
								<table id="border">
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/bhoomi">Bhoomi&nbsp;Pooja<br>भूमी पूजा </a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/officelaxmi">Laxmi&nbsp;Pooja<br>लक्ष्मी  पूजा</a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/saraswati">Sarswati&nbsp;Pooja<br>सरस्वती  पूजा</a></li></td>				
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/officesatyanarayan">Satyanarayan&nbsp;Pooja<br>सत्यनारायण पूजा</a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/vishwa">Vishwakarma&nbsp;Pooja<br>विश्वकर्मा पूजा</a></li></td>
								</tr>
								</table>
																		
							</ul>
							</li>			
							<li><a href="#" style="color:white">Festivals Pooja</a>
								<ul>
								<table id="border">
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/dhanteras"> Dhanteras&nbsp;Pooja<br>धनतेरस  पूजा </a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/mahashiv">Mahashivratri&nbsp;Pooja<br>महाशिवरात्री पूजा</a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/durgaji">Durga&nbsp;Pooja<br>दुर्गा पूजा</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/ganeshyag">Ganesh&nbsp;Yag&nbsp;<br>गणेश याग</a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/ganpati">Ganesh&nbsp;Pooja/Ganesh&nbsp;Chaturthi<br>गणेश पूजा / गणेश चतुर्थी</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/dattyag">Datta&nbsp;Yag&nbsp;<br>दत्त याग</a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/festivallaxmi">Laxmi&nbsp;Pooja<br>लक्ष्मी  पूजा</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/vatpornima">Vat&nbsp;Pournima&nbsp;Pooja<br>वट पौर्णिमा पूजा</a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/navratri">Navratri&nbsp;Pooja<br>नवरात्री पूजा</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/manglagaur">Mangla&nbsp;Gauri&nbsp;Pooja<br>मंगला गौरी पूजा</a></li></td>
								</tr>
								<tr>
									<td colspan="2"><li><a href="<?php echo base_url(); ?>index.php/Home/gauri">Gauri&nbsp;Pooja<br>गौरी पूजा</a></li></td>
								</tr>
								</table>
								</ul>
							</li>	
							<li><a href="#" style="color:white">Functional Pooja</a>
							<ul>
								<table id="border">
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/namkaran">Namkaran/Barasa<br>नामकरण / बारस</a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/murtipranpratishta">Murti&nbsp;Pranpratishtha<br>मूर्तीप्राणप्रतिष्ठा </a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/munj">Munj<br>मुंज </a></li></td>
									
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/mandirjirnodhar">Mandir&nbsp;Jirnodhar&nbsp;<br>मंदिर जीर्नोधार  </a></li></td>
								</tr>
								<tr>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/vastushanti">Vastu&nbsp;Shanti&nbsp;Pooja<br>वास्तु  शांती पूजा  &nbsp; &nbsp; </a></li></td>
									<td><li><a href="<?php echo base_url(); ?>index.php/Home/vivah">Vivah&nbsp;Pooja<br>विवाह पूजा</a></li></td>
								</tr>
								<tr>
									<td colspan="2"><li><a href="<?php echo base_url(); ?>index.php/Home/sathi">Sathi(60th Birthday)Pooja<br>साठी ( ६० वाढदिवस ) पूजा</a></li></td>
									
								</tr>
								</table>
							</ul>
							</li>
							
							<?php
							if($this->session->userdata('admin_data'))
							{
							}
							elseif($this->session->userdata('portal_admin_data'))
							{
							}
							else
							{
							?>
							<li><a href="<?php echo base_url(); ?>index.php/Home/book_guruji_direct" style="color:white">Book My Guruji</a></li>
							<?php
							}
							?>
							<!--
							<li><a href="<?php echo base_url(); ?>index.php/Home/Holi" style="color:white">Holy Store</a></li>
							<li><a href="<?php echo base_url(); ?>index.php/Home/astrology" style="color:white">Astrology</a></li>
							-->
							<?php
							if($this->session->userdata('admin_data'))
							{
							?>
								<li><a href="#" style="color:white">Option</a>
									<ul>
										<table id="border" width="100%">
										<tr>
											<td><li><a href="<?php echo base_url(); ?>index.php/Home/newletter" >Newsletter</a></li></td>
										</tr>
										<tr>
											<td><li><a href="<?php echo base_url(); ?>index.php/Right_panel/createEv">Event</a></li></td>
										</tr>
										<tr>
											<td><li><a href="<?php echo base_url(); ?>index.php/Home/sliders">Mainpage Slider</a></li></td>
										</tr>
										<tr>
											<td><li><a href="<?php echo base_url(); ?>index.php/customer_detail_edit/show_rejection_all">Rejections</a></li></td>
										</tr>
										<tr>
											<td><li><a href="<?php echo base_url(); ?>index.php/customer_detail_edit/show_pendings">Pending Orders</a></li></td>
										</tr>
										</table>
									</ul>
								</li>
							<?php
							}
							?>
							<li>
							<table>
								<tr>
									<td width="260px" height="30px"  valign="bottom" align="right">
										<?php
											if($this->session->userdata('user_data'))
											{
												$rres = $this->session->userdata('user_data');
												$name = $rres[0]->fullname;
												
												$name=strtok($name, " ");
												$len=strlen($name);
												 
												if($len > 10)
												$name=substr($name,0,10);
												
												echo "<r>Welcome&nbsp;&nbsp;<b>".strtoupper($name)."</b></r>";
											}
											
											if($this->session->userdata('admin_data'))
											{
												$rres = $this->session->userdata('admin_data');
												$name = $rres[0]->fullname;
												
												$name=strtok($name, " "); 
												$len=strlen($name);
												 
												if($len > 10)
												$name=substr($name,0,10);
												
												echo "<r>Welcome&nbsp;&nbsp;<b>".strtoupper($name)."</b></r>";
											}
											
											if($this->session->userdata('portal_admin_data'))
											{
												$rres = $this->session->userdata('portal_admin_data');
												$name = $rres[0]->fullname;
												
												$name=strtok($name, " "); 
												$len=strlen($name);
												 
												if($len > 10)
												$name=substr($name,0,10);
												
												echo "<r>Welcome&nbsp;&nbsp;<b>".strtoupper($name)."</b></r>";
											}
										?>
									</td>
								</tr>
								</table>
							</li>
						</ul>
					</nav>
			</section>
			</br>
			
		</div>
		</div><br><br><br><br><br><br>
			<!--section class="header_text sub" >
			<!--<img class="pageBanner" src="<?php echo base_url();?>img/pageBanner.png" alt="New products" >-->
				<!--h4><span></span></h4>
			</section-->
			<script src="<?php echo base_url();?>js/common.js"></script>	
	</body>	
</html>	
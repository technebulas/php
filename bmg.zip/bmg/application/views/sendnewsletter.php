<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		
		<!-- Date picker css & js-->
		<link href="<?php echo base_url(); ?>css/runnable.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>js/script.js"></script>	
		<script src="<?php echo base_url(); ?>js/script1.js"></script>	

		<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css" />
		<script src="<?php echo base_url(); ?>js/jquery-1.9.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
		<style>
		#pn:hover
		{
			border: 1px solid #FAA732;
		}
		#sl:hover
		{
			background-color: #FFE6CC;
		}
		</style>	
		
		<script language="javascript" type="text/javascript">
				
				function clrmsg()	
				{
					document.getElementById("txt1").innerHTML = "";
					document.getElementById("txt2").innerHTML = "";
				}
		
				/* function validateText(val)	
				{
					var str = val.value;
					if(!str.match(/^[A-Za-z ]*$/))
					{
						alert("Please enter valid information...!");
						val.value="";
						return false;
					}
				}	 */
					
				function checkEmail(emailId) {
					if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailId)){
					// document.write("You have entered valid email.");
					return true;
					}    
					return false;
					}

					function ValidateEmail(){
					
						var emailID=document.getElementById("to");

						if ((emailID.value==null)||(emailID.value=="")){
							// alert("Please Enter your Email ID")
							document.getElementById("txt1").innerHTML = "Please Enter your Email ID.";
							emailID.focus()
							return false
						}

						if (checkEmail(emailID.value)==false){
							emailID.value=""
							// alert("Invalid Email Adderess");
							document.getElementById("txt1").innerHTML = "Invalid Email Adderess";
							emailID.focus()
							return false
						}
							// alert('valid');
							return true
					 }
					 
			function form_submit()
			{
				var cust = document.getElementById("customer");
				var news = document.getElementById("newsletter");
				var to = document.getElementById("to").value;
				var msg = document.getElementById("msg").value;

				var flag = 0;
				
				if(cust.checked)
					flag++;
				if(news.checked)
					flag++;
				if(to != "")
					flag++;
				
				if(flag == 0)
				{
					// alert("Please select to whom you want to send mail.");
					document.getElementById("txt1").innerHTML = "<div class='span4'>Please select to whom you want to send mail.</div>";
					return false;
				}
				
				if(msg=="")
				{
					// alert("Please enter message.");
					document.getElementById("txt2").innerHTML = "&nbsp; Please enter message.";
					return false;
				}
				
				return true;
				// alert("done");
			}				
		</script>
	
	</head>
	
<body>
	<?php
		/* if($this->session->userdata('msg'))
		{
			echo '<script type="text/javascript">';
			echo 'alert("'.$this->session->userdata('msg').'")';
			echo '</script>'; 
			$this->session->unset_userdata('msg');
		} */
		
		if($this->session->userdata('mail_msg'))
		{
			echo '<script type="text/javascript">';
			echo 'alert("'.$this->session->userdata('mail_msg').'")';
			echo '</script>'; 
			$this->session->unset_userdata('mail_msg');
		}
	?></br>
		<div id="wrapper" class="container">
			<section class="main-content">				
				<div class="row">
					<form class="form-stacked" name="sendnewsletter" method="post" onsubmit="return form_submit()" action="<?php echo base_url() ?>index.php/Home/sendmail" enctype="multipart/form-data">
						<div class="span3">
							<br/><br/><br/><br/><br/>
							<input type="checkbox" name="customer" id="customer" value="1" onclick="clrmsg()"> &nbsp; Customers
							<br/><br/>
							<input type="checkbox" name="newsletter" id="newsletter" value="2" onclick="clrmsg()"> &nbsp; Newsletters
						</div>
						<div class="span6"></br>				
								<h4 class="title"><span class="text">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Send</strong>&nbsp; Mail</span></h4>
								<fieldset>
									<div class="row">
										<div class="span2">
											<label class="control-label"><b>To</b></label>
												<input type="text" placeholder="To" class="span3" name="to" id="to" onchange="ValidateEmail()" onkeypress="clrmsg()">
												<font size='2' color='red'><span id="txt1"></span></font>
										</div>
									</div>
									<br>
									<div class="row">
										<div class="span2">
											<label class="control-label"><b></b></label>
												<input type="file" placeholder="To" class="span3" name="image1" id="image1">
										</div>
									</div>
									<br>
									<div class="control-group">
										<label class="control-label"><b>Message</b></label>
										<div class="controls">
											<textarea rows="3" cols="3" placeholder="Message" class="span3" name="msg" id="msg" style="resize:none" onkeypress="clrmsg()"></textarea>
											<font size='2' color='red'><span id="txt2"></span></font> <br>
										</div>
									</div>
									
									<br>
									<div class="actions">
										<input tabindex="9" class="btn btn-success" type="submit" value="Send Mail">
										&nbsp; &nbsp; 
										<input tabindex="9" class="btn btn-warning" type="reset" value="Reset">
									</div>
								</fieldset>
						</div>						
					</form>					
					<div class="span3">
						<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
						<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center><br/><br>
						
						<?php
					foreach($images as $img)
					{
					?>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image3;?>" id="pn"><br></br>
					<?php
					}
					?>
						
						<!--img alt="" id="pn" src="<?php //echo base_url(); ?>img/ladies/1.jpg"-->
					</div>
				</div>
				<br>
				<div class="row">
					<div class="span2"></div>
					<div class="span6">
						<div style="width: 100%; height:243px; overflow-y: auto;">
							<table class="table table-bordered table-fixed">
								<tr class="active" align="center" size="auto">
									<th class="active"><h6><p> Sr. No </p></h6></th>
									<!--th class="active"><h6><p> All <br><input type="checkbox" name="all1" id="all1" value="2" onclick='checkedAll1(newsl);'> </p></h6></th-->
									<th class="active"><h6><p> Newsletter </p></h6></th>
								</tr>
								<?php
								$n=1;
								foreach($values as $v)
								{
									if($n%2 == 1)
									{
								?>
										<tr class="info" align="center">
											<td><?php echo $n;?></td>
											<!--td><input type="checkbox" name="check_1" id="check_1"></td-->
											<td><?php echo $v->email;?></td>
										</tr>
								<?php
									}
									else
									{
								?>
										<tr align="center">
											<td><?php echo $n;?></td>
											<!--td><input type="checkbox" name="check_1" id="check_1"></td-->
											<td><?php echo $v->email;?></td>
										</tr>
								<?php
									}
								$n++;
								}
								?>
							</table>
						</div></br>
					</div>
				</div>				
			</section>			
		</div>
	</body>					
</html>
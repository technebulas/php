<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<link href="<?php echo base_url(); ?>/css/bootstrappage.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>/css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>/css/main.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>/js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>/js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>/js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>/js/jquery.scrolltotop.js"></script>
	</head>
	<br>
	<div id="wrapper" class="container">
		<div id="ff">	
		<section class="main-content">
			<br>
			<div class="row" ></br>
				<div class="span3"><br><br><center><img alt="" src="<?php echo base_url(); ?>img/logo.png"></center></div>
				<div class="span5">
					<b style="font-size:12px">Customer Care :- </b></br>
					bookmyguruji.com</br>
					Prathmesh Nagar, Flat 8, SN 1 2 Wadgaon, BK Res - 1 Phase,<br>
					Pune - 411041,<br>
					Maharashtra, INDIA<br>
					Email-support@bookmyguruji.com<br>
					Call 7276995995<br>
				</div>
				<div class="span4">
					</br>	</br>
					<a href="https://www.facebook.com/bookmyguruji" target="_blank"> www.facebook.com/bookmyguruji</a><br>
					Helpline No:-6564864<br>
					Helpline No:-789468040<br>
					Helpline No:-1234567<br>
				</div>
			</div>
			<br>
		</section>
		</div>
	</div>
		
    </body>
</html>
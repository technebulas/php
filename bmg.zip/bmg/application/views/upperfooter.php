<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
			<script>
			function clear_msg()
			{
				document.getElementById("msg").innerHTML = "";
				document.getElementById("txtHint1").innerHTML="";
			}			
			function showHint11()
			{
				var str = document.getElementById("email1").value;
				
				if (str.length==0) { 
					document.getElementById("txtHint1").innerHTML="";
					return;
				} 
				else 
				{
					var xmlhttp=new XMLHttpRequest();
					xmlhttp.onreadystatechange=function() {
					if (xmlhttp.readyState==4 && xmlhttp.status==200) 
					{
						var r=xmlhttp.responseText;
						
						document.getElementById("txtHint1").innerHTML=xmlhttp.responseText;
						if(r=='Already exist')
						{
							document.getElementById("email1").value="";
							// Validateemail1();
							document.getElementById("exist").value = "yes";
							// return;
							
						}
						else
						{
							Validateemail1();
							// document.getElementById("exist").value = "no";
						}
					}
					}
					xmlhttp.open("GET","<?php echo base_url() ?>index.php/Home/subscribe?q="+str,true);
					xmlhttp.send();
				}    
			}
			
			function checkemail1(email1Id) 
			{
					if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email1Id)){
					// document.write("You have entered valid email1.");
					return true;
					}    
					return false;
			}
			function Validateemail1()
			{
				var email1ID=document.getElementById("email1");
				
				if (checkemail1(email1ID.value)==false){
					email1ID.value="";
					// alert("Invalid email Adderess");
					document.getElementById("msg").innerHTML = "Invalid email Address.<br>";
					email1ID.focus()
					return false
				}
					// alert('valid');
					 
			}
					 
			function onsubmit1()
			{
				var str = document.getElementById("email1").value;
				
				if(str == null || str == "")
				{
					// alert("Please Enter your email ID");
					document.getElementById("msg").innerHTML = "Please Enter your email Id.<br>";
					return false;
				}  
				else if (str.length==0) { 
					document.getElementById("txtHint1").innerHTML="";
					return;
				} 
				else 
				{
					var xmlhttp=new XMLHttpRequest();
					xmlhttp.onreadystatechange=function() {
						if (xmlhttp.readyState==4 && xmlhttp.status==200) 
						{
							var r=xmlhttp.responseText;
							
							document.getElementById("txtHint1").innerHTML=xmlhttp.responseText;
							if(r=='Already exist')
							{
								document.getElementById("email1").value="";
								// Validateemail1();
								document.getElementById("exist").value = "yes";
								// return;
								
							}
							else
							{
								Validateemail2();
								// document.getElementById("exist").value = "no";
							}
						}
					}
					xmlhttp.open("GET","<?php echo base_url() ?>index.php/Home/subscribe?q="+str,true);
					xmlhttp.send();
				}     
			}
					function checkemail2(email1Id) 
					{
						if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email1Id))
						{
							return true;
						}    
						return false;
					}
					
					function Validateemail2()
					{					
						var email1ID=document.getElementById("email1");
						
						if (checkemail2(email1ID.value)==false){
							email1ID.value="";
							document.getElementById("msg").innerHTML = "Invalid email address.<br>";
							email1ID.focus()
							return false
						}
							document.forms['subscribe'].submit();
					}
	</script>
	</head>
	<style>
		.thumb {
		margin-right:3px;}

		.normal {
		border:3px solid #000000;}
		
		p{
			color:#FF6600;

		}
		.icon-orange
		{
			color:#FF6600;
		}
	</style>
    <body>
	<?php
		if($this->session->userdata('news_letter_msg'))
		{
			echo '<script type="text/javascript">';
			echo 'alert("'.$this->session->userdata('news_letter_msg').'")';
			echo '</script>'; 
			$this->session->unset_userdata('news_letter_msg');
		}
	?>
		<div id="wrapper" class="container">
			<div class="row">
				<div class="span4">
					<h4><p>News Letter</p></h4>
					<form name="subscribe" action="<?php echo base_url();?>index.php/Login/newsletter" method="post">
						<p><span class="glyphicon icon-envelope icon-orange"></span>&nbsp;&nbsp;Sign up for News Letter</p>
						<p><input type="text" class="span3" name="email1" id="email1" placeholder="Email ID" onkeypress="clear_msg()" onchange="showHint11(this.value);">
						<font size='2' color='red'><span id="txtHint1"></span></font>
						</p>
						<font size='2' color='red'><span id="msg"></span></font><br>
						<p><input tabindex="3" class="btn btn-warning" type="button" value="Subscribe" onclick="onsubmit1();" ></p>
					</form>
				</div>

				<div class="span3">
								
					<h4><p>Key Features</p></h4>
					<li style="color: orange"><p>Convenient and Transparent Services.</p></li>
					<li style="color: orange"><p>100% Genuine Products.</p></li>
					<li style="color: orange"><p>Best in Town Guruji/Panditji.</p></li>	
					<li style="color: orange"><p>All Over Pune Services Available.</p></li>	
					
				</div>
				<div class="span1"></div>
				<div class="span3">
				<h4><p>Find us on Facebook</p></h4>
                    <div id="fb-root"></div>
					<script>(function(d, s, id) {
                      var js, fjs = d.getElementsByTagName(s)[0];
                      if (d.getElementById(id)) return;
                      js = d.createElement(s); js.id = id;
                      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
                      fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));
                    </script>
						<div class="fb-like-box" 
						data-href="https://www.facebook.com/bookmyguruji" 
						data-colorscheme="light" 
						data-show-faces="true" 
						data-header="false" 
						data-stream="false" 
						data-show-border="false">
                    </div>
				</div>
			</div>
		</div>
		<script src="themes/js/common.js"></script>
		<script src="themes/js/jquery.flexslider-min.js"></script>
		<script type="text/javascript">
			$(function() {
				$(document).ready(function() {
					$('.flexslider').flexslider({
						animation: "fade",
						slideshowSpeed: 4000,
						animationSpeed: 600,
						controlNav: false,
						directionNav: true,
						controlsContainer: ".flex-container" // the container that holds the flexslider
					});
				});
			});
		</script>
    </body>
</html>
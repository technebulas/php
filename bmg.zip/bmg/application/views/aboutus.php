<!DOCTYPE html>
<html lang="en">
	<head>
	</head>
	</br>
	<div id="wrapper" class="container">			
		<div id="ff">	
		<section class="main-content">
		<div class="row" ></br></br>
			<div class="span3"></br></br></br></br><center><img alt="" src="<?php echo base_url(); ?>img/logo.png"><center></div>
			<div class="span7">
			<center><h4>About Us</h4></center>
			<div style="text-align:justify;">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;bookmyguruji.com is an endeavor to bring spirituality back into the lives of the people. 
				With the fast moving life people have migrated to places, wherein it has become difficult
				to come closer to God. For instance,there are people who want to prepare a vastushanti pooja,
				in their new home, but they have a trouble finding someone who can do this. 
				Where; bookmyguruji.com works. bookmyguruji.com is a one stop solution to this
				problem and many more. bookmyguruji.com is an online portal through which you
				can book your poojas,Pooja  samagri and even a Guruji who can perform them.<br>
				bookmyguruji.com helps you to find out Guruji based on your preference, anywhere in Pune.
			</div>
		</div>
	</div></br>
		</section>
		</div>
		</div>
    </body>
</html>
<!DOCTYPE html>
<html lang="en">
	<head>
		<script type="text/javascript">
			
			function set_action(v1,v2)
			{
				document.forms["viewform"]["hidd_action"].value = v1;
				document.forms["viewform"]["hidd_enq_id"].value = v2;
				
				cnf = confirm("Do you really want to done this pooja?");
					
				if(cnf == true)
				{
					document.forms["viewform"].submit();
				}
				else
				{
					return;
				}
			}
		</script>
	</head>
	<body>
	
	<br>
	<div id="wrapper" class="container">
	<br>
		<?php
		
			foreach($values as $value)
			{
		?>
			<form  name="viewform" action= "<?php echo base_url() ?>index.php/order_detail_edit/specific_order" method="post">
					
				<input type="hidden" name="hidd_enq_id" id="hidd_enq_id"/>
				<input type="hidden" name="hidd_action" id="hidd_action"/>
				
				<div class="row">
					<div class="span5">
						<table>
							<tr>
								<td><h6>Name :</h6></td>
								<td><input type="text" value="<?=$value->full_name?>" style="background-color:white;" disabled></td>
							</tr>
							<tr>
								<td><h6>Login Name<br>(Email) :</h6></td>
								<td><input type="text" value="<?=$value->username?>" style="background-color:white;" disabled></td>
							</tr>
							<tr>
								<td><h6>Contact No. :</h6></td>
								<td><input type="text" value="<?=$value->enq_contact_no?>" style="background-color:white;" disabled></td>
							</tr>
							<tr>
								<td><h6>Enquiry Date :</h6></td>
								<td><input type="text" value="<?=date("d/m/Y", strtotime($value->enq_date))?>" style="background-color:white;" disabled></td>
							</tr>
							<tr>
								<td><h6>Booking Details :</h6></td>
								<td><input type="text" value="<?=date("d/m/Y", strtotime($value->booking_date))?> <?=$value->book_time?>" style="background-color:white;" disabled></td>
							</tr>
						</table>
					</div>
					<div class="span6">
						<table>
							<tr>
								<td><h6>Address :</h6></td>
								<td><textarea style="resize:none; background-color:white;" disabled><?=$value->add1.','.$value->add2.','.$value->add3.','.$value->add4.','.$value->add5.','.$value->add6?></textarea></td>
							</tr>
							<tr>
								<td><h6>Comment :</h6></td>
								<td><textarea style="resize:none; background-color:white;" disabled><?=$value->comment?></textarea></td>
							</tr>
							<tr>
								<td><h6>Selected Pooja :</h6></td>
								<td>
									<center>
									<p><b><?=ucwords($value->pj_name)?></b>
									<?php
										$sam_st = $value->sam_status;
										
										$ind = $value->poojas;
												
										if($ind >= 1 and $ind <= 14)
										{
											echo "(Home Pooja)";
										}
										else if($ind >= 15 and $ind <= 19)
										{
											echo "(Office Pooja)";
										}
										else if($ind >= 20  and $ind <= 30)
										{
											echo "(Festival Pooja)";
										}
										else if($ind >= 31 and $ind <= 37)
										{
											echo "(Functional Pooja)";
										}
										else
										{
											echo "(Other Pooja)";
										}
										echo "<br>Rs. ".$value->pooja_amt."<br>";
										
										if($sam_st == 'yes')
											echo "(with samagree)";
										else
											echo "(without samagree)";
											
										echo "</p>";
									?>
									</center>
								</td>
							</tr>
						</table>
					</div>
				</div>
				<div class="row">
					<div class="span5"></div>
					<div class="span2">
						<input class="btn btn-warning" type="button" value="Done" onclick="set_action(2,<?=$value->enq_id?>)">
					</div>
				</div>
				
			</form>	
			<br>
		<?php
			}
		?>
	</div>
	</body>
</html>
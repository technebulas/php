<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		
		<!-- Date picker css & js-->
		<link href="<?php echo base_url(); ?>css/runnable.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>js/script.js"></script>	
		<script src="<?php echo base_url(); ?>js/script1.js"></script>	

		<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css" />
		<script src="<?php echo base_url(); ?>js/jquery-1.9.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
		<style>
		#pn:hover
		{
			border: 1px solid #FAA732;
		}
		#sl:hover
		{
			background-color: #FFE6CC;
		}
		</style>	
		
		<script>
			function clr_msg()
			{
				document.getElementById('txt1').innerHTML = "";
				document.getElementById('txt2').innerHTML = "";
				document.getElementById('txt3').innerHTML = "";
			}
			
			function check1()
			{
				var pass=document.getElementById("upass").value;
				var pass1=document.getElementById("cupass").value;
				
				if(pass1!='')
				{
					if(pass != pass1)
					{
						// alert("Enter Password not match ! Please Re enter It.");
						document.getElementById("txt3").innerHTML = "&nbsp; Both password should be same.";
						document.getElementById("upass").value = "";
					}
					return false;
				}
			}
			
			function check()
			{
				var pass=document.getElementById("upass").value;
				var pass1=document.getElementById("cupass").value;

				if(pass != pass1)
				{
					// alert("Enter Password not match ! Please Re enter Password");
					document.getElementById('txt3').innerHTML = "&nbsp; Both password should be same. Please try again.";
					document.getElementById("cupass").value="";
					return false;
				}
			} 
			
			function submit_form()
			{
				var pass=document.getElementById("upass").value;
				var pass1=document.getElementById("cupass").value;				
				
				if(pass=="")
				{
					// alert("Plz Fill New Password");
					document.getElementById('txt1').innerHTML = "&nbsp; Please Fill New Password.";
					return false;
				}
				else if(pass1=="")
				{
					// alert("Plz Fill Confirm Password");
					document.getElementById('txt2').innerHTML = "&nbsp; Please Fill Confirm Password.";
					return false;
				}
				else
				{
					document.forms['forget_password'].submit();
					return true;
				}
			}
		</script>
	</head>
	
<body>
	<div id="wrapper" class="container">
		<section class="main-content">				
			<div class="row">
				<div class="span3"></div>
				<div class="span6">	</br>				
					<h4 class="title"><span class="text">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Enter New </strong> Password</span></h4>
					<form class="form-stacked" name="forget_password" method="post" action="<?php echo base_url() ?>index.php/Home/forget_pass">
						<fieldset>							
							<?php
								$email=$_GET['uname'];
							?>
							<div class="control-group">
								<b>Email Id</b>
								<div class="controls">
									<input type="text" placeholder="Email Id" class="span3" name="email" id="email" value="<?=$email?>" disabled style="background-color:white;">
									<input type="hidden" name="pass_recover" id="pass_recover" value="<?=$email?>">											
								</div>
							</div>
							
							<div class="control-group">
								<b>New Password</b>
								<div class="controls">
									<input type="password"  placeholder="Password" class="span3" name="upass" id="upass" onchange="check1()" onkeypress="clr_msg()">
									<font size='2' color='red'><span id="txt1"></span></font>
								</div>
							</div>
							<div class="control-group">
								<b>Confirm Password</b>
								<div class="controls">
									<input type="password"  placeholder="Confirm Password" class="span3" name="cupass" id="cupass" onchange="check()" onkeypress="clr_msg()">
									<font size='2' color='red'><span id="txt2"></span></font>
								</div>
							</div>							
							<div class="control-group">								
								<div class="controls">
									<font size='2' color='red'><span id="txt3"></span></font>
								</div>
							</div>						
							<br>
							<div class="actions">
								<input tabindex="9" class="btn btn-success" type="button" value="Submit" onclick="submit_form();">
								&nbsp; &nbsp; 
								<input tabindex="9" class="btn btn-warning" type="reset" value="Reset" onclick="clr_msg()">
							</div>
						</fieldset>
					</form>					
				</div>
				<div class="span3">
					<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
					<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center>
				</div>
				<br>
			</div>				
		</section>			
	</div>
</body>					
</html>
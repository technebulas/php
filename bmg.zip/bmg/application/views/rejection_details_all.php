<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
	</head>

	<body>
		<br>
	<div id="wrapper" class="container">
		<div class="row">
		<br>
		<div class="span12">
			<center><h4>Rejected Enquiries</h4></center><br>
			<div style="overflow: auto; height:600px; width:auto">
				<table class="table table-bordered table-fixed">
					<tr class="active" align="center" size="auto">
						<th class="active"><h6><p>Sr. No</p></h6></th>
						<th class="active"><h6><p>Enq. ID</p></h6></th>
						<th class="active"><h6><p>Cust. Name</p></h6></th>
						<th class="active"><h6><p>Mail ID</p></h6></th>
						<th class="active"><h6><p>Reg. Date</p></h6></th>
						<th class="active"><h6><p>Booking Date</p></h6></th>
						<th class="active"><h6><p>Pooja Details</p></h6></th>
						<th class="active"><h6><p>Rejected By</p></h6></th>
						<th class="active"><h6><p>Remark</p></h6></th>
					</tr>
						
					<?php 
					
					$no = 1;
					foreach($values as $value)//order
					{
						
						if($no%2==1)
						{
					?>
							<tr class="info" align = "center">
								<td><?=$no?></td>
								<td><?=$value->enq_id?></td>
								<td><?=$value->full_name?></td>
								<td><?=$value->username?></td>
								<td><?=date("d/m/Y", strtotime($value->enq_date))?></td>
								<td><?=date("d/m/Y", strtotime($value->booking_date))?></td>
								<td>
									<p><b><?=ucwords($value->pj_name)?></b>
									<?php
										$sam_st = $value->sam_status;
										
										$ind = $value->poojas;
												
										echo "<br>";
										if($ind >= 1 and $ind <= 14)
										{
											echo "(Home Pooja)";
										}
										else if($ind >= 15 and $ind <= 19)
										{
											echo "(Office Pooja)";
										}
										else if($ind >= 20  and $ind <= 30)
										{
											echo "(Festival Pooja)";
										}
										else if($ind >= 31 and $ind <= 37)
										{
											echo "(Functional Pooja)";
										}
										else
										{
											echo "(Other Pooja)";
										}
										echo "</p>";
										
										if($sam_st == 'yes')
											echo "(with samagree)";
										else
											echo "(without samagree)";
									?>
								</td>
								
								<td><?=$value->reject_by?></td>
								<td><?=$value->remark?></td>
							</tr>
					<?php
						}
						else
						{
					?>
							<tr align = "center">
								<td><?=$no?></td>
								<td><?=$value->enq_id?></td>
								<td><?=$value->full_name?></td>
								<td><?=$value->username?></td>
								<td><?=date("d/m/Y", strtotime($value->enq_date))?></td>
								<td><?=date("d/m/Y", strtotime($value->booking_date))?></td>
								<td>
									<p><b><?=ucwords($value->pj_name)?></b>
									<?php
										$sam_st = $value->sam_status;
										
										$ind = $value->poojas;
												
										echo "<br>";
										if($ind >= 1 and $ind <= 14)
										{
											echo "(Home Pooja)";
										}
										else if($ind >= 15 and $ind <= 19)
										{
											echo "(Office Pooja)";
										}
										else if($ind >= 20  and $ind <= 30)
										{
											echo "(Festival Pooja)";
										}
										else if($ind >= 31 and $ind <= 37)
										{
											echo "(Functional Pooja)";
										}
										else
										{
											echo "(Other Pooja)";
										}
										echo "</p>";
										
										if($sam_st == 'yes')
											echo "(with samagree)";
										else
											echo "(without samagree)";
									?>
								</td>
								
								<td><?=$value->reject_by?></td>
								<td><?=$value->remark?></td>
							</tr>
					<?php
						}
						
						$no++;
					}
					
					if($no==1)
					{
						echo "<tr><th colspan='8'><b style='color:red;'>No Record Found</b></th></tr>";
					}
					
					?>	
				</table>
			</div>
		</div>
		</div>
	</div>
	</body>
</html>
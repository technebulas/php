		<script type="text/javascript">
			
			function set_action(v1,v2)
			{
				var cnf = "";
				
				if(v1 == 0)
				{
					cnf = prompt("Please enter reason for reject pooja", "");
					
					if(cnf != null && cnf != "")
					{
						document.forms["viewform"]["hidd_msg"].value = cnf;
						document.forms["viewform"]["hidd_action"].value = v1;
						document.forms["viewform"]["hidd_enq_id"].value = v2;
						document.forms["viewform"].submit();
					}
					else
					{
						return;
					}

					/* cnf = confirm("Do you Really Want to Reject your Pooja ?");
				
					if(cnf == true)
					{
						document.forms["viewform"]["hidd_action"].value = v1;
						document.forms["viewform"]["hidd_enq_id"].value = v2;
						document.forms["viewform"].submit();
					}
					else
						return; */
				}
				else
				{
					document.forms["viewform"]["hidd_action"].value = v1;
					document.forms["viewform"]["hidd_enq_id"].value = v2;
					document.forms["viewform"].submit();
				}
			}
   
			
		</script>
		
		<div class="span9"><br>
			<center><h4>Orders Ready to Pay</h4></center>
			<div style=" overflow: auto;">
			<table class="table table-bordered table-fixed">
				<tr class="active" align="center" size="auto">
					<th class="active"><h6><p>Sr. No</p></h6></th>
					<th class="active"><h6><p>Enquiry ID</p></h6></th>
					<th class="active"><h6><p>Booking Details</p></h6></th>
					<th class="active"><h6><p>Pooja Details</p></h6></th>
					<th class="active"><h6><p>Price</p></h6></th>
					<th class="active"><h6><p>Action</p></h6></th>
				</tr>
				
				<form  name="viewform" action= "<?php echo base_url() ?>index.php/order_detail_edit/change_enq" method="post">
					
					<input type="hidden" name="hidd_enq_id" id="hidd_enq_id"/>
					<input type="hidden" name="hidd_action" id="hidd_action">
					<input type="hidden" name="hidd_msg" id="hidd_msg">
					<?php 
					
					$no = 1;
					foreach($values2 as $value2)//order
					{
						
						if($no%2==1)
						{
					?>
							<tr class="info" align = "center">
								<td><?=$no?></td>
								<td><?=$value2->enq_id?></td>
								<td><?=date("d/m/Y", strtotime($value2->booking_date))?><br><?=$value2->book_time?></td>
								<td><?=$value2->pj_name?></td>
								<?php
									$sam_sta = $value2->sam_status;
									
									if($sam_sta == 'yes')
									{
								?>
								<td>with samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
									else
									{
								?>
								<td>without samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
								?>
								<td>
									<!--<input class="btn btn-warning" type="button" value="Pay" onclick="set_action(1,<?=$value2->enq_id?>)">-->
									<input class="btn btn-warning" type="button" value="Reject" onclick="set_action(0,<?=$value2->enq_id?>)">
								</td>
							</tr>
					<?php
						}
						else
						{
					?>
							<tr align = "center">
								<td><?=$no?></td>
								<td><?=$value2->enq_id?></td>
								<td><?=date("d/m/Y", strtotime($value2->booking_date))?><br><?=$value2->book_time?></td>
								<td><?=$value2->pj_name?></td>
								<?php
									$sam_sta = $value2->sam_status;
									
									if($sam_sta == 'yes')
									{
								?>
								<td>with samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
									else
									{
								?>
								<td>without samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
								?>
								<td>
									<!--<input class="btn btn-warning" type="button" value="Pay" onclick="set_action(1,<?=$value2->enq_id?>)">-->
									<input class="btn btn-warning" type="button" value="Reject" onclick="set_action(0,<?=$value2->enq_id?>)">
								</td>
							</tr>
					<?php
						}
						
						$no++;
					}
					
					if($no==1)
					{
						echo "<tr><th colspan='8'><b style='color:red;'>No Record Found</b></th></tr>";
					}
					
					?>	
				</form>										
			</table>
		</div>						
		</div>						
	</div>						
	</div>						
	</div>						
	</body>
</html>
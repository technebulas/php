<!DOCTYPE html>
<html lang="en">
	<head>
		<script language="javascript" type="text/javascript">
			function allsubmit()
			{
				var t1 = document.getElementById('title1').value;
				var t2 = document.getElementById('title2').value;
				
				if(t1 == '')
				{
					document.getElementById('msg1').innerHTML = "Please fill the First Title<br>";
					return false;
				}
				else
				{
					document.getElementById('msg1').innerHTML = "";
				}
				
				if(t2 == '')
				{
					document.getElementById('msg2').innerHTML = "Please fill the Second Title<br>";
					return false;
				}
				else
				{
					document.getElementById('msg2').innerHTML = "";
				}
				
				return true;
			}
			
		</script>
	</head>
	<body>
	<br>
	<div id="wrapper" class="container">
		<form class="form-stacked" name="slider_form" method="post" onsubmit="return allsubmit()" action="<?php echo base_url() ?>index.php/Home/towards_slider_done">
			<br>
			<div class="row">
				<div class="span2"></div>
				<?php
				
				for($inc=1; $inc<=2; $inc++)
				{
				
				?>
					<div class="span4">
						Slider <?=$inc?> Title
						<input class="span4" type="text" name="title<?=$inc?>" id="title<?=$inc?>"/>
						<br>
						
						<span id="msg<?=$inc?>" style="color:red;"></span>
						<br>
						
						<?php
						for($inc2=1; $inc2<=6; $inc2++)
						{
						?>
							Image <?=$inc2?>
							<select name="sl<?=$inc?>_img<?=$inc2?>" id="sl<?=$inc?>_img<?=$inc2?>">
								<option value="Select">Select</option>
							<?php
								foreach($values as $value)
								{
							?>
								<option value="<?=$value->pooja_id?>"><?=$value->pooja_id?>&nbsp;<?=$value->pooja_name?></option>
							<?php
								}
							?>
							</select>
							<br>
						<?php
						}
						?>
					</div>
				<?php
				}
				?>
			</div>
			<br>
			<div class="row">
				<center>
					<input type="submit" class="btn btn-success" value="Submit"/>
				</center>
			</div>
		</form>
	</div>
	</body>
</html>
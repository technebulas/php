<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dhtmlxcalendar.css"/>
		<script src="<?php echo base_url(); ?>js/dhtmlxcalendar.js"></script>
		<!-- Date picker css & js-->
		<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css" />
		<script src="<?php echo base_url(); ?>js/jquery-1.9.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
		<style>
		#pn:hover
		{
			border: 1px solid #FAA732;
		}
		#sl:hover
		{
			background-color: #FFE6CC;
		}
		ss
		{
			color:#F60;
		}
		</style>	
		
		<script language="javascript" type="text/javascript">
				function validateText(val)	
				{
					var str = val.value;
					if(!str.match(/^[A-Za-z ]*$/))
					{
						// alert("Please enter valid information...!");
						if(val.id == 'full_name')
						{  		
							document.getElementById("txt2").innerHTML = "&nbsp; Please enter valid information !";
						}
						else if(val.id == 'add5')
						{
							document.getElementById("txt8").innerHTML = "&nbsp; Please enter valid information !";
						}						
						val.value="";
						return false;
					}
				}	
				
				function reset_msg()
				{
					document.getElementById("txt1").innerHTML = "";
					document.getElementById("txt2").innerHTML = "";
					document.getElementById("txt3").innerHTML = "";
					document.getElementById("txt4").innerHTML = "";
					document.getElementById("txt5").innerHTML = "";
					document.getElementById("txt6").innerHTML = "";
					document.getElementById("txt7").innerHTML = "";
					document.getElementById("txt8").innerHTML = "";
					document.getElementById("txt9").innerHTML = "";
					document.getElementById("txt10").innerHTML = "";
					document.getElementById("pass").innerHTML = "";
					document.getElementById("other").innerHTML = "";
				}
				
				function checkEmail(emailId) {
					if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailId)){
					// document.write("You have entered valid email.");
					return true;
					}    
					return false;
					}
					function ValidateEmail(){
					
						var emailID=document.getElementById("email");

						/* if ((emailID.value==null)||(emailID.value=="")){
							alert("Please Enter your Email ID")
							emailID.focus()
							return false
						} */
						if (checkEmail(emailID.value)==false){
							emailID.value="";
							// alert("Invalid Email Adderess");
							document.getElementById("txt1").innerHTML = "Invalid Email Adderess";
							emailID.focus();
							return false;
						}
							// alert('valid');
							return true;
					 }
				function val_numberTen(val)
				{
					var no = val.value;
					
					if(!no.match(/^[0-9]{10}$/))
					{
						// alert("Please enter 10 digit number ...!");
						document.getElementById("txt3").innerHTML = "&nbsp; Please enter 10 digit number !";
						val.value="";
						return false;
					}
				}

				function validpin(val)
				{
					var pin = val.value;
					
					if(!pin.match(/^[0-9]{6}$/))
					{
						// alert("Please enter 6 digit Pin number ...!");
						document.getElementById("txt9").innerHTML = "&nbsp; Please enter 6 digit Pin number.";
						val.value="";
						return false;
					}
				}
				
			function showpooja(val)
			{
				var pooja = val.value;
				
				document.getElementById('home pooja').style.display='none';
				document.getElementById('office pooja').style.display='none';
				document.getElementById('festivals pooja').style.display='none';
				document.getElementById('functional pooja').style.display='none';
				document.getElementById('other_pooja_div').style.display='none';
				
				if(pooja == 'OTHER')
					document.getElementById('other_pooja_div').style.display='inline';
				else
					document.getElementById(pooja).style.display='inline';
				
			}
			window.onload=reset();
			function reset()
			{
				document.getElementById('date_from').style.display="inline";
				document.getElementById('date_to').style.display="inline";
			}
			
			function set_dates(v)
			{
				if(v==1)
				{
					document.getElementById('date_to').style.display="none";
				}
				else
				{
					document.getElementById('date_to').style.display="inline";
					document.getElementById('date_from').style.display="inline";
					window.onload=reset();
				}
			}
			
			function terms_condition()
			{
				var agree_terms = document.getElementById('cfm');
				
				if(agree_terms.checked)
					document.getElementById("policy").innerHTML = "";
				else
					document.getElementById("policy").innerHTML = "<p style='color:red;'>you must agree to bookmyguruji Terms of use & privacy policy.</p>";
			}		
			
			function final_submit()
			{
				var mailId = document.getElementById("email").value;
				var full_name = document.getElementById("full_name").value;
				var upass;
				var contact = document.getElementById("contact").value;
				var add1 = document.getElementById("add1").value;
				var add2 = document.getElementById("add2").value;
				var add3 = document.getElementById("add3").value;
				var add4 = document.getElementById("add4").value;
				var add5 = document.getElementById("add5").value;
				var add6 = document.getElementById("add6").value;
				var type;
				var agree = document.getElementById("cfm");
				var pass_check = document.getElementById("exist").value;
				var hidd_navi = document.getElementById("hidd_navi").value;
				var xx,x = 0;
				
				if(mailId == "")
				{
					// alert("please enter email Id.");
					document.getElementById("txt1").innerHTML = "&nbsp; Please enter email Id.";
					 document.getElementById("email").focus();
					return false;
				}
				if(full_name == "")
				{
					// alert("please enter full name.");
					document.getElementById("txt2").innerHTML = "&nbsp; Please enter full name.";
					document.getElementById("full_name").focus();
					return false;
				}				
				if(pass_check != "yes")		
				{
					upass = document.getElementById("upass").value;
					if(upass == "")
					{
						// alert("please enter password.");
						document.getElementById("pass").innerHTML = "&nbsp; Please enter password.";
						document.getElementById("upass").focus();
						return false;
					}
				}
				if(contact == "")
				{
					// alert("please enter contact no.");
					document.getElementById("txt3").innerHTML = "&nbsp; Please enter contact no.";
					document.getElementById("contact").focus();
					return false;
				}
				if(add1 == "")
				{
					// alert("please enter plot/flat no.");
					document.getElementById("txt4").innerHTML = "&nbsp; Please enter plot/flat no.";
					document.getElementById("add1").focus();
					return false;
				}
				if(add2 == "")
				{
					// alert("please enter building/apartment name.");
					document.getElementById("txt5").innerHTML = "&nbsp; Please enter building/apartment name.";
					document.getElementById("add2").focus();
					return false;
				}
				if(add3 == "")
				{
					// alert("please enter street/locality.");
					document.getElementById("txt6").innerHTML = "&nbsp; Please enter street/locality.";
					document.getElementById("add3").focus();
					return false;
				}
				if(add4 == "")
				{
					// alert("please enter area/landmark.");
					document.getElementById("txt7").innerHTML = "&nbsp; Please enter area/landmark.";
					document.getElementById("add4").focus();
					return false;
				}
				if(add5 == "")
				{
					// alert("please enter city.");
					document.getElementById("txt8").innerHTML = "&nbsp; Please enter city.";
					document.getElementById("add5").focus();
					return false;
				}
				if(add6 == "")
				{
					// alert("please enter pin code.");
					document.getElementById("txt9").innerHTML = "&nbsp; Please enter pin code.";
					document.getElementById("add6").focus();
					return false;
				}
				if(hidd_navi == "direct")
				{
					type = document.getElementById("type").value;
					
					if(type == "Select")
					{
						// alert("please select pooja.");
						document.getElementById("txt10").innerHTML = "&nbsp; Please select pooja.<br>";
						document.getElementById("type").focus();
						return false;
					}
					else if(type == "OTHER")
					{
						x = document.getElementById("other_pooja_txt").value;
						if(x == "")
						{
							// alert("enter pooja.");
							document.getElementById("other").innerHTML = "&nbsp; Please enter pooja.<br>";
							document.getElementById("other_pooja_txt").focus();
							return false;
						}
					}
					else
					{
						//document.getElementById("invi").value;
						
						for(var i=1; i<=37; i++ )
						{
							xx = document.getElementById("invi"+i).checked;
							
							if(xx == true)
							{
								x = 1;
								break;
							}
						}
						
						if(x == 0)
						{
							// alert("please select pooja.");
							document.getElementById("txt10").innerHTML = "&nbsp; Please select pooja.<br>";
							return false;
						}
					}
				}
				if(!agree.checked)
				{
					document.getElementById("policy").innerHTML = "<p style='color:red;'>you must agree to bookmyguruji Terms of use & privacy policy.</p>";
					return false;
				}
				
				//alert("done");
				//document.forms["book_guruji"].submit();
				return true;
			}
		
		</script>
	</head>
	
<body onload="doOnLoad();"></br>
	<?php
		/* 		
		if($this->session->userdata('err_msg'))
		{
			echo '<script type="text/javascript">';
			echo 'alert("'.$this->session->userdata('err_msg').'")';
			echo '</script>'; 
			$this->session->unset_userdata('err_msg');
		}
		*/
	?>
	
	
		<script>
			function showHint(str)
			{
				if (str.length==0)
				{ 
					document.getElementById("txtHint").innerHTML="";
					return;
				}
				else 
				{
					var xmlhttp=new XMLHttpRequest();
					xmlhttp.onreadystatechange=function() {
						if (xmlhttp.readyState==4 && xmlhttp.status==200) 
						{
							var r=xmlhttp.responseText;
							
							document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
							if(r=='Already exist')
							{
								ValidateEmail();
								// document.getElementById('sh_pass2').style.display="none";
								document.getElementById("exist").value = "exist";
								document.getElementById("all_data_contatiner").style.display = "none";
								document.getElementById("redirect_link").style.display = "inline";
								
							}
							else
							{
								ValidateEmail();
								document.getElementById('sh_pass2').style.display="inline";
								document.getElementById("all_data_contatiner").style.display = "inline";
								document.getElementById("redirect_link").style.display = "none";
								document.getElementById("exist").value = "no";
							}
						}
					}
					xmlhttp.open("GET","<?php echo base_url() ?>index.php/Home/chaeck?q="+str,true);
					xmlhttp.send();
				}
			}

		</script>
	<div id="wrapper" class="container">
		<section class="main-content">				
			<div class="row">
				<div class="span2"></div>
				<div class="span7">	</br>				
					<h4 class="title"><span class="text">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Book</strong> My Guruji</span></h4>
					<form class="form-stacked" name="book_guruji" method="post" onsubmit="return final_submit()" action="<?php echo base_url() ?>index.php/order_detail_edit/insert_enquiry">
						<fieldset>
						
							<input type="hidden" name="exist" id="exist" value="no">
							
							<?php
							
							if($this->session->userdata('user_data'))
							{
								$rec = $this->session->userdata("user_data");
							?>
								<input type="hidden" name="hid_email" id="hid_email" value="<?=$rec[0]->username?>">
								<input type="hidden" name="hid_fullname" id="hid_fullname" value="<?=$rec[0]->fullname?>">
								<input type="hidden" name="hid_cont" id="hid_cont" value="<?=$rec[0]->contact_no?>">
								<input type="hidden" name="hid_add1" id="hid_add1" value="<?=$rec[0]->add1?>">
								<input type="hidden" name="hid_add2" id="hid_add2" value="<?=$rec[0]->add2?>">
								<input type="hidden" name="hid_add3" id="hid_add3" value="<?=$rec[0]->add3?>">
								<input type="hidden" name="hid_add4" id="hid_add4" value="<?=$rec[0]->add4?>">
								<input type="hidden" name="hid_add5" id="hid_add5" value="<?=$rec[0]->add5?>">
								<input type="hidden" name="hid_add6" id="hid_add6" value="<?=$rec[0]->add6?>">
								
								<script type="text/javascript">
									$(document).ready(function(){
									$("#email").attr("disabled", true);									
									document.getElementById("email").value = document.getElementById("hid_email").value;
									document.getElementById("full_name").value = document.getElementById("hid_fullname").value;
									document.getElementById("contact").value = document.getElementById("hid_cont").value;
									document.getElementById("add1").value = document.getElementById("hid_add1").value;
									document.getElementById("add2").value = document.getElementById("hid_add2").value;
									document.getElementById("add3").value = document.getElementById("hid_add3").value;
									document.getElementById("add4").value = document.getElementById("hid_add4").value;
									document.getElementById("add5").value = document.getElementById("hid_add5").value;
									document.getElementById("add6").value = document.getElementById("hid_add6").value;
									
									document.getElementById("cfm").checked = true; 									
									document.getElementById('sh_pass2').style.display="none";
									document.getElementById("exist").value = "yes";
									});
								</script>
							<?php
							}
							?>
							<div class="control-group">
								<b>Email Id</b>
								<div class="controls">
									<input type="text" placeholder="Email Id" class="span3" name="email" maxlength="40" id="email" style="background-color:white;" onchange="showHint(this.value);" onkeypress="reset_msg()">
									<font size='2' color='red'> &nbsp; <span id="txtHint"></span> <span id="txt1"></span></font></font><br>
								</div>
							</div>
							
							<div id="redirect_link" style="display:none;">
								<a href="<?php echo base_url();?>/index.php/Home/register">
									<b>To Login Click Here</b>
								</a>
							</div>
							
							<div id="all_data_contatiner">
							<div class="control-group">
								<b>Name</b>
								<div class="controls">
									<input type="text" placeholder="Full Name" class="span3" maxlength="45" name="full_name" id="full_name" onchange="validateText(this)" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt2"></span></font><br>
								</div>
							</div>
							<div id="sh_pass2">
								<div class="control-group">
									<b>Password</b>
									<div class="controls">
										<input type="password"  placeholder="Password" maxlength="25" class="span3" name="upass" id="upass" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="pass"></span></font><br>
									</div>
								</div>
							</div>
							<div class="control-group">
								<b>Contact No</b>
								<div class="controls">
									<input type="text" placeholder="Contact" class="span3" id="contact" name="contact" onchange="val_numberTen(this)" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt3"></span></font><br>
								</div>
							</div>
							<div class="control-group">
								<b>Address</b>
							</div>
							<div class="control-group">
								Plot/Flat No
								<div class="controls">
									<input type="text" placeholder="Plot No" maxlength="15" class="span3" name="add1" id="add1" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt4"></span></font><br>
								</div>
							</div>
							<div class="control-group">
								Building/Apartment Name
								<div class="controls">
									<input type="text" placeholder="Building/Apartment Name" maxlength="25" class="span3" name="add2" id="add2" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt5"></span></font><br>
								</div>
							</div>
							<div class="control-group">
								Street/Locality
								<div class="controls">
									<input type="text" placeholder="Street/Locality" maxlength="35" class="span3" name="add3" id="add3" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt6"></span></font><br>
								</div>
							</div>
							<div class="control-group">
								Area/Landmark
								<div class="controls">
									<input type="text" placeholder="Area/Landmark"  class="span3" maxlength="30" name="add4" id="add4" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt7"></span></font><br>
								</div>
							</div>
							<div class="control-group">
									City
								<div class="controls">
									<input type="text" placeholder="City"  class="span3" name="add5" maxlength="30" id="add5" onchange="validateText(this)" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt8"></span></font><br>
								</div>
							</div>
							<div class="control-group">
								Pincode
								<div class="controls">
									<input type="text" placeholder="Pincode"  class="span3" name="add6" id="add6" onchange="validpin(this)" onkeypress="reset_msg()">
									<font size='2' color='red'><span id="txt9"></span></font><br>
								</div>
							</div>
							
							<input type="hidden" name="hidd_navi" id="hidd_navi">
							
							<?php
							
							/* if($this->session->userdata('reference'))
							{
								$this->session->unset_userdata('reference');
							} */
							
							if(!$this->session->userdata('selected_pooja_detail'))
							{
							?>
								<script type="text/javascript">
									$(document).ready(function(){
									document.getElementById("hidd_navi").value = "direct";
									});
									
									
									function check_total(v)
									{
										var id = parseInt(v.value);
										
										var p1 = parseInt(document.getElementById("pj_amt"+id).value);
										var p2 = parseInt(document.getElementById("pj_sam_amt"+id).value);

										var total_amt = p1;
										
										if(document.getElementById("samagree1").checked == true)
										{
											total_amt = p1 + p2;
											$str = "Total (Guruji Fee + Samagri) <ss>Rs. " + total_amt + "</ss>";
										}
										else
										{
											$str = "Total (Guruji Fee) <ss>Rs. " + total_amt + "</ss>";
										}
										document.getElementById("tot_amt").innerHTML = $str;
										document.getElementById("hidd_iddd").value = id;
									}
									
									function check_status()
									{
										var id = document.getElementById("hidd_iddd").value;
										
										var p1 = parseInt(document.getElementById("pj_amt"+id).value);
										var p2 = parseInt(document.getElementById("pj_sam_amt"+id).value);

										var total_amt = p1;
										
										if(document.getElementById("samagree1").checked == true)
										{
											total_amt = p1 + p2;
											$str = "Total (Guruji Fee + Samagri) &nbsp;&nbsp;<ss>Rs. " + total_amt + "</ss>";
										}
										else
										{
											$str = "Total (Guruji Fee) &nbsp;&nbsp;<ss>Rs. " + total_amt + "</ss>";
										}
										document.getElementById("tot_amt").innerHTML=$str;
										document.getElementById("hidd_iddd").value = id;
									}
								</script>
								<?php
								
									$pooja_amt_arr = $this->session->userdata('pooja_amt');
									
									
									for($ii=0; $ii<37; $ii++)
									{
										$p_amt = $pooja_amt_arr[$ii]->pandit_fee;
										$p_dis = $pooja_amt_arr[$ii]->pandit_fee_disc;
										$f_p_amt = $p_amt +($p_amt * $p_dis)/100;
										
										
										$p_sam = $pooja_amt_arr[$ii]->samagree;
										$p_sam_dis = $pooja_amt_arr[$ii]->sam_amt_disc;
										$f_sam_amt = $p_sam + ($p_sam * $p_sam_dis)/100;
									
								?>
										<input type="hidden" id="pj_amt<?=($ii+1)?>" value="<?=$f_p_amt?>"/>
										<input type="hidden" id="pj_sam_amt<?=($ii+1)?>" value="<?=$f_sam_amt?>"/>
								<?php
									
									}
								?>
								<input type="hidden" id="hidd_iddd"/>
								<b>Type</b>
								<div class="controls">
									<select name="type" id="type" onchange="showpooja(this)" onclick="reset_msg()">
										<option value="Select" selected>Select</option>
										<option value="home pooja">HOME POOJA</option>
										<option value="office pooja">OFFICE POOJA</option>
										<option value="festivals pooja">FESTIVALS POOJA</option>
										<option value="functional pooja">FUNCTIONAL POOJA</option>
										<option value="OTHER">OTHER</option>
									</select>
								</div>
								<div class="row" style="font-size:11px;">	
									<div id="home pooja" style="display:none">	
										<div class="span3">	
											<input name="invi" id="invi1" type="radio" value="1" onclick="check_total(this)"> Laxmi Pooja </input></br>
											<input name="invi" id="invi2" type="radio" value="2" onclick="check_total(this)"> Griha Pravesh</input></br>
											<input name="invi" id="invi3" type="radio" value="3" onclick="check_total(this)"> Navgrah Pooja</input></br>
											<input name="invi" id="invi4" type="radio" value="4" onclick="check_total(this)"> Navchandi/Shatchandi</input></br>
											<input name="invi" id="invi5" type="radio" value="5" onclick="check_total(this)"> Krishna Pooja/Janmashtami </input></br>
											<input name="invi" id="invi6" type="radio" value="6" onclick="check_total(this)"> Mahamrutinjaya Jap</input></br>
											<input name="invi" id="invi7" type="radio" value="7" onclick="check_total(this)"> Satyanarayan Pooja</input></br>
										</div>
										<!--div class="span2">	
										</div-->
										<div class="span3">	
											<input name="invi" id="invi8" type="radio" value="8" onclick="check_total(this)"> Shiv Pooja</input></br>
											<input name="invi" id="invi9" type="radio" value="9" onclick="check_total(this)"> Moolshanti Pooja</input></br>
											<input name="invi" id="invi10" type="radio" value="10" onclick="check_total(this)"> Maha Rudra</input></br>
											<input name="invi" id="invi11" type="radio" value="11" onclick="check_total(this)"> Aati Rudra</input></br>
											<input name="invi" id="invi12" type="radio" value="12" onclick="check_total(this)"> Pitra Dosh Shanti</input></br>
											<input name="invi" id="invi13" type="radio" value="13" onclick="check_total(this)"> Vasant Panchami</input></br>
											<input name="invi" id="invi14" type="radio" value="14" onclick="check_total(this)"> Udak Shanti</input></br>
										</div>
									</div>
									<div id="office pooja" style="display:none">	
										<div class="span3">		
											<input name="invi" id="invi15" type="radio" value="15" onclick="check_total(this)"> Bhoomi Pooja</input></br>
											<input name="invi" id="invi16" type="radio" value="16" onclick="check_total(this)"> Laxmi Pooja</input></br>
											<input name="invi" id="invi17" type="radio" value="17" onclick="check_total(this)"> Sarswati Pooja</input></br>
											<input name="invi" id="invi18" type="radio" value="18" onclick="check_total(this)"> Satyanarayan Pooja</input></br>
											<input name="invi" id="invi19" type="radio" value="19" onclick="check_total(this)"> Vishwakarma Pooja</input></br>
										</div>
									</div>
									<div id="festivals pooja" style="display:none">	
										<div class="span3">		
											<input name="invi" id="invi20" type="radio" value="20" onclick="check_total(this)"> Dhanteras Pooja </input></br>
											<input name="invi" id="invi21" type="radio" value="21" onclick="check_total(this)"> Durga Pooja </input></br>
											<input name="invi" id="invi22" type="radio" value="22" onclick="check_total(this)"> Ganesh Pooja/Ganesh Chaturthi </input></br>
											<input name="invi" id="invi23" type="radio" value="23" onclick="check_total(this)"> Laxmi Pooja </input></br>
											<input name="invi" id="invi24" type="radio" value="24" onclick="check_total(this)"> Navratri Pooja </input></br>
											<input name="invi" id="invi25" type="radio" value="25" onclick="check_total(this)"> Gauri Pooja </input></br>
										</div>
										<div class="span3">			
											<input name="invi" id="invi26" type="radio" value="26" onclick="check_total(this)"> Mahashivratri Pooja </input></br>
											<input name="invi" id="invi27" type="radio" value="27" onclick="check_total(this)"> Ganesh Yag </input></br>
											<input name="invi" id="invi28" type="radio" value="28" onclick="check_total(this)"> Datta Yag </input></br>
											<input name="invi" id="invi29" type="radio" value="29" onclick="check_total(this)"> Vat Pornima </input></br>
											<input name="invi" id="invi30" type="radio" value="30" onclick="check_total(this)"> Mangla Gauri </input></br>
										</div>
									</div>
									<div id="functional pooja" style="display:none">	
										<div class="span2">		
											<input name="invi" id="invi31" type="radio" value="31" onclick="check_total(this)"> Namkaran/Barase</input></br>
											<input name="invi" id="invi32" type="radio" value="32" onclick="check_total(this)"> Munj</input></br>
											<input name="invi" id="invi33" type="radio" value="33" onclick="check_total(this)"> Vastu Shanti</input></br>
											<input name="invi" id="invi34" type="radio" value="34" onclick="check_total(this)"> Sathi(60th Birthday)</input></br>
										</div>
										<div class="span2">		
											<input name="invi" id="invi35" type="radio" value="35" onclick="check_total(this)"> Murti Pranpratishtha</input></br>
											<input name="invi" id="invi36" type="radio" value="36" onclick="check_total(this)"> Mandir Jirnodhar</input></br>
											<input name="invi" id="invi37" type="radio" value="37" onclick="check_total(this)"> Vivah Pooja</input></br>
										</div>
									</div>
									<br/>
									<div id="other_pooja_div" style="display:none">
										<div class="span3">
											<input type="text" class="span3" placeholder="Your Pooja Name" name="other_pooja_txt" id="other_pooja_txt" onkeypress="reset_msg()"/>
											<font size='2' color='red'><span id="other"></span></font>
										</div>
									</div>
								</div>
								<br>								
								<div class="control-group">
									<div class="controls">
									 <font size='2' color='red'><span id="txt10"></span></font>									
									</div>
								</div>
								<div class="control-group">
								<div class="controls">
									<b>With Samagri ? &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<input type="radio" name="samagree" id="samagree1" value="yes" onclick="check_status()" checked>&nbsp; YES
										&nbsp;&nbsp;&nbsp;&nbsp;
										<input type="radio" name="samagree" id="samagree2" value="no"onclick="check_status()">&nbsp; NO
									</b>
								</div>
								</div>
								
								<div class="control-group">
								<div class="controls">
									<b>
										<div id="tot_amt"></div>
									</b>
								</div>
								</div>
								
								<br>
							<?php
							}
							else
							{
								
								$arr = $this->session->userdata('selected_pooja_detail');
								$this->session->unset_userdata('selected_pooja_detail');
								
								$ind = $arr[0];
							?>
								
								<script type="text/javascript">
									$(document).ready(function(){
									document.getElementById("hidd_navi").value = "indirect";
									});
								</script>
								
								<br>
								<b>Selected Pooja :</b>
									<?php
										echo "<p>";
										if($ind <= 14)
										{
											echo "<b>$arr[1]</b> (HOME POOJA)";
										}
										else if($ind >= 15 and $ind <= 19)
										{
											echo "<b>$arr[1]</b> (OFFICE POOJA)";
										}
										else if($ind >= 20  and $ind <= 30)
										{
											echo "<b>$arr[1]</b> (FESTIVALS POOJA)";
										}
										else if($ind >= 31 and $ind <= 37)
										{
											echo "<b>$arr[1]</b> (FUNCTIONAL POOJA)";
										}
										echo "</p>";
									
									
								if($arr[3] == 'yes')
									echo "<p>With Samagri Rs. ".$arr[2]."</p>";
								else
									echo "<p>Without Samagri Rs. ".$arr[2]."</p>";
								
								// $this->session->set_userdata('reference',$arr);
								
							}
							?>							
							
							<div class="control-group">
								<div class="controls">
									<b>Pooja Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<input type="radio" name="dates" id="dates" value="fixed" onchange="set_dates(1)">&nbsp;  Fixed
										&nbsp;&nbsp;&nbsp;&nbsp;
										<input type="radio" name="dates" id="dates" value="between" onchange="set_dates(2)" checked="checked">&nbsp; In Between
									</b>
								</div>
								<br>
								<div class="controls">
									<div class="controls">
										<script>
											var myCalendar;
											function doOnLoad()
											{
												// init values
												//var t = new Date();
												var today = new Date();
												var dd = today.getDate();
												var mm = today.getMonth()+1; //January is 0!
												var yyyy = today.getFullYear();
												
												var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
												var dd1 = currentDate.getDate();
												var mm1=mm;
												var yyyy1=yyyy;
												
												if(dd1 < dd)
												{
													if(mm == 12)
													{
														mm1=1;
														yyyy1++;
													}
													else
													{
														mm1++;
													}
												}

												if(dd<10){
													dd='0'+dd;
												}
												if(mm<10){
													mm='0'+mm;
												}
												if(dd1<10){
													dd1='0'+dd1;
												}
												if(mm1<10){
													mm1='0'+mm1;
												}
												var today = yyyy+'-'+mm+'-'+dd;
												var today_to = yyyy1+'-'+mm1+'-'+dd1;
												
												myCalendar = new dhtmlXCalendarObject(["date_from","date_to"]);
												myCalendar.setDate(today_to);
												myCalendar.hideTime();
												
												byId("date_from").value =  today;//"2015-03-05";
												byId("date_to").value = today_to;//"2013-03-15";
											}
											
											function setSens(id, k)
											{
												// update range
												if (k == "min")
												{
													var today = new Date();
													var dd = today.getDate();
													var mm = today.getMonth()+1; //January is 0!
													var yyyy = today.getFullYear();

													
													if(dd<10){
														dd='0'+dd;
													} 
													if(mm<10){
														mm='0'+mm;
													}
													today = yyyy+'-'+mm+'-'+dd;
													
													myCalendar.setSensitiveRange(today, null);
													// document.getElementById('date_to').value = document.getElementById('date_from').value;
												}
												else
												{
													myCalendar.setSensitiveRange(byId(id).value, null)//, byId(id).value);
												}
											}
											
											function byId(id)
											{
												return document.getElementById(id);
											}
											
											function reset_all()
											{
												document.getElementById("full_name").value = "";
												document.getElementById("upass").value = "";
												document.getElementById("contact").value = "";
												document.getElementById("add1").value = "";
												document.getElementById("add2").value = "";
												document.getElementById("add3").value = "";
												document.getElementById("add4").value = "";
												document.getElementById("add5").value = "";
												document.getElementById("add6").value = "";
												
												document.getElementById("invite1").checked = false;
												document.getElementById("invite2").checked = false;
												document.getElementById("invite3").checked = false;
												
												document.getElementById("comment").value = "";
												
												document.getElementById("cfm").checked = false;
											}
											
											function reset_all2()
											{
												document.getElementById("email").value = "";
												reset_all();
											}
										</script>
										
										<input type="text" id="date_from" name="p-date" style="background-color:white;cursor:pointer;" onclick="setSens('date_to', 'min');" readonly="true">
										<input type="text" id="date_to" name="e-date" style="background-color:white;cursor:pointer;" onclick="setSens('date_from', 'max');" readonly="true">
									</div>
								</div>
							</div>
							
							<div class="control-group">
								<b>Please Tick the Services / Suggestions you want like up to Help you</b>			
							</div>
								
							<div class="row" style="font-size:11px;">
								<div class="span2">
									<input name="invite1" id="invite1" type="checkbox" class="input-xlarge">&nbsp;&nbsp;&nbsp;Catering</input></br>
									<input name="invite2" id="invite2" type="checkbox" class="input-xlarge">&nbsp;&nbsp;&nbsp;Decoration</input></br>
									<input name="invite3" id="invite3" type="checkbox" class="input-xlarge">&nbsp;&nbsp;&nbsp;Venue</input></br>
								</div>	
							</div>
							<br>
							<div class="control-group">
								<b>Comments</b>
								<div class="controls">
									<textarea rows="4" cols="6" class="input-xlarge" placeholder="comment" name="comment" id="comment" style="resize:none;"></textarea>
								</div>
							</div>							
							<div class="control-group">
								<div class="controls">
									<input name="cfm" id="cfm" type="checkbox" onclick="terms_condition()" class="input-xlarge"> &nbsp; I agree to the bookmyguruji <a href="<?php echo base_url(); ?>index.php/Home/termsofuse"> Terms of use </a> and <a href="<?php echo base_url(); ?>index.php/Home/privacypolicy"> Privacy Plolicy </a></input>
									</br>
									</br>
									<span id="policy"></span>
								</div>
							</div>							
							<br>
							<div class="actions">
								<input tabindex="9" class="btn btn-success" type="submit" value="Book My Guruji" onclick="final_submit()">
								&nbsp; &nbsp; 
								<?php
								
								if($this->session->userdata('user_data'))
								{
								?>
									<input tabindex="9" class="btn btn-warning" type="button" onclick="reset_all()" value="Reset">
								<?php
								}
								else
								{
								?>
									<input tabindex="9" class="btn btn-warning" type="button" onclick="reset_all2()" value="Reset">
								<?php
								}
								?>
							</div>
							</div>
						</fieldset>
					</form>					
				</div>
				<div class="span3"></br>
					<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
					<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center>
					<br><br>
					<?php
					foreach($images as $img)
					{
					?>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image5;?>" id="pn"></br><br>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image4;?>" id="pn"></br><br>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image3;?>" id="pn"></br><br>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image2;?>" id="pn"></br><br>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image1;?>" id="pn"></br>
					<?php
					}
					?>
				</div>
				<br>
			</div>				
		</section>			
	</div>
</body>					
</html>
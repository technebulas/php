<!DOCTYPE html>
<html lang="en">
	<head>
		<style>
			#pn:hover
			{
				border: 1px solid #FAA732;
			}
			#sl:hover
			{
				background-color: #FFE6CC;
			}
		</style>		
		<script>
			function reset_msg()
			{
				document.getElementById("txt1").innerHTML = "";
				document.getElementById("txt2").innerHTML = "";
			}
			
			function submit_form()
			{
				var email = document.getElementById("uname").value;				
				var pass = document.getElementById("upass").value;
				
				if(email=="")
				{
					// alert("Please Fill Email Id.");
					document.getElementById("txt1").innerHTML = "&nbsp; Please enter Email Id.<br>";
					return false;
				}
				else if(pass=="")
				{
					// alert("Please Fill Password.");
					document.getElementById("txt2").innerHTML = "&nbsp; Please enter Password.<br>";
					return false;
				}
				else
				{
					return true;
				}
			}
			
			function checkEmail(emailId) 
			{
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailId))
				{
					return true;
				}
				
				return false;
			}
			function ValidateEmail(emailID)
			{
				// var emailID = val;
					reset_msg();
				/* if ((emailID.value==null)||(emailID.value=="")){
					alert("Please Enter your Email ID")
					emailID.focus()
					return false
				} */
				if (checkEmail(emailID.value)==false){
					emailID.value="";
					// alert("Invalid Email Adderess");
					document.getElementById("txt1").innerHTML = "&nbsp; Invalid Email Adderess.<br>";
					emailID.focus();
					return false;
				}
					// alert('valid');
					return true;
			}
		</script>
	</head>
	
	<body>
		<?php
			if($this->session->userdata('enq_ins_msg'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('enq_ins_msg').'")';
				echo '</script>'; 
				$this->session->unset_userdata('enq_ins_msg');
			}
			
			/* if($this->session->userdata('log_in_out_msg'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('log_in_out_msg').'")';
				echo '</script>'; 
				$this->session->unset_userdata('log_in_out_msg');
			} */
		?>
		<br>
		<div id="wrapper" class="container">
			<section class="main-content">				
				<div class="row">
					<div class="span3">	</br></br></br><br><br>		
					<center>
						<p class="reset"><b>New Customer? Please Sign Up </b></p>
						<p>
							<form class="form-stacked" name="redirect_form" method="post" action="<?php echo base_url() ?>index.php/Home/sign_up">
								<input class="btn btn-warning" type="submit" value="Sign Up">
							</form>
						</p>
					</center>
					</div>
					<div class="span1">	</div>
					<div class="span5"></br>
					<h4 class="title"><span class="text">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Login</strong></span></h4>
						<?php
						
							if($this->session->userdata('login_msg'))
							{
								echo "<p forecolor='red'>".$this->session->userdata('login_msg')."</p>";
								$this->session->unset_userdata('login_msg');
							}
							
						?>
						
						<form class="form-stacked" name="login_form" method="post" onsubmit="return submit_form()" action="<?php echo base_url() ?>index.php/Login/login_user">
							<!--input type="hidden" name="next" value="/"-->
							<fieldset>
								<div class="control-group">
									<b>Email</b>
									<div class="controls">
										<input type="text" placeholder="Email" class="input-xlarge" name="uname" id="uname" onchange="ValidateEmail(this)" onkeypress="reset_msg()">
									</div>
								</div>
								
								<div class="control-group">
									<div class="controls">
										<font size='2' color='red'><span id="txt1"></span></font>
									</div>
								</div>
								
								<div class="control-group">
									<b>Password</b>
									<div class="controls">
										<input type="password" placeholder="Password" class="input-xlarge" id="upass" name="upass" onkeypress="reset_msg()">
									</div>
								</div>
								
								<div class="control-group">
									<div class="controls">
										<font size='2' color='red'><span id="txt2"></span></font>										
									</div>
								</div>
								
								<div class="control-group">
									<input class="btn btn-success" type="submit" value="Login">
								</div>
								<br/>
								<div class="control-group">
									<p class="reset"><a href="<?php echo base_url() ?>index.php/Home/recover_pass">Recover your username or password</a></p>
								</div>
							</fieldset>
						</form>	
					</div>	
					<div class="span3"></br>
						<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
						<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center>
						<?php
						// include 'calendar.php';
						?>
					</div>					
				</div>
			</section>			
		</div>
    </body>
</html>
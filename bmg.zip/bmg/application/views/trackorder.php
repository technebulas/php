<!DOCTYPE html>
<html lang="en">
	<head>
		<style>
			.wizard a {padding: 12px 12px 10px 12px; margin-right:5px; width:21%; background:#efefef; position:relative; display:inline-block; }
			.wizard a:before {width:0px; height:0px; border-top: 20px inset transparent; border-bottom: 20px inset transparent; border-left: 20px solid #fff; position: absolute; content: ""; top: 0; left: 0;}
			.wizard a:after {width:0px; height:0px; border-top: 20px inset transparent; border-bottom: 20px inset transparent; border-left: 20px solid #efefef; position: absolute; content: ""; top: 0; right: -20px; z-index:2;}
			.wizard a:first-child:before {border:none;}
			.wizard a:last-child:after {border:none;}

			.wizard a:first-child {-moz-border-radius: 4px 0 0 4px; -webkit-border-radius: 4px 0 0 4px; border-radius:   4px 0 0 4px;}
			.wizard a:last-child {-moz-border-radius: 0 4px 4px 0; -webkit-border-radius: 0 4px 4px 0; border-radius:   0 4px 4px 0;}

			.wizard .badge {margin:0 5px 0 18px; position:relative; top:-1px;}
			.wizard a:first-child .badge {margin-left:0;}

			.wizard .current {background:#FBB450; color:#fff;}
			.wizard .current:after {border-left-color:#FBB450;}
		</style>
		<script type="text/javascript">
			function data_clear()
			{
				document.getElementById("txt1").innerHTML = "";
			}
			
			function search()
			{
				var eid=document.getElementById("enquiryid").value;
				
				if(eid=="")
				{
					// alert("Please Fill Enquiry Id..");
					document.getElementById('report').style.display = "none";
					document.getElementById("txt1").innerHTML = "&nbsp; Please Fill Enquiry Id.";
				}
				else
				{
					var enq_id = $("#enquiryid").val();
					document.getElementById('report').style.display = "inline";
					$("#report").load("<?php echo base_url()?>index.php/Home/trackorderprogress/"+enq_id);				
				}
			}					
			
			function val_number(val)
			{
				// clear_msg();
				var no = val.value;
				
				if(!no.match(/^[+]?[0-9]+$/))
				{
					// alert("Please enter number !");
					document.getElementById('report').style.display = "none";
					document.getElementById("txt1").innerHTML = "&nbsp; Please enter digit only.";
					val.value="";
					return false;
				}
			}			
		</script>
	</head>
	<body>
		<br>
		<div id="wrapper" class="container"><br>
			<section class="main-content">				
				<div class="row">
					<!--<form class="form-stacked" name="track_order" method="post" action="<?php echo base_url(); ?>index.php/Home/trackorderprogress">-->
					<br>
					<div class="span3">	</div>	
					<div class="span2">		
						<div class="control-group">
							<div class="controls">
								<b>Enquiry Id</b>
							</div>
						</div>
					</div>
					<div class="span3">		
						<div class="control-group">
							<div class="controls">
								<input type="text" placeholder="Enquiry Id" id="enquiryid" name="enquiryid" onchange="val_number(this)" onkeypress="data_clear()">
							</div>
						</div>
					</div>
					<div class="span3">
						<div class="control-group">
							<div class="controls">
								<input class="btn btn-success" type="button" value="Search" onclick="search()">
							</div>
						</div>
					</div>
				</div>
				<br>
				<div class="row">
					<div class="span5">	</div>
					<div class="span3">
						<font size='2' color='red'><span id="txt1"></span></font>	
					</div>
				</div>
				<br>
				<div class="row">
					<div class="span12">
						<div id="report"></div>
					</div>
				</div>
			</section>			
		</div>
    </body>
</html>
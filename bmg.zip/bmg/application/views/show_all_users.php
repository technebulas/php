<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Pandit site</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		<style>
		.orange
		{
			color:#FF6600;
		}
		</style>
		
		<script type="text/javascript">
			
			function setuserid_block(my_id)
			{
				// alert("id="+my_id);
				document.forms["user_block"]["blockdata"].value = my_id;
				document.forms["user_block"].submit();
			}
			
			function setuserid_unblock(my_id)
			{
				// alert("id="+my_id);
				document.forms["user_unblock"]["unblockdata"].value = my_id;
				document.forms["user_unblock"].submit();
			}
			
			
		</script>
	</head>
	
<body>	

	<div class="container">
		<div class="row">
		<br>
		<br>
		<div class="span2">&nbsp;</div>
		<div class="span8">
		<table class="table table-bordered table-fixed">
						
			<tr class="active" align="center" size="auto">
				<th class="active"><h6><p>Sr No</p></h6></th>
				<th class="active"><h6><p>Name</p></h6></th>
				<th class="active"><h6><p>Login Name</p></h6></th>
				<th class="active"><h6><p>Status</p></h6></th>
			</tr>


				<?php
					
					$no=1;
					foreach($values as $value)
					{
				?>
						<tr  class="info">
							<td align="center"><?=$no?></td>
							<td align="center"><?=$value->fullname?></td>
							<td align="center"><?=$value->username?></td>
							<?php
								$st=(int)$value->access_status;
								
								if($st==1)
								{
							?>
									<td>
										<form name = "user_block" action= "<?php echo base_url() ?>index.php/Primary/to_block" method="post">
											<input type="hidden" name="blockdata" id="blockdata" value = "<?=$value->user_id?>" />
												<a href = "javascript:setuserid_block('<?=$value->user_id?>')"><span class= "glyphicon icon-remove-sign" title = "Block"></span></a>
										</form>
									</td>	
							<?php
								}
								else
								{
							?>
									<td>
										<form name = "user_unblock" action= "<?php echo base_url() ?>index.php/Primary/to_unblock" method="post">
											<input type="hidden" name="unblockdata" id="unblockdata" value = "<?=$value->user_id?>" />
											<a href = "javascript:setuserid_unblock('<?=$value->user_id?>')"><span class= "glyphicon icon-ok" title = "Block"></span></a>
										</form>
									</td>
							<?php
								}
							?>
						</tr>
				<?php

						$no++;
					}
				?>
			</table>
			
		</div>
		</div>
	</div>
	
</body>
</html>
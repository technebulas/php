<!DOCTYPE html>
<html lang="en">
	<body>		
		<div class="row">
			<div class="span9"></br>
				<h4 align="center"> History Details </h4>
				<div style="width: 100%; height:310px; overflow-y: auto;">
				<table class="table table-bordered table-fixed">
					<tr class="active" align="center" size="auto">
						<th class="active"><h6><p>Sr. No</p></h6></th>
						<th class="active"><h6><p>Enquiry ID</p></h6></th>
						<th class="active"><h6><p>Booking Details</p></h6></th>
						<th class="active"><h6><p>Pooja Details</p></h6></th>
						<th class="active"><h6><p>Price</p></h6></th>
						<th class="active"><h6><p>Remark</p></h6></th>
						<th class="active"><h6><p>Final Status</p></h6></th>
					</tr>
					
					<?php 
					
					$no = 1;
					foreach($values2 as $value2)//order
					{
						if($no%2==1)
						{
					?>
							<tr class="info" align = "center">
								<td><?=$no?></td>
								<td><?=$value2->enq_id?></td>
								<td><?=$value2->booking_date?><br><?=$value2->book_time?></td>
								<td><?=$value2->pj_name?></td>
								<?php
									$sam_sta = $value2->sam_status;
									
									if($sam_sta == 'yes')
									{
								?>
								<td>with samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
									else
									{
								?>
								<td>without samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
								?>
									<td><?=$value2->remark?></td>
								<?php
									$enq_st = $value2->enq_status;
									if($enq_st == 0)
									{
								?>
									<td><b style='color:red;'>Reject</b></td>
								<?php
									}
									else if($enq_st == 4)
									{
								?>
									<td><b style='color:green;'>Done</b></td>
								<?php
									}
								?>
							</tr>
					<?php
						}
						else
						{
					?>
							<tr align = "center">
								<td><?=$no?></td>
								<td><?=$value2->enq_id?></td>
								<td><?=$value2->booking_date?><br><?=$value2->book_time?></td>
								<td><?=$value2->pj_name?></td>
								<?php
									$sam_sta = $value2->sam_status;
									
									if($sam_sta == 'yes')
									{
								?>
								<td>with samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
									else
									{
								?>
								<td>without samagri<br>Rs. <?=$value2->pooja_amt?></td>
								<?php
									}
								?>
									<td><?=$value2->remark?></td>
								<?php
									$enq_st = $value2->enq_status;
									if($enq_st == 0)
									{
								?>
									<td><b style='color:red;'>Reject</b></td>
								<?php
									}
									else if($enq_st == 4)
									{
								?>
									<td><b style='color:green;'>Done</b></td>
								<?php
									}
								?>
							</tr>
					<?php
						}
								
						$no++;
					}
					
					if($no==1)
					{
						echo "<tr><th colspan='7'><b style='color:red;'>No Record Found</b></th></tr>";
					}
					
					?>	
				</table>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</body>
</html>
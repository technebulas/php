<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Pandit site</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		
	</head>
	
	<body>		
		<div id="wrapper" class="container">
			<section>
				<!--h4 align="center">Header<span></span></h4-->
			</section></br>			
			<section class="main-content">				
				<div class="row">
					<div class="span4">&nbsp;</div>
					<div class="span5">					
						<h4 class="title"><span class="text"><strong>Create </strong> Admin</span></h4>
						<form class="form-stacked" name="createadmin" method="post" action="<?php echo base_url() ?>index.php/Primary/insert_admin"">
							<!--input type="hidden" name="next" value="/"-->
							<fieldset>
								<div class="control-group">
									<label class="control-label">Username</label>
									<div class="controls">
										<input type="text" placeholder="Username" class="input-xlarge" name="fullname">
									</div>
								</div>
								<div class="control-group">
									<label class="control-label">Email</label>
									<div class="controls">
										<input type="text" placeholder="Email Id" class="input-xlarge" name="email">
									</div>
								</div>
								
								<div class="control-group">
									<input tabindex="3" class="btn btn-success" type="submit" value="Submit">
									&nbsp; &nbsp; &nbsp; &nbsp;
									<input tabindex="3" class="btn btn-warning" type="reset" value="Reset">
								</div>
							</fieldset>
						</form>				
					</div>
				</div>
			</section>			
		</div>
    </body>
</html>
<!DOCTYPE html>
<html lang="en">
	<head>
		
		<!-- Date picker css & js-->
		<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
		<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css" />
		<link href="<?php echo base_url(); ?>css/runnable.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>js/script.js"></script>	
		<script src="<?php echo base_url(); ?>js/script1.js"></script>	

		<script src="<?php echo base_url(); ?>js/jquery-1.9.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
		<script type="text/javascript">
			
			function reset_msg()
			{
				document.getElementById("txt1").innerHTML = "";
				document.getElementById("txt2").innerHTML = "";
				document.getElementById("txt3").innerHTML = "";
			}
				
			function set_action(v1)
			{
				
				document.forms["enquiry_form"]["hid_action"].value = v1;
				
				if(v1 == 0)
				{
					var v2 = document.getElementById('remark').value;
					if(!v2 || 0 === v2.length)
					{
						// alert("Please enter remark");
						document.getElementById("txt3").innerHTML = "&nbsp; Please enter remark.";
					}
					else
					{
						document.forms["enquiry_form"].submit();
					}
				}
				else
				{
					var v2 = document.getElementById('datepicker').value;
					
					var temp = document.getElementById('hid_xx').value;
					var v3 = "";
					
					if(temp==1)
					{
						v3 = document.getElementById('other_pj_amt').value;
						if(v3=='')
						{
							// alert("Please enter pooja amount");
							document.getElementById("txt1").innerHTML = "&nbsp; Please enter pooja amount.";
							return;
						}
					}
					
					if(!v2 || 0 === v2.length)
					{
						// alert("Please select date");
						document.getElementById("txt2").innerHTML = "&nbsp; Please select date.";
						return;
					}
					else if(v2.length != 10)
					{
						// alert("Please select proper date");
						document.getElementById("txt2").innerHTML = "&nbsp; Please proper date.";
						return;
					}
					else
					{
						// alert("done");
						document.forms["enquiry_form"].submit();
					}
				}
				
				
			}
			
			function onlyNos(e, t)
			{
				reset_msg();
				try
				{

					if (window.event)
					{
						var charCode = window.event.keyCode;
					}
					else if (e)
					{
						var charCode = e.which;
					}
					else
					{
						return true;
					}

					if (charCode > 31 && (charCode < 48 || charCode > 57))
					{
						return false;
					}
					return true;
				}
				catch (err)
				{
					alert(err.Description);
				}
			}	
			
		</script>
	</head>

	<body>
	<br>
	<div id="wrapper" class="container">
		<?php
		
			foreach($values as $value)
			{
		?>
				<form class="form-stacked" name="enquiry_form" method="post" action="<?php echo base_url() ?>index.php/order_detail_edit/update_enquiry">
					
					<input type="hidden" name="hid_frm_navi" value="<?=$navi_frm?>">
					
					<input type="hidden" name="hid_enq_id" value="<?=$value->enq_id?>">
					<input type="hidden" name="hid_user_id" value="<?=$value->u_id?>">
					<input type="hidden" name="hid_action" id="hid_action">
					<br>
					<div class="row">
						<div class="span5">
							<table width="100%">
								<tr>
									<td><h6>Name :</h6></td>
									<td><input type="text" value="<?=$value->full_name?>" style="background-color:white;" class="span3" disabled></td>
								</tr>
								<tr>
									<td><h6>Login Name<br>(Email) :</h6></td>
									<td><input type="text" value="<?=$value->username?>"  style="background-color:white;" class="span3" disabled></td>
								</tr>
								<tr>
									<td><h6>Contact No :</h6></td>
									<td><input type="text" value="<?=$value->enq_contact_no?>" style="background-color:white;" class="span3" disabled></td>
								</tr>
								<tr>
									<td><h6>Registered Date :</h6></td>
									<td><input type="text" value="<?=date("d/m/Y", strtotime($value->enq_date))?>" class="span3"  style="background-color:white;" disabled></td>
								</tr>
								<tr>
									<td><h6>Booking Date :</h6></td>
									<?php
										if($value->s_date==$value->e_date)
										{
									?>
									<td><input type="text" value="<?=date("d/m/Y", strtotime($value->s_date))?>" class="span3"  style="background-color:white;" disabled></td>
									<?php
										}
										else
										{
									?>
									<td><input type="text" value="<?=date("d/m/Y", strtotime($value->s_date))?> to <?=date("d/m/Y", strtotime($value->e_date))?>" style="background-color:white;" class="span3" disabled></td>
									<?php
										}
									?>
								</tr>
							</table>
						</div>
						<div class="span1">&nbsp;</div>
						<div class="span5">
							<table width="100%">
								<tr>
									<td><h6>Address :</h6></td>
									<td><textarea style="resize: none; background-color:white;" class="span3" disabled><?=$value->add1.",".$value->add2.",".$value->add3.",".$value->add4.",".$value->add5.",".$value->add6?></textarea></td>
								</tr>
								<tr>
									<td><h6>Other Activities :</h6></td>
									<?php
										$myArray2 = explode(',',$value->other_acts);
										// print_r ($myArray2);
										$len = count($myArray2);
										$sstr = '';
										for($incr=0;$incr<$len;$incr++)
										{
											if($myArray2[$incr] == 1)
												$sstr = $sstr."Catering,";
											else if($myArray2[$incr] == 2)
												$sstr = $sstr."Decoration,";
											else if($myArray2[$incr] == 3)
												$sstr = $sstr."Venue,";
										}
										
										$sstr = substr($sstr,0,-1);
										
									?>
									<td><input type="text" class="span3" value="<?=$sstr?>"  style="background-color:white;" disabled></td>
								</tr>
								<tr>
									<td><h6>Comment :</h6></td>
									<td><textarea style="resize: none; background-color:white;" class="span3" disabled><?=$value->comment?></textarea></td>
								</tr>
							</table>
						</div>
					</div>
					<?php
						$sam_st = $value->sam_status;
					?>
					<br><br>
					
					<div class="row">
						
						<div class="span12">
						<table align="center" width="80%">
							<?php
								$pooid = $value->poojas;
								
							?>
							<tr>
								<td rowspan="2" align="center" width="25%">
									<p><font size="3"><b><?=ucwords($value->pj_name)?></b></font>
									<?php
									
									$ind = $pooid;
									
									$xx = 0;
									echo "<br>";
									if($ind >= 1 and $ind <= 14)
									{
										echo "(Home Pooja)";
									}
									else if($ind >= 15 and $ind <= 19)
									{
										echo "(Office Pooja)";
									}
									else if($ind >= 20  and $ind <= 30)
									{
										echo "(Festival Pooja)";
									}
									else if($ind >= 31 and $ind <= 37)
									{
										echo "(Functional Pooja)";
									}
									else
									{
										echo "(Other Pooja)";
										$xx = 1;
									}
									echo "</p>";
									
									if($sam_st == 'yes')
										echo "(with samagree)";
									else
										echo "(without samagree)";
									
									
									if($xx == 1)
									{
									?>
										<br><input class="span1" type="text" name="other_pj_amt" id="other_pj_amt" onkeypress="return onlyNos(event,this);">
									<?php
									}
									else
									{
										echo "<br><p>Rs. ".$value->pooja_amt."</p>";
									}
									?>
									<input type="hidden" name="hid_xx" id="hid_xx" value="<?=$xx?>">
									<br>
									<font size='2' color='red'><span id="txt1"></span></font>
								</td>
								<td align="center">
									<b>Date :</b>&nbsp;&nbsp;&nbsp;<input type="text" name="final_date" class="span2" placeholder="MM/DD/YYYY" id="datepicker" style="background-color :white; cursor: context-menu;" onclick="reset_msg()" readonly="true">
									<br>
									<font size='2' color='red'><span id="txt2"></span></font>
								</td>
								<td align="center" rowspan="2">
									<b>Remark :&nbsp;&nbsp;&nbsp;</b>
									<textarea style="resize:none;" class="span3" name="remark" id="remark" placeholder="Any Additional Information About Requested Enquiry" onkeypress="reset_msg()"></textarea>									
									<br>
									<font size='2' color='red'><span id="txt3"></span></font>
								</td>
							</tr>
							<tr>
							
								<td align="center"><b>Timing</b>&nbsp;&nbsp;&nbsp;<!--input type="text" name="final_time" class="span2" placeholder="Timing"-->
									<select style="width:70px" name="sel_time" id="sel_time">
										<?php
											for($i=1;$i<=12;$i++)
											{
										?>
										  <option><?=$i?>:00</option>
										  <option><?=$i?>:30</option>
										<?php
											}
										?>
									</select>
									<select style="width:55px" name="sel_for" id="sel_for">
										<option>AM</option>
										<option>PM</option>
									</select>
								</td>
							</tr>
						</table>
						</div>
					</div>
					
					<br><br>
					
					<div class="row">
						<div class="span12" align="center">
						<input class="btn btn-success" type="button" value="Confirm" onclick="set_action(2)">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input class="btn btn-warning" type="button" value="Reject" onclick="set_action(0)">
						</div>
					</div>
					
				</form>
		<?php
			}
		?>
	</div>
	</body>
</html>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
	
   
		<!--	<section class="header_text sub" >
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				<h4><span></span></h4>
			</section>
			-->
	</br>
	<div id="wrapper" class="container">			
		<div id="ff">	
		<section class="main-content">
		<div class="row" ></br>
			<div class="span12">
					<h4>Terms Of Use</h4>
							<b>Welcome to bookmyguruji.com</b><br>
							<div style="text-align:justify;">
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								Below mentioned are the terms & conditions that govern your
								use of this site. These terms apply to the person subjected 
								to subscribing our services online and buying products.
								“bookmyguruji.com” reserves the right to change or modify 
								any of the terms and conditions contained of this site, or 
								any policy or guideline of the Site, at any time and in its 
								sole discretion. A regular update is expected by the user.
								<br>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								The Website Owner i.e. Elite Softwares Pvt. Ltd., including
								its subsidiaries and affiliates (“bookmyguruji.com” or “we” or “us” or “our”)
								provides the information contained on the website or on any of the pages 
								comprising the website (“website”) to visitors (“visitors”) 
								(cumulatively referred to as “you” or “your” hereinafter) subject to 
								the terms and conditions set out in these website terms and conditions, 
								the privacy policy and any other relevant terms and conditions, policies
								and notices which may be applicable to a specific section or module of the website. <br>
								<b>The use of this website is subject to the following terms of use</b><br>
							</div>
							<div style="margin-left:25px;text-align:justify;">
									<b>1.</b>&nbsp;The content of the pages of this website is for your general 
									information and use only. It is subject to change without notice.<br>
									<b>2.</b>&nbsp;Neither we nor any third parties provide any warranty or
									guarantee as to the accuracy, timeliness, performance, completeness this
									or suitability of the information<div style="margin-left : 13px;">  and materials found or offered on
									 website for any particular purpose. Under no circumstances will 
									we be liable in any way for any Content, including, but not limited to,
									materials for any errors or omissions in any Content, or for any loss or damage 
									of any kind incurred as a result of the use or viewing of any Content posted,
									emailed,transmitted or otherwise made available via the Service.</div>
									<b>3.</b>&nbsp;	We make no warranty that (i) the service will meet your requirements, 
									or be uninterrupted, timely, secure, or error-free, (ii) the results that 
									may be obtained from <div style="margin-left : 13px;">the use of the service will be accurate or reliable,
									(iii) the quality of any products, services, information, or other material 
									purchased or obtained by you through the service will meet your expectations,
									and (iv) any errors in the service or software will be corrected.</div>
									<b>4.</b>&nbsp;Any material transmitted, received, downloaded or otherwise obtained or sent,
									through the use of the service is done at your own discretion and risk and that you 
									<div style="margin-left : 13px;">will be solely responsible for any damage to your computer system or loss of data
									that results from the opening, download or sending of any such material.</div>
									<b>5.</b>&nbsp;	No advice or information, whether oral or written, obtained by you from service
									provider or its suppliers or through or from the service shall create any warranty
									<div style="margin-left : 13px;">not expressly stated in the tos.</div>
									<b>6.</b>&nbsp;This website contains material which is owned by or licensed to us. 
									This material includes, but is not limited to, the design, layout, look, 
									appearance and graphics. <br>
							</div>
									<br>
									<b>Reproduction is prohibited other than in accordance with the copyright notice,
									which forms part of these terms and conditions.</b><br><br>
							<div style="margin-left:25px;text-align:justify;">
										<b>1.</b>&nbsp;All trade marks reproduced in this website which are not the property of,
									or licensed to, the operator are acknowledged on the website.<br>
										<b>2.</b>&nbsp;Unauthorised use of this website may give rise to a claim for 
									damages and/or be a criminal offence.<br>
										<b>3.</b>&nbsp;From time to time this website may also include 
									links to other websites. These links are provided for
									your convenience to provide further information.
									They do not <div style="margin-left : 13px;">signify that we endorse the website(s). 
									We have no responsibility for the content of the linked website(s).</div>
										<b>4.</b>&nbsp;You may not create a link to this website from another website or
									document without [business name]'s prior written consent.<br>
										<b>5.</b>&nbsp;You agree that we, in our sole discretion, may suspend or terminate
									your password, account (or any part thereof) or use of the Service, 
									remove and discard any <div style="margin-left : 13px;">Content within the Service, deactivate or delete
									your account and all related information and files in your account 
									and/or bar any further access to such files or the Service, discontinue
									providing the Service, or any part thereof, with or without notice if we
									believe that you have violated or acted inconsistently with the letter 
									or spirit of the TOS, and have not either cured the breach (if curable) 
									or provided a satisfactory undertaking to us or the applicable authorities, 
									within five (5) business days of receiving a notification of the breach,
									or for maintenance purposes. Further, you agree that we shall not be liable
									to you or any third-party for any termination or suspension of your access to the Service.</div>
										<b>6.</b>&nbsp;Your interaction with third parties, including (without limitation):
									participation in promotions of, advertisers found on or through the Service, 
									payment and delivery<div style="margin-left : 13px;"> of goods or services, and any other terms, conditions,
									warranties or representations associated with such dealings, are solely between
									you and such third parties, and that Service Provider and its suppliers shall 
									not be responsible or liable for any loss or damage of any sort incurred as the
									result of any such dealings or the presence of such third parties on the Service.</div>
										<b>7.</b>&nbsp;You agree the Service and any necessary software used in connection with 
									it ("Software") contain proprietary and confidential information protected
									by <div style="margin-left : 13px;">applicable intellectual property and other laws, including but not limited
									to copyright, and trade and service mark protections, and is owned by Service 
									Provider or its suppliers. Service Provider grants you a personal, non-transferable
									and non-exclusive right and license to use the object code of its Software on a
									single computer, provided you
									do not (and do not allow any third party to) reverse 
									engineer, reverse assemble or otherwise attempt to discover any source code, sell, 
									assign, sublicense, grant a security interest in or otherwise transfer any right
									in the Software or Service, copy, modify, rent, lease, loan, sell, distribute, or 
									create derivative works of or based on, the Service or the Software, in whole or in part,
									or use modified versions of the Software, including (without limitation) to obtain
									unauthorized access to the Service. You agree not to access the Service by any means
									other than through the interfaces provided by or through Service Provider for use in accessing the Service.</div>
										<b>8.</b>&nbsp;Your use of this website and any dispute arising out of such use of the website 
									is subject to the laws of India or other regulatory authority.
						</div>
					</div>
				</div></br>
		</section>
	</div>
	</div>
		
    </body>
</html>
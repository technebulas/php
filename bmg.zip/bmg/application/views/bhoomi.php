<!DOCTYPE html>
<html lang="en">
	<head>
		
	</head>
	<style>
	#pn:hover
	{
	border: 1px solid #FAA732;
	}
	#sl:hover
	{
	background-color: #FFE6CC;
	}
	</style>		
	<script language="javascript" type="text/javascript">
		function set_total_amt()	
		{
			// var v1 = document.getElementById('samg').value;
			if(document.getElementById("samg").checked)
			{
				// when samagree selected
				var x = parseInt(document.getElementById('hid_txt_p_tot').value);
				var y = parseInt(document.getElementById('hid_txt_s_tot').value);
				document.getElementById('order_total').value = x+y;
			}
			else
			{
				// when samagree not selected
				var x = parseInt(document.getElementById('hid_txt_p_tot').value);
				document.getElementById('order_total').value = x;
			}

		}
	</script>
	<body>		
	<div id="wrapper" class="container">
		<div class="row" >
		<section class="main-content">
			<div class="span9">	
				<div class="row" >	
					<div class="span3">	<br><br><br><br><br>
						<center><img src="<?php echo base_url(); ?>img/1.jpg" style="margin-top:5px;"></center><br>
									<?php
										$no = 1;
										foreach($values as $value)
										{ ?>
											<form class="form-inline" action="<?php echo base_url() ?>index.php/Home/book_guruji" method="post">
												<input type="hidden" id="hid_pid" name="hid_pid" value="15">
												<input type="hidden" id="hid_pname" name="hid_pname" value="BHOOMI POOJAN">
												
												<?php
													$pan_fee_amt = $value->pandit_fee;
													$pan_dis = $value->pandit_fee_disc;
													$sam_fee_amt = $value->samagree;
													$sam_dis = $value->sam_amt_disc;
													
													$pan_dis_amt = ($pan_fee_amt * $pan_dis)/100;
													$sam_dis_amt = ($sam_fee_amt * $sam_dis)/100;
													
													$show_total_amt = $pan_fee_amt - $pan_dis_amt + $sam_fee_amt - $sam_dis_amt;
												?>
												
													
													<table border="0" >
														<tr>
															<td>Guruji Fee</td>
															<td><img src="<?php echo base_url(); ?>img/Rupee.png"><?=$pan_fee_amt?></td>
														</tr>
														<?php
														if($pan_dis_amt != 0)
														{
														?>
														<tr >
															<td>Discount</td>
															<td ><img src="<?php echo base_url(); ?>img/Rupee.png"><?=$pan_dis_amt?></td>
														</tr>
														<?php
														}
														?>
														<tr >
															<td>Samagri</td>
															<td><img src="<?php echo base_url(); ?>img/Rupee.png"><?=$sam_fee_amt?></td>
														</tr>
														
														<?php
														if($sam_dis_amt != 0)
														{
														?>
														<tr >
															<td>Discount</th>
															<td><img src="<?php echo base_url(); ?>img/Rupee.png"><?=$sam_dis_amt?></td>
														</tr>
														<?php
														}
														?>
														<tr>
															<td>Total</td>
															<td><img src="<?php echo base_url(); ?>img/Rupee.png"><?=$show_total_amt?></td>
														</tr>
													</table>
													<br>
											
												<?php
													$hid_p_total = $pan_fee_amt - $pan_dis_amt;
													$hid_s_total = $sam_fee_amt - $sam_dis_amt;
												?>
												<input type="hidden" name="hid_txt_p_tot" id="hid_txt_p_tot" value="<?=$hid_p_total?>">
												<input type="hidden" name="hid_txt_s_tot" id="hid_txt_s_tot" value="<?=$hid_s_total?>">
												
												<b>Your Order Total</b>&nbsp;&nbsp;<input class="span1" type="text" name="order_total" id="order_total" style="background-color:white;" value="<?=$hid_p_total?>" disabled>
												<br><br>
												<input type="checkbox" name="samg" id="samg" onchange="set_total_amt()">&nbsp;&nbsp;Samagri
												<br><br>
												<button type="submit"style="margin-left:0px;margin-top:1px" class="btn btn-warning">Book My Guruji</button>
												
											</form>
									<?php
									}
									?>
						
					</div>
					
					<div class="span6">
						<br><br>
						<h3 align="center">BHOOMI POOJA</h3>
							<div style="text-align:justify;">
								<b>BHOOMI POOJA</b> is performed at the construction site or a newly built
								house before beginning the construction, which is considered to be
								a new beginning. By doing this, people who believe that their success
								is determined by vaastus are ensured of a secure future in the new 
								house or construction site. This ceremony is conducted in strict 
								compliance to Vaastu Shastra, the ancient Indian science of structures
								and architecture.
								If conducted with proper assistance of a jyotish, keeping in mind 
								the auspicious days for performing the pooja, it never fails to 
								attain its objectives. Generally, the time decided upon is in 
								conformation to the ‘VastuMuhurat'. By performing this ‘bhoomi pooja’ 
								the right energy and natural elements encompassing the site can be appeased. 
								Bhoomi pooja has an important place in the lives of many as it helps
								to settle legal disputes, solves quarrels and gives peace of mind.
							</div>
						<br><br>
						<h4 align="center"><font color="orange">SAMAGRI</font></h4>
							<font size="3">
							<table border="0" width="95%" align="center">
								<tr>
								<td width="30%"><li>हळद	</li></td>
								<td width="30%"><li>कुंकू</li></td>
								<td width="20%"><li>बुक्का</li></td>
								</tr>
								<tr>
								<td><li>अत्तर</li></td>
								<td><li>जानवे</li></td>
								<td><li>कापसाचीवस्त्र</li></td>
								</tr>
								<tr>
								<td><li>पंचामृत	</li></td>
								<td><li>फुलवाती</li></td>
								<td><li>समई</li></td>
								</tr>
								<tr>
								<td><li>निरंजन	</li></td>
								<td><li>उदबत्ती</li></td>
								<td><li>कापूर</li></td>
								</tr>
								<tr>
								<td><li>नारळ</li></td>
								<td><li>गहूतांदूळ</li></td>
								<td><li>विड्याचीपाने</li></td>
								</tr>
								<tr>
								<td><li>फळे</li></td>
								<td><li>चौरंग </li></td>
								<td><li>सुट्टेपैसे coins</li></td>
								</tr>
								<tr>
								<td><li>खारीक</li></td>
								<td><li>पळीभांडे ताम्हण</li></td>
								<td><li>फुले</li></td>
								</tr>
								<tr>
								<td><li>कलश</li></td>
								<td><li>प्रसाद</li></td>
								<td><li>द्रोणपत्रावळी</li></td>
								</tr>
								<tr>
								<td><li>साखर</li></td>
								<td><li>गुळ</li></td>
								<td><li>खोबरे</li></td>
								</tr>
								<tr>
								<td><li>केळी</li></td>
								<td><li>हार, फुलेतुळसदुर्वा</li></td>
								<td><li>सुपारी</li></td>
								</tr>
								<tr>
								<td><li>तोरण</li></td>
								<td></td>
								<td></td>
								</tr>
							</table>
							</font>
						
					</div>
				</div>
				
				<br>
			
			</div>
						
			<div class="span3">
			
				<br><br>
				<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
				<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center>
				<br>
				 <?php
				 // include 'calendar.php';
				 ?> 
			
				<?php
					foreach($images as $img)
					{
					?>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image1;?>" id="pn"><br></br>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image3;?>" id="pn"><br></br>
					<?php
					}
					?>
			</div>

		</section>
		</div>
	</div>
    </body>
</html>
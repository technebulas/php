<!DOCTYPE html>
<html lang="en">
	<head>
		<style>
		#pn:hover
		{
			border: 1px solid #FAA732;
		}
		#sl:hover
		{
			background-color: #FFE6CC;
		}
		</style>	
		
		<script language="javascript" type="text/javascript">
			function reset_msg()
			{
				document.getElementById("txt1").innerHTML = "";
				document.getElementById("txt2").innerHTML = "";
				document.getElementById("txt3").innerHTML = "";
				document.getElementById("txt4").innerHTML = "";
				document.getElementById("txt5").innerHTML = "";
				document.getElementById("txt6").innerHTML = "";
				document.getElementById("txt7").innerHTML = "";
				document.getElementById("txt8").innerHTML = "";
				document.getElementById("txt9").innerHTML = "";
				document.getElementById("txt10").innerHTML = "";
				document.getElementById("txt11").innerHTML = "";
				document.getElementById("txtHint").innerHTML = "";
			}
			
				function validateText(val)	
				{
					// reset_msg();
					
					var str = val.value;
					if(!str.match(/^[A-Za-z ]*$/))
					{
						if(val.id == "full_name")
						{
							document.getElementById("txt1").innerHTML = "&nbsp; Please enter valid information.";
						}
						else if(val.id == 'add5')
						{
							document.getElementById("txt9").innerHTML = "&nbsp; Please enter valid information.";
						}						
						val.value="";
						return false;
					}
				}	
								
				function checkEmail(emailId) {
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailId)){
				// document.write("You have entered valid email.");
				return true;
				}    
				return false;
				}

				function ValidateEmail(){
					var emailID=document.getElementById("email");
					
					if (checkEmail(emailID.value)==false){
						emailID.value=""
						// alert("Invalid Email Adderess");
						document.getElementById("txtHint").innerHTML = "&nbsp; Invalid Email Adderess.";
						emailID.focus()
						return false
					}
						return true
				 }
					
				function val_numberTen(val)
				{
					var no = val.value;
					
					if(!no.match(/^[0-9]{10}$/))
					{
						// alert("Please enter 10 digit number ...!");
						document.getElementById("txt4").innerHTML = "&nbsp; Please enter 10 digit number.";		
						val.value="";
						return false;
					}
				}	
						
			function check()
			{
				var pass=document.getElementById("upass").value;
				var pass1=document.getElementById("cupass").value;

				if(pass != pass1)
				{
					// alert("Enter Password not match ! Please Re enter It.");
					document.getElementById("txt3").innerHTML = "&nbsp; Both password should be same.";
					document.getElementById("cupass").value = "";
				}
				return false;
			}
			
			function check1()
			{
				var pass=document.getElementById("upass").value;
				var pass1=document.getElementById("cupass").value;
				
				if(pass1!='')
				{
					if(pass != pass1)
					{
						// alert("Enter Password not match ! Please Re enter It.");
						document.getElementById("txt3").innerHTML = "&nbsp; Both password should be same.";
						document.getElementById("upass").value = "";
					}
					return false;
				}
			}
			
			function validpin(val)
			{
				var pin = val.value;
				
				if(!pin.match(/^[0-9]{6}$/))
				{
					// alert("Please enter 6 digit Pin number ...!");
					document.getElementById("txt10").innerHTML = "&nbsp; Please enter 6 digit Pin number.";
					val.value="";
					return false;
				}		
			}
			
			function terms_condition()
			{
				var agree_terms = document.getElementById('cfm');
				
				if(agree_terms.checked)
					document.getElementById("policy").innerHTML = "";
				else
					document.getElementById("policy").innerHTML = "<p style='color:red;'>you must agree to bookmyguruji Terms of use & privacy policy.</p>";
			}		
			
			function final_sub()
			{
				var full_name = document.getElementById("full_name").value;
				var mailId = document.getElementById("email").value;				
				var upass = document.getElementById("upass").value;
				var contact = document.getElementById("con").value;
				var add1 = document.getElementById("add1").value;
				var add2 = document.getElementById("add2").value;
				var add3 = document.getElementById("add3").value;
				var add4 = document.getElementById("add4").value;
				var add5 = document.getElementById("add5").value;
				var add6 = document.getElementById("add6").value;
				var agree = document.getElementById("cfm");
				var cupass = document.getElementById("cupass").value;
				
				if(full_name == "")
				{
					// alert("please enter name.");
					document.getElementById("txt1").innerHTML = "&nbsp; Please enter name.";
					document.getElementById("full_name").focus();
					return false;
				}
				else if(mailId == "")
				{
					// alert("please enter email Id.");
					document.getElementById("txtHint").innerHTML = "&nbsp; Please enter email Id.";
					document.getElementById("email").focus();
					return false;
				}
				else if(upass == "")		
				{
					// alert("please enter password.");
					document.getElementById("txt2").innerHTML = "&nbsp; Please enter password.";
					document.getElementById("upass").focus();
					return false;
				}
				else if(cupass=="")
				{
					// alert("please enter  confirm password.");
					document.getElementById("txt3").innerHTML = "&nbsp; Please enter confirm password.";
					document.getElementById("cupass").focus();
					return false;
				}
				else if(contact == "")
				{
					// alert("please enter contact no.");
					document.getElementById("txt4").innerHTML = "&nbsp; Please enter contact no.";
					document.getElementById("con").focus();
					return false;
				}
				else if(add1 == "")
				{
					// alert("please enter plot/flat no.");
					document.getElementById("txt5").innerHTML = "&nbsp; Please enter plot/flat no.";
					document.getElementById("add1").focus();
					return false;
				}
				else if(add2 == "")
				{
					// alert("please enter building/apartment name.");
					document.getElementById("txt6").innerHTML = "&nbsp; Please enter building/apartment name.";
					document.getElementById("add2").focus();
					return false;
				}
				else if(add3 == "")
				{
					// alert("please enter street/locality.");
					document.getElementById("txt7").innerHTML = "&nbsp; Please enter street/locality.";					
					document.getElementById("add3").focus();
					return false;
				}
				else if(add4 == "")
				{
					// alert("please enter area/landmark.");
					document.getElementById("txt8").innerHTML = "&nbsp; Please enter area/landmark.";
					document.getElementById("add4").focus();
					return false;
				}
				else if(add5 == "")
				{
					// alert("please enter city.");
					document.getElementById("txt9").innerHTML = "&nbsp; Please enter city.";
					document.getElementById("add5").focus();
					return false;
				}
				else if(add6 == "")
				{
					// alert("please enter pin code.");
					document.getElementById("txt10").innerHTML = "&nbsp; Please enter pin code.";
					document.getElementById("add6").focus();
					return false;
				}
				else if(!agree.checked)
				{
					document.getElementById("policy").innerHTML = "<p style='color:red;'>you must agree to bookmyguruji Terms of use & privacy policy.</p>";
					return false;
				}
				else
				{
					document.forms["sign_up"].submit();
					return true;
				}
			}			
		</script>
		
		<script>
			function showHint(str)
			{
			if (str.length==0) { 
				document.getElementById("txtHint").innerHTML="";
				return;
			} else 
			{
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (xmlhttp.readyState==4 && xmlhttp.status==200) 
					{
						var r=xmlhttp.responseText;
						
						document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
						if(r=='Already exist')
						{
							ValidateEmail();
							document.getElementById('sh_pass').style.display="none";
							document.getElementById('recover').style.display="inline";
							document.getElementById("exist").value = "yes";
						}
						else
						{
							ValidateEmail();
							document.getElementById('sh_pass').style.display="inline";
							document.getElementById("exist").value = "no";
						}
					}
				}
				xmlhttp.open("GET","<?php echo base_url() ?>index.php/Home/chaeck?q="+str,true);
				xmlhttp.send();
			}    
			}
		</script>
	</head>
	
<body onload="reset()">
	<br>
	<div id="wrapper" class="container">
		<section class="main-content">				
			<div class="row">
				<div class="span3"></div>
				<div class="span6"></br>				
					<h4 class="title"><span class="text">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Sign</strong>&nbsp;&nbsp;Up</span></h4>
					<form class="form-stacked" name="sign_up" onsubmit="return final_sub()" method="post" action="<?php echo base_url() ?>index.php/Login/signUp">
						<fieldset>
							<div class="control-group">
								<b>Name</b>
								<div class="controls">
										<input type="text" placeholder="Full Name" class="span3" name="full_name" id="full_name" maxlength="45" onchange="validateText(this)" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt1"></span></font>
								</div>
							</div>
							
							<div class="control-group">
								<b>Email Id</b>
								<div class="controls">
									<input type="text" placeholder="Email Id" class="span3" name="email" id="email" maxlength="40" onchange="showHint(this.value)" onkeypress="reset_msg()">
									&nbsp; <font size='2' color='red'><span id="txtHint"></span></font> <br>
								</div>
							</div>
							<div id="sh_pass">
								<div class="control-group">
									<b>Password</b>
									<div class="controls">
										<input type="password"  placeholder="Password" class="span3" name="upass" id="upass" onchange="check1()" maxlength="25" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt2"></span></font>
									</div>
								</div>
								<div class="control-group">
									<b>Confirm Password</b>
									<div class="controls">
										<input type="password"  placeholder="Confirm Password" class="span3" name="cupass" id="cupass" onchange="check()" maxlength="25" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt3"></span></font>
									</div>
								</div>
							
							<div>
								<div class="control-group">
									<b>Contact</b>
									<div class="controls">
										<input type="text"  placeholder="Contact" class="span3" name="con" id="con" onchange="val_numberTen(this)" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt4"></span></font>
									</div>
								</div>
								<div class="control-group">
									<b>Address:</b>
								</div>
								<div class="control-group">
									Plot/Flat No
									<div class="controls">
										 <input type="text" placeholder="Plot No" maxlength="15" class="span3" name="add1" id="add1" onkeypress="reset_msg()">
										 <font size='2' color='red'><span id="txt5"></span></font>
									</div>
								</div>
								<div class="control-group">
									Building/Apartment Name
									<div class="controls">
										<input type="text" placeholder="Building/Apartment Name" maxlength="25" class="span3" name="add2" id="add2" onkeypress="reset_msg()">
										<font size='2' color='red'><span id="txt6"></span></font>
									</div>
								</div>
								<div class="control-group">
									Street/Locality
									<div class="controls">
										  <input type="text" placeholder="Street/Locality" maxlength="35" class="span3" name="add3" id="add3" onkeypress="reset_msg()">
										  <font size='2' color='red'><span id="txt7"></span></font>
									</div>
								</div>
								<div class="control-group">
									Area/Landmark
									<div class="controls">
										  <input type="text" placeholder="Area/Landmark" maxlength="30" class="span3" name="add4" id="add4" onkeypress="reset_msg()">
										  <font size='2' color='red'><span id="txt8"></span></font>
									</div>
								</div>
								<div class="control-group">
										City
									<div class="controls">
										  <input type="text" placeholder="City" onchange="validateText(this)" maxlength="30" class="span3" name="add5" id="add5" onkeypress="reset_msg()">
										  <font size='2' color='red'><span id="txt9"></span></font>
									</div>
								</div>
								<div class="control-group">
									Pincode
									<div class="controls">
										 <input type="text" placeholder="Pincode" onchange="validpin(this)" class="span3" name="add6" id="add6" onkeypress="reset_msg()">
										 <font size='2' color='red'><span id="txt10"></span></font>
									</div>
								</div>
							</div>
							<br>
							<div class="control-group">
								<div class="controls">
									<input name="cfm" id="cfm" type="checkbox" onclick="terms_condition()" class="input-xlarge"> &nbsp; I agree to the bookmyguruji <a href="<?php echo base_url(); ?>index.php/Home/termsofuse"> Terms of use </a> and <a href="<?php echo base_url(); ?>index.php/Home/privacypolicy"> Privacy Plolicy </a></input>
									</br>
									</br>
									<span id="policy"></span>
								</div>
							</div>						
							<div class="actions">
								<input tabindex="9" class="btn btn-success" type="submit" value="Sign Up">
								&nbsp; &nbsp; 
								<input tabindex="9" class="btn btn-warning" type="reset" value="Reset">
							</div>
							</div></br>
							<div class="control-group" id="recover" style="display:none">
									<p class="reset"><a href="<?php echo base_url() ?>index.php/Home/recover_pass"><b>Recover your username or password</b></a></p>
							</div>
						</fieldset>
					</form>					
				</div>
				<div class="span3"></br>
					<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
					<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center>
					<br><br>
					<?php
					foreach($images as $img)
					{
					?>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image4;?>" id="pn"></br></br>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image3;?>" id="pn"></br></br>
						<img src="<?php echo base_url()?>uploads/<?php echo $img->image2;?>" id="pn"></br></br>
					<?php
					}
					?>
				</div>
				<br>
			</div>				
		</section>			
				<br>
	</div>
</body>					
</html>
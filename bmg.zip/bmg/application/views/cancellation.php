<!DOCTYPE html>
<html lang="en">
	<head>
	</head>
	</br>
	<div id="wrapper" class="container">			
		<div id="ff">	
		<section class="main-content">
		<div class="row" >			</br>
			<div class="span10">
							<h4>Cancellation and Returns Policy</h4>
						<div style="text-align:justify;">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In case of cancellation of any pooja, the customer has to contact bookmyguruji.
							com before 48 hours from the date of pooja.Customer has to be contacted through email
							  or call our customer care for the cancellation of Services or Products.<br>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In case of any changes in the date of booking, the customer  should contact 
							bookmyguruji.com by calling their customer care for the same before 48 hours from the date 
							of pooja.
						</div>
							<br>
							<b>Pooja</b><br>
						<div style="text-align:justify;">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For Pandits a grace period of not more than 1 hour shall be accepted.
							(In case of Unavoidable circumstances like natural disasters, police bandhs. etc)<br>
						</div><br>
							<b>Services</b></br>
						<div style="text-align:justify;">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In case of cancellation of service the following returns policy is applicable.<br>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Before 48 hours 15% deduction. 85% returned.<br>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Before 12 hours 25% deduction.75% returned. After that no refund would be provided.<br>
						</div><br>
							<b>Products</b><br>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7 days return policy.<br>
						<div style="text-align:justify;">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The product purchased will be returned to bookmyguruji.com under the following conditions :-<br>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The product is in faulty or defective condition.<br>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If the product is physically damaged.<br>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Not as specified by the seller.<br>
						</div><br>
				</div>
			</div></br>
		</section>
		</div>
	</div>
    </body>
</html>
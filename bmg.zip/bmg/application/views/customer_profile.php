<html lang="en">
	<head>
		<!-- Date picker css & js-->
		<link href="<?php echo base_url(); ?>css/runnable.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>js/script.js"></script>	
		<script src="<?php echo base_url(); ?>js/script1.js"></script>	

		<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css" />
		<script src="<?php echo base_url(); ?>js/jquery-1.9.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
		<script type="text/javascript">
			
			function reset_msg()
			{
				document.getElementById("txt1").innerHTML = "";
				document.getElementById("txt2").innerHTML = "";
				document.getElementById("txt3").innerHTML = "";
				document.getElementById("txt4").innerHTML = "";
				document.getElementById("txt5").innerHTML = "";
				document.getElementById("txt6").innerHTML = "";
				document.getElementById("txt7").innerHTML = "";
				document.getElementById("txt8").innerHTML = "";
			}
			
			function validateText(val)	
			{
				var str = val.value;
				if(!str.match(/^[A-Za-z ]*$/))
				{
					if(val.id == "name")
					{
						document.getElementById("txt1").innerHTML = "&nbsp; Please enter valid information.";
					}
					else if(val.id == 'add5')
					{
						document.getElementById("txt7").innerHTML = "&nbsp; Please enter valid information.";
					}						
					val.value="";
					return false;
				}
			}	
			
			function val_numberTen(val)
			{
				var no = val.value;
				
				if(!no.match(/^[0-9]{10}$/))
				{
					// alert("Please enter 10 digit number ...!");
					document.getElementById("txt2").innerHTML = "&nbsp; Please enter 10 digit number.";
					val.value="";
					return false;
				}
			}
			
			function validpin(val)
			{
				var pin = val.value;
				
				if(!pin.match(/^[0-9]{6}$/))
				{
					// alert("Please enter 6 digit Pin number ...!");
					document.getElementById("txt8").innerHTML = "&nbsp; Please enter 6 digit Pin number.";
					val.value="";
					return false;
				}		
			}
			
			function Edit_data()
			{
				document.getElementById("name").removeAttribute("disabled");
				document.getElementById("mno").removeAttribute("disabled");
				document.getElementById("add1").removeAttribute("disabled");
				document.getElementById("add2").removeAttribute("disabled");
				document.getElementById("add3").removeAttribute("disabled");
				document.getElementById("add4").removeAttribute("disabled");
				document.getElementById("add5").removeAttribute("disabled");
				document.getElementById("add6").removeAttribute("disabled");
				
				document.getElementById('show2').style.display="inline";
				document.getElementById('show1').style.display="none";
			}
			
			function form_submit()
			{
				var name = document.getElementById("name").value;	
				var number = document.getElementById("mno").value;
				var add1 = document.getElementById("add1").value;
				var add2 = document.getElementById("add2").value;
				var add3 = document.getElementById("add3").value;
				var add4 = document.getElementById("add4").value;
				var add5 = document.getElementById("add5").value;
				var add6 = document.getElementById("add6").value;
			
				if(name == "")
				{
					// alert("Please Fill Name.");
					document.getElementById("txt1").innerHTML = "Please fill name.";
				}
				else if(number == "")
				{
					// alert("Please Fill Contact No .");
					document.getElementById("txt2").innerHTML = "Please fill contact No.";
				}
				else if(add1 == "")
				{
					// alert("Please Fill Flat No.");
					document.getElementById("txt3").innerHTML = "Please fill flat No.";
				}
				else if(add2 == "")
				{
					// alert("Please Fill Apartment Name");
					document.getElementById("txt4").innerHTML = "Please fill apartment name.";
				}
				else if(add4 == "")
				{
					// alert("Please Fill Area");
					document.getElementById("txt5").innerHTML = "Please fill area name.";
				}
				else if(add3 == "")
				{
					// alert("Please Fill Street");
					document.getElementById("txt6").innerHTML = "Please fill street name.";
				}
				else if(add5 == "")
				{
					// alert("Please Fill City");
					document.getElementById("txt7").innerHTML = "Please fill city name.";
				}
				else if(add6 == "")
				{
					// alert("Please Fill PINCODE");
					document.getElementById("txt8").innerHTML = "Please fill pincode.";
				}
				else
				{
					document.forms["profileform"].submit();
				}
			}			
		</script>
	</head>
	<body>
		<br>		
		<?php
			if($this->session->userdata('update_profile'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('update_profile').'")';
				echo '</script>'; 
				$this->session->unset_userdata('update_profile');
			}
		?>
		<div class="row">
			<div class="span1"></div>
			<div class="span7">
				<table>
					<tr>
						<td><h4>&nbsp; &nbsp; &nbsp;Profile </h4></td>
						<!--<td align="left"> [ <a href="javascript:Edit_data();" style="color:red;" > Edit </a> ] </td>-->
					</tr>
				</table>
				<form  name="profileform" action= "<?php echo base_url() ?>index.php/customer_detail_edit/updata_profile" method="post">
					<br>
					<div class="span3">
						<div class="control-group">
							<b>Name :</b>
							<div class="controls">
								<input type="text" class="span3" name="name" id="name" style="background-color:white;" onchange="validateText(this)" onkeypress="reset_msg()" value="<?=$values[0]->fullname?>" maxlength="45" disabled>
								<font size='2' color='red'><span id="txt1"></span></font>
							</div>
						</div>					
						
						<br>
						
						<div class="control-group">
							<b> Contact : </b>
							<div class="controls">
								<input type="text" class="span3" name="mno" id="mno" style="background-color:white;" onchange="val_numberTen(this)" onkeypress="reset_msg()" value="<?=$values[0]->contact_no?>" disabled>
								<font size='2' color='red'><span id="txt2"></span></font>
							</div>
						</div>
						
						<br>
						
						<div class="control-group">
							<b> Address : </b>
						</div>
						
						<div class="control-group">
							Plot/Flat No :
							<div class="controls">
								<input type="text" class="span3" name="add1" maxlength="15" id="add1" onkeypress="reset_msg()" style="background-color:white;" value="<?=$values[0]->add1?>" disabled>
								<font size='2' color='red'><span id="txt3"></span></font>
							</div>
						</div>
						
						<br>
						
						<div class="control-group">
							Building/Apartment Name :
							<div class="controls">
								<input type="text" class="span3" name="add2" maxlength="25" onkeypress="reset_msg()" id="add2" style="background-color:white;" value="<?=$values[0]->add2?>" disabled>
								<font size='2' color='red'><span id="txt4"></span></font>
							</div>
						</div>
						
						<br>
						
						<div class="control-group">
							Area/Landmark :
								<div class="controls">
									<input type="text" class="span3" name="add4" maxlength="30" id="add4" onkeypress="reset_msg()" style="background-color:white;" value="<?=$values[0]->add4?>" disabled>
									<font size='2' color='red'><span id="txt5"></span></font>
								</div>
						</div>						
						
					</div>
					
					<div class="span3">
						<div class="control-group">
							<b> Email : </b>
							<div class="controls">
								<input type="text" class="span3" name="emaild" id="emaild" style="background-color:white;" value="<?=$values[0]->username?>" disabled>
								<input type="hidden" name="email" id="email" style="background-color:white;" value="<?=$values[0]->username?>">
							</div>
						</div>
						
						<div class="control-group">
							<br>
						</div>
						
						<div class="control-group">
							<div class="controls">
								<br><br><br><br><br>
							</div>
						</div>
						
						<div class="control-group">
							Street/Locality :
							<div class="controls">
								<input type="text" name="add3" id="add3" maxlength="35" style="background-color:white;" onkeypress="reset_msg()" value="<?=$values[0]->add3?>" disabled></td>
								<font size='2' color='red'><span id="txt6"></span></font>
							</div>
						</div>
						
						<br>
						
						<div class="control-group">
							City :
							<div class="controls">
								<input type="text" class="span3" name="add5" maxlength="30" id="add5" onchange="validateText(this)" onkeypress="reset_msg()" style="background-color:white;" value="<?=$values[0]->add5?>" disabled></td>
								<font size='2' color='red'><span id="txt7"></span></font>
							</div>
						</div>
						
						<br>
						
						<div class="control-group">
							Pincode : 
							<div class="controls">
								<input type="text" class="span3" name="add6" id="add6" onchange="validpin(this)" onkeypress="reset_msg()" style="background-color:white;" value="<?=$values[0]->add6?>" disabled></td>
								<font size='2' color='red'><span id="txt8"></span></font>
							</div>
						</div>
					</div>
				
				<div class="span6" align="center">
					<div class="control-group">
						<div id="show1">
							<br>
							<input type="button" value="Edit" onclick="Edit_data()" class="btn btn-warning">
						</div>
						<div id="show2"  style="display:none">
							<br>
							<input type="button" value="Submit" onclick="form_submit()" class="btn btn-success">
						</div>	
					</div>
				</div>
			</div>
			</form>
		</div>
	</div>
	</section>
	</div>
	</body>
</html>
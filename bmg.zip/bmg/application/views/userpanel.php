<html>
	<style>
	#sl:hover
		{
		background-color: #ff8533;
		}    
	</style>
	</br>
	<div id="wrapper" class="container">
		<section class="main-content">				
			<div class="row">
				<div class="span3">			
					<fieldset></br>
						<div class="control-group">
							<div class="controls" >
							<table width="100%" style="background-color:#FAA732;height:100%;"  ><tr><td>
								<table width="100%" style="background-color:#FAA732; border="1" >
									<tr>
										<td align="center" id="sl" style="height:55px;width:100%;">
											<a href="<?php echo base_url() ?>index.php/customer_detail_edit/enquiry_details" style="color:white;">
											<div style="height:100%;width:100%;">&nbsp;&nbsp;<b></br> ENQUIRY </b></div>
										</a>
										</td>
									</tr>
								</table><div style="border: 1px solid white;"></div>
								<table width="100%"  style="background-color:#FAA732; border="1" >
									<tr>
										<td align="center" id="sl" style="height:55px;width:100%">
											<a href="<?php echo base_url() ?>index.php/customer_detail_edit/order_details" style="color:white;">
											<div style="height:100%;width:100%;">&nbsp;&nbsp;<b></br> ORDERS </b></div>
										</a>
										</td>
									</tr>
								</table><div style="border: 1px solid white;"></div>
								<table width="100%"  style="background-color:#FAA732; border="1" >
									<tr>
										<td align="center" id="sl" style="height:55px;width:100%">
											<a href="<?php echo base_url() ?>index.php/customer_detail_edit/history_details" style="color:white;">
											<div style="height:100%;width:100%;">&nbsp;&nbsp;<b></br> HISTORY </b></div>
										</a>
										</td>
									</tr>
								</table><div style="border: 1px solid white;"></div>
								<table width="100%"  style="background-color:#FAA732; border="1" >
									<tr>
										<td align="center" id="sl" style="height:55px;width:100%">
											<a href="<?php echo base_url() ?>index.php/customer_detail_edit/show_rejection" style="color:white;">
											<div style="height:100%;width:100%;">&nbsp;&nbsp;<b></br> REJECTIONS </b></div>
										</a>
										</td>
									</tr>
								</table><div style="border: 1px solid white;"></div>
								<table width="100%"  style="background-color:#FAA732; border="1" >
									<tr>
										<td align="center" id="sl" style="height:55px;width:100%">
											<a href="<?php echo base_url() ?>index.php/customer_detail_edit/customer_profile" style="color:white; ">
											<div style="height:100%;width:100%; ">&nbsp;&nbsp;<b></br> PROFILE </b></div>
											</a>
										</td>
									</tr>
								</table><div style="border: 1px solid white;"></div>
								</td></tr>
								</table>
							</div>
						</div>
					</fieldset>
				</div>
	</html>		
	
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		
		<!-- Date picker css & js-->
		<link href="<?php echo base_url(); ?>css/runnable.css" rel="stylesheet"/>
		<script src="<?php echo base_url(); ?>js/script.js"></script>	
		<script src="<?php echo base_url(); ?>js/script1.js"></script>	

		<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css" />
		<script src="<?php echo base_url(); ?>js/jquery-1.9.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
		<style>
		#pn:hover
		{
			border: 1px solid #FAA732;
		}
		#sl:hover
		{
			background-color: #FFE6CC;
		}
		</style>	
		<script>
		
		function displayResult()
        {
			var xx = document.getElementById("cnts").value;
			xx++;
			
            document.getElementById("myProduct").insertRow(-1).innerHTML = '<td align="center"></br><input class = "form-control" type="text" id="eventname'+xx+'" name="eventname'+xx+'" required ></td>';
			
			document.getElementById("cnts").value = xx;
        }
		
		function kaymatch()
		{		
			var aevent = document.getElementById('addevent');
			if(aevent.checked)
			{
				var xx = document.getElementById("cnts").value;
				var i,x,str="";
				
				for(i=1;i<=xx;i++)
				{
					x = document.getElementById("eventname"+i).value;
					if(x==null || x.trim()=="")
					{
						alert("Plaease Fill Event");
						return;
					}
					else
					{
						str = str + x +',';
					}
				}
				document.forms["event"]["prds"].value=str;
				document.forms["event"].submit();
			}
			else
			{
				document.forms["event"].submit();
			}			
		}
		
		function show_event()
		{
			var aevent = document.getElementById('addevent');
			var aimages = document.getElementById('addimages');
			
			if(aimages.checked)
			{
				document.getElementById('add_images').style.display='inline';
			}
			else
			{
				document.getElementById('add_images').style.display='none';
			}
			
			if(aevent.checked)
			{
				//document.getElementById('add_event').checked=true;
				document.getElementById('add_event').style.display='inline';				
			}
			else
			{
				document.getElementById('add_event').style.display='none';				
			}
			
			if(!aimages.checked && !aevent.checked)
			{
				document.getElementById('addevent').checked=true;
				document.getElementById('add_event').style.display='inline';
				document.getElementById('add_images').style.display='none';
			}
		}
		
		function remove_event(event_id)
		{
			var cfm=confirm("Do you want Delete this event?");
				if(cfm==true)
				{
					
					document.forms['delete_event']['eventindex'].value=event_id;
					document.forms['delete_event'].submit();
				}
			return false;
		}
		</script>
	</head>
	
<body>
	<?php
		if($this->session->userdata('enq_ins_msg'))
		{
			echo '<script type="text/javascript">';
			echo 'alert("'.$this->session->userdata('msg').'")';
			echo '</script>'; 
			$this->session->unset_userdata('msg');
		}
		
		if($this->session->userdata('add_event'))
			{
				echo '<script type="text/javascript">';
				echo 'alert("'.$this->session->userdata('add_event').'")';
				echo '</script>'; 
				$this->session->unset_userdata('add_event');
			}
	?></br>
	<div id="wrapper" class="container">
		<section class="main-content">				
			<div class="row">
			<form class="form-stacked" name="event" method="post" action="<?php echo base_url() ?>index.php/Right_panel/right" enctype="multipart/form-data">
				<div class="span3">
					<br/><br/><br/><br/><br/>
					<input type="checkbox" name="addevent" id="addevent" onclick="show_event()" value="1" checked> &nbsp; Add Events
					<br/><br/>
					<input type="checkbox" name="addimages" id="addimages" value="2" onclick="show_event()"> &nbsp; Add Images
				</div>
				<div class="span4">
					</br>				
					<h4 class="title"><span class="text">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>Right</strong>&nbsp;&nbsp;Panel</span></h4>
						<fieldset>
							<div class="control-group" id="add_event"> 
								<label class="control-label"><b>Event</b></label>
								<div class="controls">
									<input type="hidden" name="cnts" id="cnts" value="1"/>
									<input type="hidden" name="prds" id="prds">
									<table id="myProduct" border="0">	
										<tr>
											<td>
												<input class = "form-control" type="text" style="margin-bottom:-0px" Placeholder="Event" id="eventname1" name="eventname1">
											</td>
											<td >		
												<input type="button" class="btn btn-success"  onclick="displayResult()" value="+" title="Add New Event" >
											</td>
										</tr>
									</table>
								</div>
							</div>	
							
							<div class="control-group" id="add_images" style="display:none;">
								<label class="control-label"><b>Images</b></label>
								<div class="controls">
									<input type="file" class="span3" name="image1" id="image1" required>
								</div>
								<br>
								<div class="control-group">
									<div class="controls">
										<input type="file"  class="span3" name="image2" id="image2" required >
									</div>
								</div>
								<br>
								<div class="control-group">
									<div class="controls">
										<input type="file"  class="span3" name="image3" id="image3" required >
									</div>
								</div>
								<br>
								<div class="control-group">
									<div class="controls">
										<input type="file"  class="span3" name="image4" id="image4" required >
									</div>
								</div>
								<br>
								<div class="control-group">
									<div class="controls">
										<input type="file"  class="span3" name="image5" id="image5" required >
									</div>
								</div>
								<br>
								<div class="control-group">
									<div class="controls">
										<input type="file"  class="span3" name="image6" id="image6" required >
									</div>
								</div>
							</div>
							
							<br>
							<div class="actions">
								<input tabindex="9" class="btn btn-success" type="button" onclick="kaymatch()" value="Create Event">
								&nbsp; &nbsp; 
								<input tabindex="9" class="btn btn-warning" type="reset" value="Reset">
							</div>
							<br/>
						</fieldset>
					</form>					
				</div>
				<div class="span2"></div>
				<div class="span3">
					<center  id="pn" ><a href="<?php echo base_url() ?>index.php/Home/book_guruji_direct"><img alt="" src="<?php echo base_url(); ?>img/nav.jpg">
					<img alt="" src="<?php echo base_url(); ?>img/logo1.png" width="100%" height="100px"></a></center>
					<br>					
				</div>
				<br>
			</div>
		</section>
		<div class="span1"></div>
			<div class="span6">
				<div style="width: 100%; height:200px; overflow-y: auto;">
				<form name="delete_event" method="post" action="<?php echo base_url() ?>index.php/Right_panel/event_delete">
					<input type="hidden" id="eventindex" name="eventindex">
					<table class="table table-bordered table-fixed">
						<tr class="active" align="center" size="auto">
							<th class="active" width="12%"><h6><p> Sr. No </p></h6></th>
							<!--th class="active"><h6><p> All <br><input type="checkbox" name="all1" id="all1" value="2" onclick='checkedAll1(newsl);'> </p></h6></th-->
							<th class="active"><h6><p> Event Name </p></h6></th>
							<th class="active" width="12%"><h6><p> Action </p></h6></th>
						</tr>
					<?php
					if($values)
					{
						$str = $values[0]->eventname;	
						$my_array = explode("#", $str);						
						$len=sizeof($my_array);
						$no=1;
						for($i=0;$i<$len;$i++)
						{
							if($my_array[$i] != '')
							{
					?>
							<tr>
								<td><?=$no;?></td>
								<td><?=$my_array[$i];?></td>
								<td><input type="button" class="btn btn-warning" value="Delete" onclick="remove_event(<?=$i;?>);"></td>
							</tr>
					<?php
						$no++;
						}
						}
					}
					?>	
					</table>
				</form>	
				</div></br>
			</div>	
	</div>
</body>					
</html>
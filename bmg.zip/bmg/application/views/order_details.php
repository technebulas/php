<!DOCTYPE html>
<html lang="en">
	<head>
		<script type="text/javascript">
			
			function set_action(v1,v2)
			{
				document.forms["viewform"]["hidd_action"].value = v1;
				document.forms["viewform"]["hidd_enq_id"].value = v2;
				
				if(v1 == 1)
				{
					document.forms["viewform"].submit();
				}
				else
				{
					cnf = confirm("Do you really want to done this pooja?");
					
					if(cnf == true)
					{
						document.forms["viewform"].submit();
					}
					else
					{
						return;
					}
				}
			}
		</script>
	</head>

	<body><br>
	<div id="wrapper" class="container">
		<div class="row">
		<br>
		<div class="span12">
		<h4>ORDER DETAILS</h4>
		<div style="width: 100%; height:600px; overflow-y: auto;">
			<table class="table table-bordered table-fixed">
				<tr class="active" align="center" size="auto">
					<th class="active"><h6><p> Sr. No </p></h6></th>
					<th class="active"><h6><p> Order ID </p></h6></th>
					<th class="active"><h6><p> Enquiry ID </p></h6></th>
					<th class="active"><h6><p> Payment ID </p></h6></th>
					<th class="active"><h6><p> Enquiry Date </p></h6></th>
					<th class="active"><h6><p> Booking Details </p></h6></th>
					<th class="active"><h6><p> Pooja Details</p></h6></th>
					<th class="active"><h6><p> Price</p></h6></th>
					<th class="active"><h6><p> Action </p></h6></th>
				</tr>
				
				<form  name="viewform" action= "<?php echo base_url() ?>index.php/order_detail_edit/specific_order" method="post">
					
					<input type="hidden" name="hidd_enq_id" id="hidd_enq_id"/>
					<input type="hidden" name="hidd_action" id="hidd_action"/>
					<?php 
					
					$no = 1;
					foreach($values as $value)
					{
						if($no%2==1)
						{
					?>
						<tr class="info" align = "center">
							<td><?=$no?></td>
							<td><?=$value->order_id?></td>
							<td><?=$value->enq_id?></td>
							<td><?=$value->pay_id?></td>
							<td><?=date("d/m/Y", strtotime($value->enq_date))?></td>
							<td><?=date("d/m/Y", strtotime($value->booking_date))?><br><?=$value->book_time?></td>
							<td>
								<p><b><?=ucwords($value->pj_name)?></b>
								<?php
									$sam_st = $value->sam_status;
									
									$ind = $value->poojas;
											
									echo "<br>";
									if($ind >= 1 and $ind <= 14)
									{
										echo "(Home Pooja)";
									}
									else if($ind >= 15 and $ind <= 19)
									{
										echo "(Office Pooja)";
									}
									else if($ind >= 20  and $ind <= 30)
									{
										echo "(Festival Pooja)";
									}
									else if($ind >= 31 and $ind <= 37)
									{
										echo "(Functional Pooja)";
									}
									else
									{
										echo "(Other Pooja)";
									}
									echo "</p>";
									
									if($sam_st == 'yes')
										echo "(with samagree)";
									else
										echo "(without samagree)";
								?>
							</td>
							<td>Rs. <?=$value->pooja_amt?></td>
							<td>
								<input class="btn btn-success" type="button" value="View" onclick="set_action(1,<?=$value->enq_id?>)">
								<input class="btn btn-warning" type="button" value="Done" onclick="set_action(2,<?=$value->enq_id?>)">
							</td>
						</tr>
					<?php
						}
						else
						{
					?>
						<tr align = "center">
							<td><?=$no?></td>
							<td><?=$value->order_id?></td>
							<td><?=$value->enq_id?></td>
							<td><?=$value->pay_id?></td>
							<td><?=date("d/m/Y", strtotime($value->enq_date))?></td>
							<td><?=date("d/m/Y", strtotime($value->booking_date))?><br><?=$value->book_time?></td>
							<td>
								<p><b><?=ucwords($value->pj_name)?></b>
								<?php
									$sam_st = $value->sam_status;
									
									$ind = $value->poojas;
											
									echo "<br>";
									if($ind >= 1 and $ind <= 14)
									{
										echo "(Home Pooja)";
									}
									else if($ind >= 15 and $ind <= 19)
									{
										echo "(Office Pooja)";
									}
									else if($ind >= 20  and $ind <= 30)
									{
										echo "(Festival Pooja)";
									}
									else if($ind >= 31 and $ind <= 37)
									{
										echo "(Functional Pooja)";
									}
									else
									{
										echo "(Other Pooja)";
									}
									echo "</p>";
									
									if($sam_st == 'yes')
										echo "(with samagree)";
									else
										echo "(without samagree)";
								?>
							</td>
							<td>Rs. <?=$value->pooja_amt?></td>
							<td>
								<input class="btn btn-success" type="button" value="View" onclick="set_action(1,<?=$value->enq_id?>)">
								<input class="btn btn-warning" type="button" value="Done" onclick="set_action(2,<?=$value->enq_id?>)">
							</td>
						</tr>
					<?php
						}
						
						$no++;
					}
					
					if($no==1)
					{
						echo "<tr><th colspan='9'><b style='color:red;'>No Record Found</b></th></tr>";
					}
					
					?>	
				</form>										
				
			</table>
		</div>						
		</div>	
		
		</div>	<br><br>					
	</div>						
	</body>
</html>
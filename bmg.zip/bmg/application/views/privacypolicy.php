<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">      
		<link href="<?php echo base_url(); ?>css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="<?php echo base_url(); ?>css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="<?php echo base_url(); ?>css/flexslider.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>				
		<script src="<?php echo base_url(); ?>js/superfish.js"></script>	
		<script src="<?php echo base_url(); ?>js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
	
   
		<!--	<section class="header_text sub" >
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				<h4><span></span></h4>
			</section>
			-->
	</br>
	<div id="wrapper" class="container">			
		<div id="ff">	
		<section class="main-content">
		<div class="row" >
		<div class="span12"></br>
				<h4>Privacy Policy</h4>
				<div style="text-align:justify;">	
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bookmyguruji is an online e-commerce portal designed to 
					provide an easy way for our members to shop online. 
					bookmyguruji.com members create their own unique profile using our predetermined form.
					Name, address, telephone and email-id is a mandatory information to become a member. 
					We also collect Credit card / Debit Card information and IP address once the member 
					transacts on bookmyguruji.com, using our payment gateway, which is on a 100% secure 
					server. None of the information we gather can be used by the public 
					(visitors, other members, and anyone not employed by bookmyguruji.com,
					its corporate affiliates, or the financial institutions we use to process
					membership charges) to identify a specific individual.
				</div>
				<br>
				<div style="text-align:justify;">
					<h4>Service Providers</h4>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;We use other third parties to provide logistics and payment 
					processing on our site. When you transact or place an order on
					our site, we will share shipping address with the logistics
					provider and credit card number with the payment gateway provider
					as necessary for the third party to provide that service.
					These third parties are prohibited from using your personally
					identifiable information for any other purpose.We do not sell, 
					rent, share, trade or give away any of your private information 
					without your permission except to the financial institution that
					processes your credit card transactions. We reserve the right to
					disclose your personally identifiable information as required by 
					law and when we believe that disclosure is necessary to protect
					our rights and/or comply with a judicial proceeding, court order,
					or legal process served on our Website. bookmyguruji.com uses cookies
					to provide the services, to deliver content specific to your interests,
					to save your password so you don't have to re-enter it each time you visit
					different pages on our site, and for other purposes. Please note that cookies
					are used only to recollect information sent to your computer from bookmyguruji.com.
					We CANNOT access any information not sent by bookmyguruji.com. We also do not link the 
					information we store in cookies to any personally identifiable information you submit while on our site.
				</div>
				<br>
				<div style="text-align:justify;">
					<h4>Third Party Cookies</h4>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Some of our business partners(e.g., advertisers) use cookies on our site. 
					We have no access to or control over these cookies. This privacy statement
					covers the use of cookies by bookmyguruji.com only and does not cover the
					use of cookies by any advertisers .If we decide to change our privacy policy,
					we will post those changes to this privacy statement, the home page, 
					and other places we deem appropriate so that you are aware of what information we collect,
					how we use it, and under what circumstances, if any, we disclose it. bookmyguruji.com 
					sends email offers to individuals who would require information on product updates and
					services. We reserve the right to modify this privacy statement at any time, 
					so please review it frequently. If we make material changes to this policy,
					we will notify you here, by email, or by means of a notice on our homepage.
			</div>
			<br>
		</div>
	</div>
	</div>
	</div>
		</section>
		
    </body>
</html>
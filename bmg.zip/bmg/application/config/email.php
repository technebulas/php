<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* $config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.googlemail.com';
$config['smtp_port'] = '465';
$config['mailpath'] = '/usr/sbin/sendmail';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
$config['newline']='\r\n'; 
$config['smtp_user']='support@bookmyguruji.com';
$config['smtp_pass']='Support123*'; */


?>